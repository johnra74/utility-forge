/* =============================================================================
   owner-journey.js — the Scotia Data Catalog prototype, with the data owner
   journey delivered as a guided tour rather than as product features.

   Third of three, and deliberately the same shape as the other two:

     THE PROTOTYPE  is just the product. A catalog where an owner registers a
                    data product, assembles it, gives its fields meaning and
                    signs a contract. Nothing on screen explains itself, because
                    a real product does not narrate its own value.

     THE TOUR       is React Joyride. Every line of journey narration lives in
                    TOUR below and appears in a tooltip anchored to the real
                    element it is talking about. Close the tour and you are left
                    with a product; there is no leftover scaffolding.

   THE UNIT OF WORK IS THE DATA PRODUCT (DP-0142). It is a curated bundle with
   one accountable owner, and it contains logical datasets — one of which,
   enterprise.customer.customer_360_profile, is the dataset the analyst queries
   and the steward certifies.

   Two things follow from working at product level, and both are handled rather
   than left to cause quiet contradictions:

     - The product carries its own identifier, never a table urn. A product that
       claims to be a table is neither.
     - Terms and code sets attach to logical data elements (end-to-end-journey.md
       step 4 is explicit about this), which live one level down. The Glossary
       tab therefore names the dataset alongside every element it maps, so the
       four terms and one coded field here are the same four and one that
       steward-journey.js counts when it certifies that dataset.

   The owner is the middle link, and the other two files depend on this one:

     steward-journey.html  publishes the term and curates the code set
     owner-journey.html    ATTACHES BOTH TO ACTUAL ELEMENTS, classifies the
                           product, and signs the contract the quality score is
                           measured against
     analyst-journey.html  reads English instead of R01, meets the obligations
                           the classification put in force, and trusts the score

   React 18 and react-joyride 2.9 are vendored and pre-bundled in
   vendor/react-joyride.bundle.js — one React instance, no network at run time.
   The DataHub skin is in catalog.css, shared with steward-journey.html.
   ========================================================================== */

(function () {
  'use strict';

  var h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect, useCallback = React.useCallback;
  var JC = window.JoyrideConst;

  /* --- icons (feather-style; every path must start with an absolute M, since
         ic() prefixes each segment with one) ------------------------------- */
  var I = {
    db: 'M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3ZM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6',
    box: 'M12 3 21 8v8l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v9',
    book: 'M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 0-3 3V4ZM18 20H7',
    grid: 'M4 4h7v7H4V4ZM13 4h7v7h-7V4ZM4 13h7v7H4v-7ZM13 13h7v7h-7v-7Z',
    hash: 'M5 9h14M5 15h14M10 4 8 20M16 4l-2 16',
    clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM12 7v5l3 2',
    search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14ZM20 20l-3.5-3.5',
    check: 'M5 12L9.5 16.5L19 7',
    warn: 'M12 3 22 20H2L12 3ZM12 9v5M12 17.5v.5',
    lock: 'M5 11h14v10H5V11ZM8 11V7a4 4 0 0 1 8 0v4',
    arrow: 'M4 12h15M13 6l6 6-6 6',
    spark: 'M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3.5 3.5M14.5 14.5 18 18M18 6l-3.5 3.5M9.5 14.5 6 18'
  };
  function ic(n, sz) {
    return '<svg width="' + (sz || 16) + '" height="' + (sz || 16) + '" viewBox="0 0 24 24" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      I[n].split('M').filter(Boolean).map(function (p) { return '<path d="M' + p + '"/>'; }).join('') +
      '</svg>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* =======================================================================
     DATA — the Scotia records shared with the other two journeys, plus the
     registration, mapping and contract material this journey needs.
     ==================================================================== */

  /* The protagonist. steward-journey.js already names him as the Data Owner of
     the dataset inside this product; Aisha is its steward there and here. */
  var OWNER = { initials: 'MD', name: 'Marc Deschamps', role: 'VP, Retail Deposits' };
  var STEWARD = { initials: 'AS', name: 'Aisha Sharma', role: 'Customer Domain Steward' };

  /* The data product. Its identifier is its own — a product carrying a table urn
     is pretending to be a table. The dataset the rest of the story consumes is
     named separately, because that is what it is: one thing inside this. */
  var PRODUCT = {
    id: 'DP-0142', name: 'Retail Customer 360',
    urn: 'dataproduct.retail.customer_360',
    flagship: 'enterprise.customer.customer_360_profile',
    domain: 'Customer', version: 'v1.0 — first release', classification: 'Restricted',
    purpose: 'A single, complete view of every retail customer relationship — who they are, ' +
      'what they hold, how they behave, and whether they are leaving — for retail performance ' +
      'reporting and attrition analysis.',
    usedFor: [
      'Retail performance and board reporting.',
      'Attrition and retention analysis.'
    ],
    notFor: [
      'Credit decisioning — that is a Risk product, on Risk\'s own data.',
      'Outbound marketing without an active consent flag.'
    ],
    quality: 96, consumers: 41,
    refresh: 'Daily 02:00 ET', availability: 'Tier 1 · 99.9%'
  };

  /* Sensitivity is a property of the data, not a decision the owner takes. The
     platform reads the datasets in the product, finds personal data, and elevates
     the product's access policy on the spot — the owner is informed, and there is
     nothing to accept or decline.

     The protection groups and their wording are the ones the analyst meets in
     analyst-journey.js before a query runs. This screen is where they come from;
     until it existed the analyst's obligations panel had no origin in the story. */
  var CLASSIFICATION = {
    was: 'Internal', now: 'Restricted',
    detected: [
      { el: 'sin_hash', kind: 'National identifier, hashed', pg: 'PG-PII-RES-09' },
      { el: 'full_name', kind: 'Direct identifier', pg: 'PG-PII-RES-04' },
      { el: 'date_of_birth', kind: 'Direct identifier', pg: 'PG-PII-RES-04' }
    ],
    obligations: [
      { pg: 'PG-PII-RES-09', rule: 'SIN hash is withheld entirely from analytics roles.' },
      { pg: 'PG-PII-RES-04', rule: 'Name and date of birth are masked for analytics roles.' },
      { pg: 'PG-CUST-RES-01', rule: 'Customer records stay in the Canadian region.' }
    ],
    access: 'Request with a declared purpose, decided by policy — no longer open to the domain.',
    retention: '7 years post-closure'
  };

  /* What the pipeline actually delivers. The owner's promise is checked against
     these, so an over-tight promise breaches on the day it is signed. */
  var ACTUAL = { freshness: 4.2, completeness: 99.6 };

  /* The datasets offered for the product. Five belong. The last two are the point
     of the screen, and they fail in two genuinely different ways:

       'ownership' — mechanically impossible. A data product is a bundle somebody
                     is accountable for, and nobody can be accountable for data
                     another domain owns. The platform can check this, because
                     ownership is recorded rather than argued about.

       'inherit'   — perfectly possible, and expensive. Nothing stops the owner
                     including it; what it does is spread obligations across every
                     consumer of the product, and the platform's job is to price
                     that before the decision rather than forbid it.

     A rule that simply banned a dataset for being "the wrong sort" would be
     neither, and would teach an executive something false about how governance
     works. */
  var CANDIDATES = [
    { name: 'Customer 360 Profile', urn: PRODUCT.flagship, flagship: true,
      grain: 'One row per customer', rows: '24.6M', pii: true, belongs: true },
    { name: 'Customer Master', urn: 'enterprise.customer.customer_master',
      grain: 'One row per customer', rows: '4.1M', pii: true, belongs: true },
    { name: 'Account & Balance Daily', urn: 'enterprise.deposits.account_balance_daily',
      grain: 'One row per account per day', rows: '312M', pii: true, belongs: true },
    { name: 'Channel Interaction Events', urn: 'enterprise.digital.channel_events',
      grain: 'One row per digital interaction', rows: '1.4B', pii: true, belongs: true },
    { name: 'Attrition Outcomes', urn: 'enterprise.customer.attrition_outcomes',
      grain: 'One row per customer per month', rows: '4.1M', belongs: true },
    { name: 'Credit Bureau Scores', urn: 'enterprise.risk.credit_bureau_scores',
      grain: 'One row per customer', rows: '3.8M', pii: true, verdict: 'ownership',
      head: 'Credit Bureau Scores belongs to Risk',
      why: 'A product bundles what its owner is accountable for, and Marc is not accountable for ' +
        'Risk\'s data. It can be referenced from Risk\'s own product; it cannot be absorbed into ' +
        'this one.' },
    { name: 'Marketing Campaign Responses', urn: 'enterprise.marketing.campaign_responses',
      grain: 'One row per contact', rows: '22M', pii: true, verdict: 'inherit',
      head: 'Marketing Campaign Responses spreads consent rules across the product',
      why: 'Marc does own it. Adding it applies marketing consent checks to every dataset in the ' +
        'product — all 41 consuming teams inherit them.' }
  ];
  var BELONGS = CANDIDATES.filter(function (c) { return c.belongs; }).length;


  /* =======================================================================
     PHYSICAL STRUCTURE — what each dataset actually is on the platform.

     Deliberately close to what BigQuery reports, because that is what an owner
     is really looking at: storage kind, partitioning and clustering, keys, row
     and byte counts, expirations, labels, and a column list carrying mode,
     policy tag, null share and approximate cardinality.

     Two things here are load-bearing rather than decoration:

       - The eleven columns of Customer 360 Profile are the eleven columns in
         analyst-journey.js, with the same types, policy tags and descriptions.
         This screen is the owner's view of the object the analyst later queries.
       - Column-level access in BigQuery is enforced by policy tag, so the PG-*
         values are not an invention of this mock: they are the mechanism, and
         they arrive from the sensitivity classification on the Overview tab.
     ==================================================================== */

  var SCHEMAS = {
    'Customer 360 Profile': {
      physical: 'scotia-prod-data.enterprise_customer.customer_360_profile',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '24,612,884', size: '342 GB', modified: '2026-08-15 02:14 ET',
      partition: 'DATE(updated_at) · daily · 2,555 partitions · filter required',
      cluster: 'customer_id, segment_code',
      expiry: 'Partition expiry 2,555 days · table never expires',
      labels: ['tier', 'tier-1'], owner: 'Marc Deschamps',
      pk: 'customer_id',
      fk: [['segment_code', 'reference.segment_codes.segment_cd'],
        ['attrition_reason_cd', 'reference.attrition_reason_codes.reason_cd']],
      cols: [
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '0%', card: '24.6M',
          d: 'Enterprise customer identifier (CIF). Surrogate key issued by the Customer Data Hub at onboarding.' },
        { n: 'sin_hash', t: 'STRING', m: 'NULLABLE', pii: true, pg: 'PG-PII-RES-09',
          nulls: '0.4%', card: '24.5M',
          d: 'SHA-256 of Social Insurance Number with enterprise pepper. Never reversible; cross-system join only.' },
        { n: 'full_name', t: 'STRING', m: 'REQUIRED', pii: true, pg: 'PG-PII-RES-04',
          nulls: '0%', card: '21.9M',
          d: 'Legal name as captured during KYC, with preferred-name overlay where expressed.' },
        { n: 'date_of_birth', t: 'DATE', m: 'REQUIRED', pii: true, pg: 'PG-PII-RES-04',
          nulls: '0%', card: '26,481',
          d: 'Date of birth from KYC. Masked to year-only for analytics roles.' },
        { n: 'segment_code', t: 'STRING', m: 'NULLABLE', key: 'FK', pg: 'PG-CUST-INT-02',
          nulls: '1.2%', card: '14',
          d: 'Marketing segment assigned quarterly by the segmentation model.' },
        { n: 'tenure_months', t: 'INT64', m: 'REQUIRED', pg: 'PG-CUST-INT-02',
          term: 'Tenure Band', nulls: '0%', card: '612',
          d: 'Months since the customer opened their first product with the bank.' },
        { n: 'attrition_reason_cd', t: 'STRING', m: 'NULLABLE', key: 'FK', coded: true,
          pg: 'PG-CUST-INT-02', term: 'Attrition (Retail)', nulls: '91.4%', card: '7',
          d: 'Coded reason recorded at closure. Null for every customer still with the bank; decodes via reference.attrition_reason_codes.' },
        { n: 'product_holdings_count', t: 'INT64', m: 'REQUIRED', pg: 'PG-CUST-INT-02',
          term: 'Product Holding', nulls: '0%', card: '19',
          d: 'Count of open products held at the as-of date.' },
        { n: 'is_scene_member', t: 'BOOL', m: 'REQUIRED', pg: 'PG-CUST-INT-02',
          nulls: '0%', card: '2', d: 'Whether the customer is enrolled in Scene+.' },
        { n: 'last_login_ts', t: 'TIMESTAMP', m: 'NULLABLE', pg: 'PG-CUST-INT-02',
          nulls: '8.7%', card: '22.1M',
          d: 'Most recent authenticated digital session. Null for customers who have never used a digital channel.' },
        { n: 'updated_at', t: 'TIMESTAMP', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '2,555',
          d: 'Row last-modified timestamp from the curation job. Partition key.' }
      ]
    },

    'Customer Master': {
      physical: 'scotia-prod-data.enterprise_customer.customer_master',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '4,118,442', size: '61 GB', modified: '2026-08-15 01:40 ET',
      partition: 'None · full refresh nightly', cluster: 'customer_id',
      expiry: 'Never expires', labels: ['tier', 'tier-1'], owner: 'Marc Deschamps',
      pk: 'customer_id', fk: [['country_cd', 'reference.country_codes.country_cd']],
      cols: [
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '0%', card: '4.1M', d: 'Enterprise customer identifier (CIF).' },
        { n: 'cif_open_dt', t: 'DATE', m: 'REQUIRED', pg: 'PG-CUST-INT-02',
          nulls: '0%', card: '14,602', d: 'Date the customer relationship was opened.' },
        { n: 'kyc_status_cd', t: 'STRING', m: 'REQUIRED', coded: true, pg: 'PG-CUST-RES-01',
          nulls: '0%', card: '5', d: 'Know-your-customer verification state.' },
        { n: 'primary_branch_cd', t: 'STRING', m: 'NULLABLE', key: 'FK', coded: true,
          pg: 'PG-CUST-INT-02', nulls: '3.1%', card: '941', d: 'Branch of record.' },
        { n: 'country_cd', t: 'STRING', m: 'REQUIRED', key: 'FK', coded: true,
          pg: 'PG-CUST-INT-02', nulls: '0%', card: '112',
          d: 'Country of residence. ISO 3166 alpha-2.' }
      ]
    },

    'Account & Balance Daily': {
      physical: 'scotia-prod-data.enterprise_deposits.account_balance_daily',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '312,004,911', size: '2.9 TB', modified: '2026-08-15 02:02 ET',
      partition: 'as_of_dt · daily · 1,096 partitions · filter required',
      cluster: 'customer_id, product_cd',
      expiry: 'Partition expiry 1,096 days', labels: ['tier', 'tier-1'], owner: 'Marc Deschamps',
      pk: 'account_id, as_of_dt',
      fk: [['customer_id', 'enterprise.customer.customer_master.customer_id'],
        ['product_cd', 'reference.product_codes.product_cd']],
      cols: [
        { n: 'account_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-CUST-RES-01',
          nulls: '0%', card: '9.4M', d: 'Account identifier. Unique with as_of_dt.' },
        { n: 'as_of_dt', t: 'DATE', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '1,096', d: 'Close-of-business date. Partition key.' },
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'FK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '0%', card: '4.1M', d: 'Owning customer.' },
        { n: 'product_cd', t: 'STRING', m: 'REQUIRED', key: 'FK', coded: true,
          pg: 'PG-CUST-INT-02', nulls: '0%', card: '84', d: 'Product held on the account.' },
        { n: 'balance_cad', t: 'NUMERIC(18, 2)', m: 'REQUIRED', pg: 'PG-CUST-RES-01',
          nulls: '0%', card: '188M', d: 'End-of-day balance, Canadian dollars.' },
        { n: 'legacy_status_cd', t: 'STRING', m: 'NULLABLE', coded: true, gap: true,
          pg: 'PG-CUST-INT-02', nulls: '46.9%', card: '23',
          d: 'Status code inherited from the deposits legacy core. No reference set decodes it.' }
      ]
    },

    'Channel Interaction Events': {
      physical: 'scotia-prod-data.enterprise_digital.channel_events',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '1,412,880,364', size: '18.4 TB', modified: '2026-08-15 02:11 ET',
      partition: 'DATE(event_ts) · daily · 730 partitions · filter required',
      cluster: 'customer_id, channel_cd',
      expiry: 'Partition expiry 730 days', labels: ['tier', 'tier-2'], owner: 'Marc Deschamps',
      pk: 'event_id', fk: [['customer_id', 'enterprise.customer.customer_master.customer_id']],
      cols: [
        { n: 'event_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '1.4B', d: 'Event identifier, UUID v4.' },
        { n: 'event_ts', t: 'TIMESTAMP', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '1.4B', d: 'When the interaction happened. Partition key.' },
        { n: 'customer_id', t: 'STRING', m: 'NULLABLE', key: 'FK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '22.4%', card: '19.8M',
          d: 'Null for unauthenticated sessions, which is most of the traffic.' },
        { n: 'channel_cd', t: 'STRING', m: 'REQUIRED', coded: true, pg: 'PG-CUST-INT-02',
          nulls: '0%', card: '6', d: 'App, web, ATM, branch, phone or chat.' },
        { n: 'event_type_cd', t: 'STRING', m: 'REQUIRED', coded: true, pg: 'PG-CUST-INT-02',
          nulls: '0%', card: '214', d: 'What the customer did.' }
      ]
    },

    'Attrition Outcomes': {
      physical: 'scotia-prod-data.enterprise_customer.attrition_outcomes',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '4,118,442', size: '9 GB', modified: '2026-08-15 02:08 ET',
      partition: 'as_of_month · monthly · 84 partitions', cluster: 'customer_id',
      expiry: 'Never expires', labels: ['tier', 'tier-1'], owner: 'Marc Deschamps',
      pk: 'customer_id, as_of_month',
      fk: [['attrition_reason_cd', 'reference.attrition_reason_codes.reason_cd']],
      cols: [
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '0%', card: '4.1M', d: 'Enterprise customer identifier.' },
        { n: 'as_of_month', t: 'DATE', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '84', d: 'Month the outcome was assessed. Partition key.' },
        { n: 'attrition_flag', t: 'BOOL', m: 'REQUIRED', pg: 'PG-CUST-INT-02',
          term: 'Attrition (Retail)', nulls: '0%', card: '2',
          d: 'Whether the relationship ended in this month, on the agreed definition.' },
        { n: 'CUST_ATTR_FLG_3', t: 'STRING', m: 'NULLABLE', key: 'FK', coded: true,
          pg: 'PG-CUST-INT-02', nulls: '91.4%', card: '7',
          d: 'Source-system name for the coded closure reason. Curated into customer_360_profile as attrition_reason_cd.' },
        { n: 'closed_dt', t: 'DATE', m: 'NULLABLE', pg: 'PG-CUST-INT-02',
          nulls: '91.4%', card: '3,102', d: 'Date the last account closed.' }
      ]
    },

    'Credit Bureau Scores': {
      physical: 'scotia-prod-data.enterprise_risk.credit_bureau_scores',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '3,844,201', size: '14 GB', modified: '2026-08-14 23:50 ET',
      partition: 'scored_dt · monthly · 96 partitions', cluster: 'customer_id',
      expiry: 'Partition expiry 2,920 days', labels: ['tier', 'tier-1'],
      owner: 'Idris Haddad · VP, Credit Risk',
      pk: 'customer_id, bureau_cd, scored_dt', fk: [],
      cols: [
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-RISK-RES-01',
          nulls: '0%', card: '3.8M', d: 'Enterprise customer identifier.' },
        { n: 'bureau_cd', t: 'STRING', m: 'REQUIRED', key: 'PK', coded: true, pg: 'PG-RISK-RES-01',
          nulls: '0%', card: '2', d: 'Which bureau supplied the score.' },
        { n: 'score', t: 'INT64', m: 'REQUIRED', pii: true, pg: 'PG-RISK-RES-01',
          nulls: '0%', card: '551', d: 'Bureau score, 300–900.' },
        { n: 'scored_dt', t: 'DATE', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '96', d: 'Month the score was pulled. Partition key.' }
      ]
    },

    'Marketing Campaign Responses': {
      physical: 'scotia-prod-data.enterprise_marketing.campaign_responses',
      kind: 'Managed table', region: 'northamerica-northeast2',
      rows: '22,048,190', size: '48 GB', modified: '2026-08-14 22:15 ET',
      partition: 'DATE(contacted_ts) · daily · 1,460 partitions', cluster: 'campaign_id',
      expiry: 'Partition expiry 1,460 days', labels: ['tier', 'tier-2'], owner: 'Marc Deschamps',
      pk: 'contact_id', fk: [['customer_id', 'enterprise.customer.customer_master.customer_id']],
      cols: [
        { n: 'contact_id', t: 'STRING', m: 'REQUIRED', key: 'PK', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '22.0M', d: 'One row per contact attempt.' },
        { n: 'customer_id', t: 'STRING', m: 'REQUIRED', key: 'FK', pg: 'PG-CUST-RES-01',
          term: 'Customer', nulls: '0%', card: '6.7M', d: 'Customer contacted.' },
        { n: 'campaign_id', t: 'STRING', m: 'REQUIRED', pg: 'PG-MKTG-INT-03',
          nulls: '0%', card: '1,884', d: 'Campaign the contact belonged to.' },
        { n: 'contacted_ts', t: 'TIMESTAMP', m: 'REQUIRED', key: 'PART', pg: 'PG-META-PUB-01',
          nulls: '0%', card: '22.0M', d: 'When the contact was made. Partition key.' },
        { n: 'response_cd', t: 'STRING', m: 'NULLABLE', coded: true, pg: 'PG-MKTG-INT-03',
          nulls: '73.8%', card: '9', d: 'How the customer responded, if at all.' },
        { n: 'consent_flag', t: 'BOOL', m: 'REQUIRED', pg: 'PG-MKTG-CON-01',
          nulls: '0%', card: '2',
          d: 'Active marketing consent at the time of contact. The rule that travels with this dataset.' }
      ]
    }
  };

  /* The minimum metadata standard the steward published. Three of the seven are
     the owner's to supply at registration; the rest are earned later. */
  var REQUIREMENTS = [
    { id: 'desc', name: 'Plain-English description', short: 'a description', plain: 'What this is, in a sentence a non-specialist understands.', at: 3 },
    { id: 'owner', name: 'Named data owner', short: 'an owner', plain: 'A person, not a team mailbox.', at: 3 },
    { id: 'class', name: 'Sensitivity classification', short: 'a classification', plain: 'So the platform knows what to protect.', at: 3 },
    { id: 'terms', name: 'Business glossary terms mapped', short: 'terms', plain: 'Every key element means one agreed thing.', at: 4 },
    { id: 'contract', name: 'Data contract with an SLA', short: 'a contract', plain: 'A promise about freshness and completeness.', at: 4 },
    { id: 'lineage', name: 'Lineage traced to source', short: 'lineage', plain: 'Where the numbers came from, end to end.', at: 5 },
    { id: 'obligations', name: 'Usage obligations attached', short: 'obligations', plain: 'What you are and are not allowed to do with it.', at: 5 }
  ];
  var AT_REGISTRATION = ['desc', 'owner', 'class'];
  var SUPPLIED_VALUES = {
    desc: 'A single, complete view of every retail customer relationship.',
    owner: OWNER.name + ' — ' + OWNER.role,
    class: 'Restricted · applied automatically from 3 personal-data elements'
  };

  /* Source fields waiting to be given a business meaning. A term attaches to a
     logical data element, which lives inside a dataset — so each row names the
     dataset it belongs to. These four are exactly the four glossary terms the
     steward's certification counts on Customer 360 Profile. */
  var DS = 'Customer 360 Profile';
  var MAPPINGS = [
    { field: 'CIF_CUST_ID', ds: DS, term: 'Customer', el: 'customer_id' },
    { field: 'CUST_TEN_MTH', ds: DS, term: 'Tenure Band', el: 'tenure_months' },
    { field: 'CUST_ATTR_FLG_3', ds: DS, term: 'Attrition (Retail)', el: 'attrition_reason_cd' },
    { field: 'PRD_HLD_CNT', ds: DS, term: 'Product Holding', el: 'product_holdings_count' }
  ];

  /* The one coded element in the product, and the steward's set that decodes it.
     This single link is why the assistant in analyst-journey.html can offer its
     join — and why the board pack reads "Moved to competitor", not "R01". */
  var CODED = {
    el: 'attrition_reason_cd', ds: DS, ref: 'reference.attrition_reason_codes',
    name: 'Attrition Reason Codes', codes: 7, access: 'Open to all staff',
    sample: [['R01', 'Moved to competitor'], ['R02', 'Rate dissatisfaction'],
      ['R03', 'Service complaint']]
  };

  /* An element that cannot be published with the product, because nothing in the
     glossary says what its values mean. It is held back rather than shipped as a
     column nobody can read. */
  var CODE_GAP = {
    el: 'legacy_status_cd', ds: 'Account & Balance Daily',
    why: 'No reference set exists, and nobody left can say what its values mean.'
  };

  /* The two dials an owner actually sets. Everything else in a contract is
     inherited from the tier; these are the promise. */
  var LEVERS = [
    { id: 'freshness', label: 'Freshness', min: 4, max: 48, step: 4,
      low: 'No older than 4h', high: 'No older than 48h',
      plain: 'How old the data may be before the owner has broken their promise.' },
    { id: 'completeness', label: 'Completeness floor', min: 90, max: 100, step: 1,
      low: '90% of expected records', high: '100% of expected records',
      plain: 'How much of the expected data must arrive before it counts as delivered.' }
  ];
  function levelText(id, v) { return id === 'freshness' ? v + 'h' : v + '%'; }

  /* The owner's estate — data products. DP-0142 is the one worked in this tour;
     the rest are the honest remainder, and two are blocked on engineering rather
     than on him. */
  var ESTATE = [
    { id: PRODUCT.id, name: PRODUCT.name, story: true, datasets: 5,
      missing: ['terms', 'contract', 'lineage', 'obligations'],
      note: 'Tables for years; never a described product.' },
    { id: 'DP-0244', name: 'Product Holdings & Pricing', datasets: 3,
      missing: ['lineage'], note: 'Two source systems still connected by hand.' },
    { id: 'DP-0318', name: 'Retail Deposits', datasets: 4,
      missing: ['contract', 'lineage'], note: 'No service commitment agreed with consumers yet.' },
    { id: 'DP-0402', name: 'Branch Operations', datasets: 2,
      missing: ['terms', 'contract', 'lineage'], note: 'Built for a one-off review in 2024, never uplifted.' }
  ];

  var RAIL = [
    ['box', 'Data Products', '412', 'rail-products', 'product'],
    ['db', 'Datasets', '3,089', 'rail-datasets', null],
    ['book', 'Glossary Terms', '218', 'rail-glossary', null],
    ['hash', 'Reference Sets', '39', 'rail-refs', null],
    ['grid', 'Domains', '8', 'rail-domains', null]
  ];


  /* =======================================================================
     THE TOUR — every line of journey narration lives here and nowhere else.

     Each step names the product state it needs, so the tour drives the
     prototype rather than the prototype knowing about the tour.
     ==================================================================== */

  var ALL_INCLUDED = CANDIDATES.filter(function (c) { return c.belongs; })
    .map(function (c) { return c.name; });
  var ALL_MAPPED = MAPPINGS.map(function (m) { return m.field; });

  var TOUR = [
    {
      target: 'body', placement: 'center',
      state: { screen: 'estate', registered: false, published: false },
      title: 'Accountable, not consulted',
      body: 'Marc runs Retail Deposits. He is not a data person, and he is <b>accountable</b> for ' +
        'these four data products — a different job from being asked about them. Every one has ' +
        'been scored against the standard the steward published.',
      key: 'Journey step 9 · the owner\'s estate'
    },
    {
      target: '#reg-form', placement: 'bottom',
      state: { screen: 'product', tab: 'overview', purposed: false },
      title: 'A product, not a database',
      body: 'A reference, a version, and somebody accountable. The tables existed for years; what ' +
        'did not exist was anyone who owned them.',
      key: 'Journey step 3 · register the data product'
    },
    {
      target: '#classification', placement: 'bottom',
      state: { screen: 'product', tab: 'overview', purposed: true },
      title: 'The data classifies itself',
      body: 'Three elements are personal data, so the product is Restricted and three protection ' +
        'groups attach. Marc is told, not asked — these are the rules the analyst meets later.',
      key: 'Journey step 3 · sensitivity classification'
    },
    {
      target: '#datasets', placement: 'bottom',
      state: { screen: 'product', tab: 'datasets', purposed: true,
        included: ALL_INCLUDED, rejected: 'Marketing Campaign Responses', overridden: false },
      title: 'One cannot go in. The other costs',
      body: 'Credit Bureau Scores is Risk\'s — nobody can be accountable for another domain\'s ' +
        'data. Campaign Responses is his, and expensive: the platform prices it.',
      key: 'Journey step 3 · add logical datasets'
    },
    {
      target: '#gate', placement: 'bottom',
      state: { screen: 'product', tab: 'gov', included: ALL_INCLUDED,
        supplied: AT_REGISTRATION.slice(), registered: false },
      title: 'The policy is the gate',
      body: 'It will not go live until the metadata it <b>can</b> have today is present. Nobody is ' +
        'asked for lineage yet — that is engineering\'s, later.',
      key: 'Journey step 3 · meet the minimum standard'
    },
    {
      target: '#ownership', placement: 'bottom',
      state: { screen: 'product', tab: 'gov', supplied: AT_REGISTRATION.slice(), registered: true },
      title: 'The one field that cannot be delegated',
      body: 'Marc owns it and Aisha stewards it. Everything else on this page can be fixed later; ' +
        'without this, there is nobody to ask.',
      key: 'Journey step 3 · confirm ownership'
    },
    {
      target: '#map-terms', placement: 'bottom',
      state: { screen: 'product', tab: 'glossary', registered: true, mapped: ALL_MAPPED, linked: false },
      title: 'CUST_ATTR_FLG_3 means nothing to a board',
      body: '<b>Attrition (Retail)</b> does — and the steward already agreed it. A term attaches ' +
        'to an element inside a dataset, so each row names both.',
      key: 'Journey step 4 · map terms to logical data elements'
    },
    {
      target: '#map-refs', placement: 'bottom',
      state: { screen: 'product', tab: 'glossary', registered: true, mapped: ALL_MAPPED, linked: true },
      title: 'The single most valuable click in this prototype',
      body: 'One coded element, linked to the steward\'s set. This is the entire reason the ' +
        'assistant can offer that join later. Without it, the board pack reads R01.',
      key: 'Journey step 4 · link the coded element'
    },
    {
      target: '#map-gap', placement: 'bottom',
      state: { screen: 'product', tab: 'glossary', registered: true, mapped: ALL_MAPPED, linked: true },
      title: 'And one element nobody can explain',
      body: 'Nothing in the glossary says what its values mean, so it is held back until the ' +
        'steward creates a set — rather than shipping a column no one can read.',
      key: 'Journey step 4 · request a code set'
    },
    {
      target: '#levers', placement: 'bottom',
      state: { screen: 'product', tab: 'contract', registered: true, mapped: ALL_MAPPED,
        linked: true, freshness: 24, completeness: 99, published: false },
      title: 'Two dials, and they are a promise',
      body: 'Not a target and not an aspiration — a commitment to everyone downstream. Drag them: ' +
        'tighter promises cost more to keep.',
      key: 'Journey step 4 · define service expectations'
    },
    {
      target: '#breach', placement: 'bottom',
      state: { screen: 'product', tab: 'contract', freshness: 4, completeness: 100, published: false },
      title: 'Promise more than you deliver, and you breach on day one',
      body: 'The pipeline delivers ' + ACTUAL.freshness + 'h and ' + ACTUAL.completeness + '%. ' +
        'The platform will not publish a promise it can already see being broken.',
      key: 'Journey step 4 · establish the SLA'
    },
    {
      target: '#contract', placement: 'bottom',
      state: { screen: 'product', tab: 'contract', freshness: 12, completeness: 99, published: true },
      title: 'Signed, and now measurable',
      body: 'The quality score the analyst reads is measured against exactly this. A number with ' +
        'nothing behind it is a decoration.',
      key: 'Journey step 4 · publish the data contract'
    },
    {
      target: '#estate', placement: 'bottom',
      state: { screen: 'estate', registered: true, published: true, mapped: ALL_MAPPED, linked: true },
      title: 'Five of seven, and the rest is not his',
      body: 'Lineage and usage obligations are engineering\'s. The report names the gap per ' +
        'product rather than telling him to improve his metadata — the difference between a ' +
        'scoreboard and a to-do list.',
      key: 'Journey step 9 → the steward certifies, then the analyst uses it'
    }
  ];

  var STATE_KEYS = ['screen', 'tab', 'purposed', 'included', 'rejected', 'overridden', 'supplied',
    'registered', 'mapped', 'linked', 'freshness', 'completeness', 'published'];


  /* =======================================================================
     SCREEN CONTENT — product copy only. If a sentence explains why the
     product is good, it belongs in TOUR, not here.
     ==================================================================== */

  function pill(kind, label, icon) {
    return '<span class="pill pill--' + kind + '">' + (icon ? ic(icon, 11) : '') + esc(label) + '</span>';
  }
  function chips(list, kind) {
    return list.map(function (t) { return '<span class="chip chip--' + kind + '">' + esc(t) + '</span>'; }).join('');
  }
  function person(p, kind) {
    return '<div class="dh-owner"><i>' + esc(p.initials) + '</i><div><b>' + esc(p.name) + '</b>' +
      '<span>' + esc(kind ? kind + ' · ' + p.role : p.role) + '</span></div></div>';
  }
  function banner(kind, icon, title, body) {
    return '<div class="alert alert--' + kind + '"><i>' + ic(icon, 13) + '</i>' +
      '<div><b>' + esc(title) + '</b><p>' + esc(body) + '</p></div></div>';
  }
  function fld(label, value) {
    return '<div class="fld"><span class="fld-l">' + esc(label) + '</span>' +
      '<span class="fld-v">' + esc(value) + '</span></div>';
  }
  function has(list, v) { return (list || []).indexOf(v) !== -1; }
  /* an element lives inside a dataset — naming both is the whole reason this
     screen can sit at product level without lying about where a term attaches */
  function elemRef(el, ds) {
    return '<span class="map-f"><code>' + esc(el) + '</code>' +
      '<span class="map-ds">' + esc(ds) + '</span></span>';
  }

  /* the entity header every screen wears — kept in one place so the screens
     cannot drift apart */
  function ehead(o) {
    return '<div class="dh-crumb">' + o.crumb.map(function (c) {
        /* a crumb is either plain text or [label, act, arg] — the dataset detail
           needs a way back to the product it was opened from */
        return typeof c === 'string' ? esc(c)
          : '<button class="crumb-link" data-act="' + c[1] + '"' +
            (c[2] ? ' data-arg="' + esc(c[2]) + '"' : '') + '>' + esc(c[0]) + '</button>';
      }).join('<span class="sep">›</span>') + '</div>' +
      '<div class="dh-ehead"><div class="dh-etitle">' +
      '<span class="dh-glyph dh-glyph--' + o.glyph[0] + '">' + esc(o.glyph[1]) + '</span>' +
      '<h1>' + esc(o.title) + '</h1>' + (o.badges || []).join('') + '</div>' +
      (o.urn ? '<div class="dh-eurn">' + esc(o.urn) + '</div>' : '') +
      (o.desc ? '<div class="dh-edesc">' + esc(o.desc) + '</div>' : '') +
      (o.tabs
        ? '<div class="dh-tabs">' + o.tabs.map(function (t) {
            return '<button class="dh-tab' + (t[0] === o.tab ? ' on' : '') + '" data-act="' +
              (o.act || 'tab') + '" data-arg="' + t[0] + '">' + esc(t[1]) + '</button>';
          }).join('') + '</div>'
        : '<div class="dh-ehead-pad"></div>') + '</div>';
  }
  function wrap(head, body) { return head + '<div class="dh-content">' + body + '</div>'; }

  /* --- how far this product has got against the seven ---------------------- */
  function metNow(st) {
    var met = st.registered ? AT_REGISTRATION.slice() : [];
    /* the requirement needs both halves: terms on the elements that carry them,
       and the coded element pointed at the set that decodes it */
    if (st.mapped.length === MAPPINGS.length && st.linked) met.push('terms');
    if (st.published) met.push('contract');
    return met;
  }
  function shortName(id) {
    var r = REQUIREMENTS.filter(function (x) { return x.id === id; })[0];
    return r ? r.short : id;
  }
  /* every requirement still outstanding across the owner's four products */
  function openGaps(st) {
    return ESTATE.reduce(function (n, d) {
      return n + (d.story ? REQUIREMENTS.length - metNow(st).length : d.missing.length);
    }, 0);
  }

  /* --- the estate, before and after --------------------------------------- */
  function estateRows(st, after) {
    return ESTATE.map(function (d) {
      var missing = d.story && after
        ? REQUIREMENTS.filter(function (r) { return metNow(st).indexOf(r.id) === -1; })
            .map(function (r) { return r.id; })
        : d.missing;
      var met = REQUIREMENTS.length - missing.length;
      return '<button class="gl-row" data-act="open" data-arg="' + esc(d.id) + '">' +
        '<div><div class="gl-n">' + esc(d.name) +
        pill(met >= 5 ? 'ok' : met >= 4 ? 'warn' : 'bad', met + ' of 7') +
        (d.story && after ? pill('info', 'worked today') : '') + '</div>' +
        '<div class="gl-d">' + esc(d.id) + ' · ' + d.datasets + ' datasets · missing ' +
        missing.map(shortName).join(', ') + (after ? '' : ' — ' + esc(d.note)) + '</div></div>' +
        '<div class="gl-r"><b>' + met + '/7</b>' + (d.story ? 'open it' : 'later') + '</div></button>';
    }).join('');
  }

  function viewEstate(st) {
    var worked = st.registered || st.published;
    var met = metNow(st).length;
    return wrap(ehead({
      crumb: ['Catalog', 'Data Products', 'Owned by ' + OWNER.name], glyph: ['ds', 'MD'],
      title: 'My data products', urn: 'owner:marc.deschamps',
      desc: 'Every tier 1 data product this owner is accountable for, scored against the ' +
        'seven-point minimum metadata standard.',
      badges: [worked ? pill(met >= 5 ? 'ok' : 'warn', PRODUCT.id + ' · ' + met + ' of 7', 'check')
        : pill('warn', '4 below the standard', 'warn')],
      tabs: [['mine', 'My products'], ['report', 'Estate report']],
      tab: worked ? 'report' : 'mine', act: 'noop'
    }),
      /* bare rows, not wrapped in a panel — they are already self-contained
         cards, and a panel wrapper costs the tour tooltip its headroom */
      '<div id="estate">' + estateRows(st, worked) + '</div>' +
      (worked
        ? '<div class="panel"><div class="panel-h">What happens to ' + esc(PRODUCT.id) +
          ' next</div><dl class="kv">' +
          '<dt>Engineering</dt><dd>Lineage and usage obligations — the last two requirements</dd>' +
          '<dt>Steward</dt><dd>' + esc(STEWARD.name) + ' certifies <span class="mono">' +
          esc(PRODUCT.flagship) + '</span> once all seven are met</dd>' +
          '<dt>Then</dt><dd>It appears in the marketplace, and an analyst can find it without ' +
          'knowing it exists</dd></dl></div>'
        : '<p class="muted" style="font-size:12px;margin-top:10px">Two of these gaps are lineage, ' +
          'which is engineering work rather than the owner\'s. The report knows the difference.</p>'));
  }


  /* --- a dataset inside the product, as the platform actually holds it ----- */
  function viewDsDetail(st) {
    var c = CANDIDATES.filter(function (x) { return x.name === st.openDs; })[0] || CANDIDATES[0];
    var sc = SCHEMAS[c.name];
    var foreign = c.verdict === 'ownership';

    return wrap(ehead({
      crumb: ['Catalog', ['Data Products', 'tab', 'datasets'], [PRODUCT.name, 'tab', 'datasets'],
        c.name],
      glyph: ['ds', 'BQ'], title: c.name, urn: sc.physical,
      badges: [pill('info', sc.kind),
        foreign ? pill('bad', 'Owned by Risk', 'lock') : pill('ok', 'In this product', 'check'),
        c.pii ? pill('bad', 'PII', 'lock') : ''].filter(Boolean),
      tabs: null
    }),
      '<div class="panel" id="ds-props"><div class="panel-h">Table properties</div>' +
      '<dl class="kv">' +
      '<dt>Type</dt><dd>' + esc(sc.kind) + ' · ' + esc(sc.region) + '</dd>' +
      '<dt>Grain</dt><dd>' + esc(c.grain) + '</dd>' +
      '<dt>Rows</dt><dd class="mono">' + esc(sc.rows) + '</dd>' +
      '<dt>Storage</dt><dd class="mono">' + esc(sc.size) + '</dd>' +
      '<dt>Partitioning</dt><dd class="mono">' + esc(sc.partition) + '</dd>' +
      '<dt>Clustering</dt><dd class="mono">' + esc(sc.cluster) + '</dd>' +
      '<dt>Primary key</dt><dd class="mono">' + esc(sc.pk) + '</dd>' +
      (sc.fk.length
        ? '<dt>Foreign keys</dt><dd>' + sc.fk.map(function (f) {
            return '<span class="mono">' + esc(f[0]) + '</span> → <span class="mono">' +
              esc(f[1]) + '</span>';
          }).join('<br>') + '</dd>'
        : '') +
      '<dt>Expiration</dt><dd>' + esc(sc.expiry) + '</dd>' +
      '<dt>Last modified</dt><dd>' + esc(sc.modified) + '</dd>' +
      '<dt>Owner</dt><dd>' + esc(sc.owner) + '</dd>' +
      '<dt>Labels</dt><dd class="mono">' + esc(sc.labels.join(':')) + '</dd>' +
      '</dl></div>' +

      '<div class="panel" id="ds-schema" style="padding:0">' +
      '<div class="tbl-x"><table class="tbl"><thead><tr>' +
      '<th>Column</th><th>Type</th><th>Policy tag</th><th>Description</th>' +
      '</tr></thead><tbody>' +
      sc.cols.map(function (col) {
        return '<tr><td><code>' + esc(col.n) + '</code>' +
          (col.key ? ' <span class="chip">' + esc(col.key) + '</span>' : '') +
          (col.pii ? ' ' + pill('bad', 'PII', 'lock') : '') +
          (col.coded ? ' ' + pill('warn', 'coded', 'warn') : '') +
          (col.term ? ' <span class="chip chip--term">' + esc(col.term) + '</span>' : '') +
          '<div class="col-sub">' + esc(col.m) + ' · ' + esc(col.nulls) + ' null · ' +
          esc(col.card) + ' distinct</div></td>' +
          '<td class="mono">' + esc(col.t) + '</td>' +
          '<td class="mono pt">' + esc(col.pg) + '</td>' +
          '<td class="muted">' + esc(col.d) +
          (col.gap ? ' <b style="color:var(--warn)">Held back from publication.</b>' : '') +
          '</td></tr>';
      }).join('') + '</tbody></table></div></div>' +

      '<div class="panel"><div class="panel-h">How to read this</div>' +
      '<p class="muted" style="font-size:12.5px">Column-level access is enforced by <b>policy ' +
      'tag</b>, and the tags come from the sensitivity classification on the product — nobody ' +
      'sets them by hand. A glossary term on a column is the owner\'s mapping; a coded column ' +
      'needs a reference set before anyone can read it.</p></div>' +

      '<div class="acts"><button class="btn" data-act="tab" data-arg="datasets">' +
      'Back to ' + esc(PRODUCT.id) + '</button>' +
      '<span class="muted">' + sc.cols.length + ' columns · ' + esc(sc.rows) + ' rows</span></div>');
  }

  /* --- the data product entity page --------------------------------------- */
  function viewProduct(st) {
    var tabs = [['overview', 'Overview'], ['datasets', 'Datasets'], ['glossary', 'Glossary'],
      ['contract', 'Contract'], ['gov', 'Governance']];
    var tab = ['overview', 'datasets', 'glossary', 'contract', 'gov'].indexOf(st.tab) === -1
      ? 'overview' : st.tab;
    var body = tab === 'datasets' ? tabDatasets(st) : tab === 'glossary' ? tabGlossary(st)
      : tab === 'contract' ? tabContract(st) : tab === 'gov' ? tabGov(st) : tabOverview(st);
    var met = metNow(st).length;

    return wrap(ehead({
      crumb: ['Catalog', 'Data Products', PRODUCT.name], glyph: ['ds', 'DP'],
      title: PRODUCT.name, urn: PRODUCT.urn,
      badges: [pill('info', PRODUCT.id),
        st.published ? pill('ok', 'Contracted', 'check')
          : st.registered ? pill('ok', 'Registered', 'check') : pill('draft', 'Draft'),
        pill(met >= 5 ? 'ok' : 'warn', met + ' of 7 met')],
      tabs: tabs, tab: tab
    }), body);
  }

  function tabOverview(st) {
    return '<div class="panel" id="reg-form"><div class="panel-h">Data product</div>' +
      fld('Product name', PRODUCT.name) +
      fld('Reference', PRODUCT.id) +
      fld('Domain', PRODUCT.domain) +
      fld('Version', PRODUCT.version) +
      fld('Accountable', OWNER.name + ' · ' + OWNER.role) +
      '</div>' +

      /* Shown from the moment the product exists, and never gated on anything the
         owner does: the data is sensitive whether or not he has got round to
         describing it. */
      '<div class="panel" id="classification">' +
      '<div class="panel-h">Sensitivity classification · applied automatically</div>' +
      '<div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-bottom:11px">' +
      pill('draft', CLASSIFICATION.was) + '<span class="muted">→</span>' +
      pill('bad', CLASSIFICATION.now, 'lock') +
      '<span class="muted" style="font-size:12px">elevated by ' +
      CLASSIFICATION.detected.length + ' personal-data elements</span></div>' +
      CLASSIFICATION.detected.map(function (d) {
        return '<div class="map"><code class="map-f">' + esc(d.el) + '</code>' +
          '<span class="map-arrow">' + ic('arrow', 14) + '</span>' +
          '<span class="map-t">' + esc(d.kind) + '</span>' +
          '<span class="mono muted">' + esc(d.pg) + '</span></div>';
      }).join('') +
      '<p class="muted" style="font-size:12px;margin-top:10px">A classification is a statement ' +
      'of fact about the data, not a decision. There is nothing here to accept or decline — the ' +
      'owner is told, because the consequences are his to plan around.</p></div>' +

      '<div class="panel"><div class="panel-h">Obligations now in force</div>' +
      CLASSIFICATION.obligations.map(function (o) {
        return '<div class="life"><div><div class="life-n">' + esc(o.rule) + '</div>' +
          '<div class="life-p"><code>' + esc(o.pg) + '</code></div></div>' +
          '<div>' + pill('warn', 'Enforced', 'lock') + '</div></div>';
      }).join('') +
      '<dl class="kv" style="margin-top:11px">' +
      '<dt>Access</dt><dd>' + esc(CLASSIFICATION.access) + '</dd>' +
      '<dt>Retention</dt><dd>' + esc(CLASSIFICATION.retention) + '</dd></dl></div>' +

      (st.purposed
        ? '<div class="panel"><div class="panel-h">Business purpose</div>' +
          '<p style="font-size:12.5px;margin-bottom:10px">' + esc(PRODUCT.purpose) + '</p>' +
          '<ul class="ticks ticks--yes">' + PRODUCT.usedFor.map(function (x) {
            return '<li>' + esc(x) + '</li>';
          }).join('') + '</ul>' +
          '<ul class="ticks" style="margin-top:6px">' + PRODUCT.notFor.map(function (x) {
            return '<li>' + esc(x) + '</li>';
          }).join('') + '</ul>' +
          '<p class="muted" style="font-size:12px;margin-top:9px">Purpose is checked when ' +
          'somebody requests access, against the purpose they declare.</p></div>' +
          '<div class="acts"><button class="btn" data-act="tab" data-arg="datasets">' +
          'Add the logical datasets</button></div>'
        : '<div class="acts"><button class="btn" data-act="purpose">Define its purpose</button>' +
          '<span class="muted">A product without a stated purpose cannot be scoped, or refused.</span></div>');
  }

  function tabDatasets(st) {
    var good = CANDIDATES.filter(function (c) {
      return c.belongs && has(st.included, c.name);
    }).length;
    var shown = CANDIDATES.filter(function (c) { return c.name === st.rejected; })[0];
    var count = good + (st.overridden ? 1 : 0);

    return '<div class="panel" id="datasets">' +
      '<div class="panel-h">Logical datasets · ' + count + ' of ' + BELONGS + '</div>' +
      (shown
        ? (shown.verdict === 'ownership'
            /* accountability, not taste — this one genuinely cannot be absorbed */
            ? banner('bad', 'warn', shown.head, shown.why)
            /* possible and expensive: show the cost, then let the owner decide */
            : '<div class="alert alert--warn"><i>' + ic('warn', 13) + '</i>' +
              '<div><b>' + esc(shown.head) + '</b><p>' + esc(shown.why) + '</p>' +
              '<div class="acts" style="margin-top:9px">' +
              '<button class="btn btn--sm" data-act="dismiss">Leave it out</button>' +
              '<button class="btn btn--sm btn--ghost" data-act="override">Add it anyway</button>' +
              '</div></div></div>')
        : '') +
      (st.overridden
        ? banner('bad', 'lock', 'Marketing consent checks now apply to the whole product',
            'Every dataset in it inherits them, and all 41 consuming teams are subject to a rule ' +
            'that has nothing to do with what they use.')
        : '') +
      '<div class="tbl-scroll' + (shown || st.overridden ? ' tight' : '') + '">' +
      CANDIDATES.map(function (c) {
        var on = c.belongs ? has(st.included, c.name) : (c.verdict === 'inherit' && st.overridden);
        return '<div class="cand' + (on ? ' in' : c.belongs ? '' : ' no') + '">' +
          '<div><div class="cand-n">' +
          '<button class="cand-open" data-act="openDs" data-arg="' + esc(c.name) + '">' +
          esc(c.name) + '</button>' +
          (c.flagship ? pill('info', 'flagship') : '') +
          (c.pii ? pill('bad', 'PII', 'lock') : '') +
          (c.verdict === 'ownership' ? pill('warn', 'owned by Risk', 'lock') : '') + '</div>' +
          '<div class="cand-g"><span class="mono">' + esc(c.urn) + '</span> · ' + esc(c.grain) +
          ' · ' + esc(c.rows) + ' rows · ' + SCHEMAS[c.name].cols.length + ' columns</div></div>' +
          (c.verdict === 'ownership'
            ? '<button class="btn btn--sm btn--ghost" data-act="include" data-arg="' +
              esc(c.name) + '">Why not?</button>'
            : '<button class="btn btn--sm' + (on ? ' btn--ghost' : '') + '" data-act="' +
              (on ? 'dismissOverride' : 'include') + '" data-arg="' + esc(c.name) + '">' +
              (on ? 'Remove' : 'Add') + '</button>') +
          '</div>';
      }).join('') + '</div></div>' +
      '<div class="acts">' +
      '<button class="btn" data-act="tab" data-arg="gov"' + (good < BELONGS ? ' disabled' : '') + '>' +
      'Meet the minimum standard</button>' +
      '<span class="muted">' + (good < BELONGS
        ? 'Add all ' + BELONGS + ' that belong to continue.'
        : count + ' datasets, one owner, one product.') + '</span></div>';
  }

  function tabGov(st) {
    var supplyable = REQUIREMENTS.filter(function (r) { return has(AT_REGISTRATION, r.id); });
    var later = REQUIREMENTS.filter(function (r) { return !has(AT_REGISTRATION, r.id); });
    var ready = supplyable.every(function (r) { return has(st.supplied, r.id); });

    return '<div class="panel" id="gate">' +
      '<div class="panel-h">POL-061 · what must be present before it goes live</div>' +
      supplyable.map(function (r) {
        var on = has(st.supplied, r.id);
        return '<div class="chk' + (on ? ' on' : '') + '">' +
          '<button class="chk-t" data-act="supply" data-arg="' + r.id + '" aria-pressed="' + on + '" ' +
          'aria-label="' + esc(r.name) + '">' + (on ? ic('check', 11) : '') + '</button>' +
          '<div><div class="chk-n">' + esc(r.name) + '</div>' +
          '<div class="chk-p">' + esc(on ? SUPPLIED_VALUES[r.id] : r.plain) + '</div></div>' +
          '<div class="chk-r">' + (on ? 'Supplied' : 'Required') + '</div></div>';
      }).join('') +
      '<div class="acts">' +
      (st.registered
        ? pill('ok', 'Registered · ' + PRODUCT.id, 'check')
        : '<button class="btn" data-act="register"' + (ready ? '' : ' disabled') + '>Register the product</button>' +
          '<span class="muted">' + (ready ? 'Ready.' : 'Blocked by POL-061 until all three are supplied.') +
          '</span>') +
      '</div></div>' +
      '<div class="panel"><div class="panel-h">The remaining ' + later.length + ', earned later</div>' +
      later.map(function (r) {
        return '<span class="chip">' + esc(r.name) + ' · step ' + r.at + '</span>';
      }).join('') +
      '<p class="muted" style="font-size:12px;margin-top:8px">Nobody is asked for metadata they ' +
      'cannot yet have.</p></div>' +
      '<div class="panel" id="ownership"><div class="panel-h">Accountability</div>' +
      person(OWNER, 'Data Owner') + person(STEWARD, 'Data Steward') +
      '<p class="muted" style="font-size:12px;margin-top:6px">The owner is accountable for what ' +
      'this product means and promises. The steward keeps the vocabulary it uses correct.</p></div>';
  }

  function tabGlossary(st) {
    return '<div class="panel" id="map-terms">' +
      '<div class="panel-h">Business meaning · ' + st.mapped.length + ' of ' +
      MAPPINGS.length + ' elements mapped</div>' +
      MAPPINGS.map(function (m) {
        var on = has(st.mapped, m.field);
        return '<div class="map">' + elemRef(m.el, m.ds) +
          '<span class="map-arrow">' + ic('arrow', 14) + '</span>' +
          '<span class="map-t' + (on ? '' : ' empty') + '">' +
          (on ? '<span class="chip chip--term">' + esc(m.term) + '</span> from <code>' +
                esc(m.field) + '</code>'
              : 'no agreed meaning · source <code>' + esc(m.field) + '</code>') + '</span>' +
          '<button class="btn btn--sm' + (on ? ' btn--ghost' : '') + '" data-act="map" data-arg="' +
          esc(m.field) + '">' + (on ? 'Unassign' : 'Assign term') + '</button></div>';
      }).join('') + '</div>' +

      '<div class="panel" id="map-refs">' +
      '<div class="panel-h">Coded element · ' + (st.linked ? '1 of 1 linked' : 'not linked') + '</div>' +
      '<div class="map">' + elemRef(CODED.el, CODED.ds) +
      '<span class="map-arrow">' + ic('arrow', 14) + '</span>' +
      '<span class="map-t' + (st.linked ? '' : ' empty') + '">' +
      (st.linked ? '<code>' + esc(CODED.ref) + '</code> · ' + CODED.codes + ' codes · ' +
          esc(CODED.access)
        : 'comes back as a raw code') + '</span>' +
      '<button class="btn btn--sm' + (st.linked ? ' btn--ghost' : '') + '" data-act="link">' +
      (st.linked ? 'Unlink' : 'Link') + '</button></div>' +
      (st.linked
        ? '<div style="margin-top:10px">' + CODED.sample.map(function (c) {
            return '<span class="chip"><span class="mono">' + esc(c[0]) + '</span> ' +
              esc(c[1]) + '</span>';
          }).join('') + '<span class="chip">…and ' + (CODED.codes - CODED.sample.length) +
          ' more</span></div>'
        : '') + '</div>' +

      '<div class="panel" id="map-gap"><div class="panel-h">Held back from publication</div>' +
      '<div class="map">' + elemRef(CODE_GAP.el, CODE_GAP.ds) +
      '<span class="map-arrow">' + ic('arrow', 14) + '</span>' +
      '<span class="map-t empty">' + esc(CODE_GAP.why) + '</span>' +
      '<span>' + pill('warn', 'Raised with the steward', 'warn') + '</span></div></div>' +

      '<div class="acts">' +
      '<button class="btn" data-act="tab" data-arg="contract"' +
      (st.mapped.length === MAPPINGS.length && st.linked ? '' : ' disabled') + '>' +
      'Set service expectations</button>' +
      '<span class="muted">Deciding which term or set applies to which element is the owner\'s ' +
      'call — he is accountable for what it means.</span></div>';
  }

  function tabContract(st) {
    var breaches = [];
    if (st.freshness < ACTUAL.freshness) breaches.push('freshness');
    if (st.completeness > ACTUAL.completeness) breaches.push('completeness');
    /* illustrative only: tighter promises cost more to keep, steeply on the
       completeness end, which is the point the screen is making */
    var cost = Math.round(180 + (48 - st.freshness) * 9 +
      Math.pow(Math.max(0, st.completeness - 90), 1.8) * 4);

    var terms = [
      ['Freshness', 'No older than ' + st.freshness + ' hours', ACTUAL.freshness + 'h average',
        st.freshness >= ACTUAL.freshness],
      ['Completeness', '≥ ' + st.completeness + '% of expected records', ACTUAL.completeness + '%',
        st.completeness <= ACTUAL.completeness],
      ['Availability', PRODUCT.availability, '99.8%', true],
      ['Change notice', '30 days before any breaking change', '30 days', true]
    ];

    return '<div class="panel" id="levers"><div class="panel-h">Service expectations · contract v1</div>' +
      LEVERS.map(function (l) {
        var v = st[l.id];
        return '<div class="lever"><div class="lever-h">' +
          '<span class="lever-l">' + esc(l.label) + '</span>' +
          '<span class="lever-v" id="' + l.id + '-val">' + levelText(l.id, v) + '</span></div>' +
          '<input type="range" class="rng" min="' + l.min + '" max="' + l.max + '" step="' + l.step +
          '" value="' + v + '" data-lever="' + l.id + '" aria-label="' + esc(l.label) + '">' +
          '<div class="lever-f"><span>' + esc(l.low) + '</span><span>' + esc(l.high) + '</span></div>' +
          '<div class="lever-p">' + esc(l.plain) + '</div></div>';
      }).join('') +
      '<div class="stats">' +
      '<div class="stat"><b>$' + cost + 'k</b><span>Annual cost to keep the promise</span></div>' +
      '<div class="stat"><b>' + ACTUAL.freshness + 'h</b><span>What the pipeline delivers</span></div>' +
      '<div class="stat"><b>' + ACTUAL.completeness + '%</b><span>Completeness achieved</span></div>' +
      '</div></div>' +

      '<div id="breach">' + (breaches.length
        ? banner('bad', 'warn', 'You would breach this contract immediately',
            'The pipeline delivers ' + ACTUAL.freshness + 'h freshness and ' + ACTUAL.completeness +
            '% completeness. Promising more than that is how trust is lost in month one.')
        : banner('ok', 'check', 'This promise is deliverable',
            'Inside what the pipeline already achieves, with room for a bad day.')) + '</div>' +

      '<div class="acts">' +
      (st.published
        ? pill('ok', 'Published · contract v1', 'check')
        : '<button class="btn" data-act="publish"' + (breaches.length ? ' disabled' : '') + '>' +
          'Publish the contract</button>' +
          '<span class="muted">' + (breaches.length
            ? 'Ease the dials until the promise is one you can keep.'
            : 'From here it is measured continuously, and consumers are told when it slips.') +
          '</span>') +
      '</div>' +

      (st.published
        ? '<div class="panel" id="contract"><div class="panel-h">Data contract v1 · in force</div>' +
          '<table class="tbl"><thead><tr><th>Commitment</th><th>Promised</th><th>Actual</th>' +
          '<th></th></tr></thead><tbody>' +
          terms.map(function (t) {
            return '<tr><td><b>' + esc(t[0]) + '</b></td><td>' + esc(t[1]) + '</td>' +
              '<td class="mono">' + esc(t[2]) + '</td><td>' +
              (t[3] ? pill('ok', 'Met', 'check') : pill('bad', 'Breached', 'warn')) + '</td></tr>';
          }).join('') + '</tbody></table></div>' +
          '<div class="panel"><div class="panel-h">Open change requests · 1</div>' +
          '<div class="map"><span class="map-f" style="font-family:inherit">Digital Channels</span>' +
          '<span class="map-arrow">' + ic('arrow', 14) + '</span>' +
          '<span class="map-t">Asks for 6h freshness for the retention dashboard</span>' +
          '<span>' + pill('warn', 'Costs $126k more', 'clock') + '</span></div>' +
          '<p class="muted" style="font-size:12px;margin-top:8px">A contract that cannot be ' +
          'renegotiated is one people route around.</p></div>'
        : '');
  }

  /* --- the pinned metadata sidebar ---------------------------------------- */
  function sidebar(st) {
    if (st.screen === 'dsdetail') {
      var c = CANDIDATES.filter(function (x) { return x.name === st.openDs; })[0] || CANDIDATES[0];
      var sc = SCHEMAS[c.name];
      /* the distinct policy tags on this table — the practical answer to "who
         can see what", and the reason the classification screen matters */
      var tags = sc.cols.map(function (x) { return x.pg; }).filter(function (v, i, a) {
        return a.indexOf(v) === i;
      });
      return [
        ['About', '<div class="dh-sec-b">' + esc(c.grain) + '.</div>'],
        ['Owners', person(sc.owner.indexOf('Idris') === 0
          ? { initials: 'IH', name: 'Idris Haddad', role: 'VP, Credit Risk' }
          : OWNER, 'Data Owner')],
        ['In data product', '<div class="dh-sec-b">' +
          (c.belongs || st.overridden ? esc(PRODUCT.id) + ' · ' + esc(PRODUCT.name)
            : 'Not in this product') + '</div>'],
        ['Policy tags', '<div class="dh-sec-b mono" style="font-size:11.5px">' +
          tags.map(esc).join('<br>') + '</div>'],
        ['Storage', '<div class="dh-sec-b">' + esc(sc.size) + ' · ' + esc(sc.rows) + ' rows</div>'],
        ['Region', '<div class="dh-sec-b mono">' + esc(sc.region) + '</div>']
      ].map(sec).join('');
    }
    if (st.screen === 'estate') {
      return [
        ['About', '<div class="dh-sec-b">Four tier 1 data products, one accountable owner.</div>'],
        ['Owners', person(OWNER, 'Data Owner')],
        ['Domain', chips(['Customer', 'Retail Deposits'], 'domain')],
        ['Standard', '<div class="dh-sec-b">Seven requirements, published by the Customer Domain ' +
          'Steward. Two are engineering\'s to meet.</div>']
      ].map(sec).join('');
    }
    return [
      ['About', '<div class="dh-sec-b">' +
        esc(st.purposed ? PRODUCT.purpose.slice(0, 104) + '…' : 'No stated purpose yet.') + '</div>'],
      ['Owners', person(OWNER, 'Data Owner') + person(STEWARD, 'Data Steward')],
      ['Flagship dataset', '<div class="dh-sec-b mono" style="word-break:break-all">' +
        esc(PRODUCT.flagship) + '</div>'],
      ['Tags', chips(['Tier 1', 'customer', 'PII'], 'tag')],
      ['Glossary terms', st.mapped.length
        ? chips(MAPPINGS.filter(function (m) { return has(st.mapped, m.field); })
            .map(function (m) { return m.term; }), 'term')
        : '<div class="dh-sec-b muted">None mapped yet</div>'],
      ['Domain', chips([PRODUCT.domain], 'domain')],
      ['Contract', '<div class="dh-sec-b">' + (st.published
        ? 'v1 · no older than ' + st.freshness + 'h · ≥' + st.completeness + '% complete'
        : 'Not agreed yet') + '</div>']
    ].map(sec).join('');
  }
  function sec(s) {
    return '<div class="dh-sec"><div class="dh-sec-h">' + esc(s[0]) + '</div>' + s[1] + '</div>';
  }


  /* =======================================================================
     APP
     ==================================================================== */

  /* The gap left above a tour target once the page has been scrolled to it —
     enough to clear the 52px sticky top bar and no more, because every extra
     pixel is one the tooltip cannot use on a short laptop screen. */
  var TOUR_OFFSET = 60;

  function scrollToTarget(sel) {
    if (!sel || sel === 'body') { window.scrollTo(0, 0); return; }
    var el = document.querySelector(sel);
    if (!el) return;
    window.scrollTo(0, Math.max(0, el.getBoundingClientRect().top + window.scrollY - TOUR_OFFSET));
  }

  function App() {
    var s = useState({
      screen: 'estate', tab: 'overview', purposed: false, included: [], rejected: null,
      overridden: false, openDs: null, supplied: [], registered: false, mapped: [], linked: false,
      freshness: 24, completeness: 99, published: false
    });
    var st = s[0], setSt = s[1];
    var tr = useState({ run: false, index: 0 });
    var tour = tr[0], setTour = tr[1];

    var patch = useCallback(function (p) { setSt(function (x) { return Object.assign({}, x, p); }); }, []);

    /* the tour drives the product, never the other way round */
    var applyStep = useCallback(function (i) {
      var step = TOUR[i];
      if (!step || !step.state) return;
      var p = {};
      STATE_KEYS.forEach(function (k) { if (k in step.state) p[k] = step.state[k]; });
      setSt(function (x) { return Object.assign({}, x, p); });
    }, []);

    var onJoyride = useCallback(function (data) {
      var status = data.status, type = data.type, action = data.action, index = data.index;
      if (status === JC.STATUS.FINISHED || status === JC.STATUS.SKIPPED || action === JC.ACTIONS.CLOSE) {
        setTour({ run: false, index: 0 });
        return;
      }
      if (type === JC.EVENTS.STEP_AFTER || type === JC.EVENTS.TARGET_NOT_FOUND) {
        var next = index + (action === JC.ACTIONS.PREV ? -1 : 1);
        if (next < 0 || next >= TOUR.length) { setTour({ run: false, index: 0 }); return; }
        /* Pause, move the product into the state the next step needs, let the DOM
           settle, scroll the target into place ourselves, and only then resume.

           The scroll has to happen here rather than being left to Joyride, which
           scrolls the target into view *after* the tooltip has chosen a side: a
           tall panel is then measured with no room beneath it, flips above, and
           lands off the top of the screen once the scroll catches up. */
        setTour(function (t) { return { run: false, index: t.index }; });
        applyStep(next);
        setTimeout(function () {
          scrollToTarget(TOUR[next].target);
          setTimeout(function () { setTour({ run: true, index: next }); }, 60);
        }, 170);
      }
    }, [applyStep]);

    var startTour = useCallback(function () {
      applyStep(0);
      setTimeout(function () {
        scrollToTarget(TOUR[0].target);
        setTour({ run: true, index: 0 });
      }, 60);
    }, [applyStep]);

    useEffect(function () { window.scrollTo(0, 0); }, [st.screen, st.tab]);

    /* The contract dials are the one control this file's rendering model cannot
       host naively: the screen is re-mounted as an HTML string on every state
       change, so re-rendering on `input` would destroy the slider under the
       pointer mid-drag. So the live readout is written straight to the DOM while
       dragging — no React involved, the drag survives — and state is committed
       on `change`, which fires when the reader lets go. */
    useEffect(function () {
      var rngs = [].slice.call(document.querySelectorAll('.rng'));
      var offs = rngs.map(function (el) {
        var id = el.dataset.lever;
        var live = function () {
          var out = document.getElementById(id + '-val');
          if (out) out.textContent = levelText(id, el.value);
        };
        var commit = function () {
          var n = Number(el.value);
          if (!isNaN(n)) { var p = {}; p[id] = n; patch(p); }
        };
        el.addEventListener('input', live);
        el.addEventListener('change', commit);
        return function () {
          el.removeEventListener('input', live);
          el.removeEventListener('change', commit);
        };
      });
      return function () { offs.forEach(function (f) { f(); }); };
    });

    /* one delegated handler for every control on every screen */
    function onClick(ev) {
      var el = ev.target.closest('[data-act]');
      if (!el || el.disabled) return;
      ev.preventDefault();
      var a = el.dataset.act, v = el.dataset.arg;
      if (a === 'tab') patch({ screen: 'product', tab: v });
      else if (a === 'openDs') patch({ screen: 'dsdetail', openDs: v });
      else if (a === 'open') patch({ screen: 'product', tab: 'overview' });
      else if (a === 'purpose') patch({ purposed: true });
      else if (a === 'include') {
        var c = CANDIDATES.filter(function (x) { return x.name === v; })[0];
        /* the two awkward ones explain themselves at the moment of the decision,
           rather than being silently accepted and found at an audit */
        if (c && !c.belongs) { patch({ rejected: v }); return; }
        var next = st.included.slice();
        var i = next.indexOf(v);
        if (i === -1) next.push(v); else next.splice(i, 1);
        patch({ included: next, rejected: null });
      } else if (a === 'dismiss') patch({ rejected: null });
      else if (a === 'override') patch({ overridden: true, rejected: null });
      else if (a === 'dismissOverride') patch({ overridden: false });
      else if (a === 'supply') {
        var sup = st.supplied.slice();
        var j = sup.indexOf(v);
        if (j === -1) sup.push(v); else sup.splice(j, 1);
        patch({ supplied: sup });
      } else if (a === 'register') patch({ registered: true });
      else if (a === 'map') {
        var m = st.mapped.slice();
        var k = m.indexOf(v);
        if (k === -1) m.push(v); else m.splice(k, 1);
        patch({ mapped: m });
      } else if (a === 'link') patch({ linked: !st.linked });
      else if (a === 'publish') patch({ published: true });
    }

    var view = st.screen === 'dsdetail' ? viewDsDetail(st)
      : st.screen === 'product' ? viewProduct(st) : viewEstate(st);

    return h('div', null,
      h('header', { className: 'dh-top' },
        h('div', { className: 'dh-logo' }, h('i', null), 'Scotia Data Catalog'),
        h('div', {
          className: 'dh-search',
          dangerouslySetInnerHTML: { __html: ic('search', 14) + '<span>Search products, datasets, terms…</span>' }
        }),
        h('div', { className: 'dh-top-r' },
          h('button', {
            className: 'tour-btn', id: 'tour-btn', onClick: startTour,
            dangerouslySetInnerHTML: { __html: ic('spark', 13) + 'Take the tour' }
          }),
          h('span', { className: 'dh-av' }, OWNER.initials))),

      h('div', { className: 'dh-body' },
        h('nav', { className: 'dh-rail' },
          h('div', { className: 'dh-rail-h' }, 'Browse'),
          RAIL.map(function (r) {
            return h('button', {
              key: r[3], id: r[3], className: 'dh-rail-i' + (r[3] === 'rail-products' ? ' on' : ''),
              onClick: function () { if (r[4]) patch({ screen: r[4] }); },
              dangerouslySetInnerHTML: { __html: '<span>' + r[1] + '</span><b>' + r[2] + '</b>' }
            });
          }),
          h('div', { className: 'dh-rail-h' }, 'My work'),
          h('button', {
            className: 'dh-rail-i', id: 'rail-estate',
            onClick: function () { patch({ screen: 'estate' }); },
            /* open gaps across the estate, not a count of reports — every other
               number in this rail counts entities, so this one has to move as
               the work lands or it reads as "2 reports waiting" */
            dangerouslySetInnerHTML: {
              __html: '<span>My products</span><b>' + openGaps(st) + ' gaps</b>'
            }
          })),

        /* the footer lives inside the content column, not after the grid: a
           sticky rail can only stay pinned while its containing block is still
           on screen, so anything below the grid unpins both side columns just
           as the reader reaches the bottom of the page */
        h('main', { className: 'dh-main' },
          h('div', { id: 'view', onClick: onClick, dangerouslySetInnerHTML: { __html: view } }),
          h('div', {
            className: 'foot',
            dangerouslySetInnerHTML: {
              __html: 'Illustrative prototype · the owner\'s half of the catalog behind ' +
                '<code class="mono">design/analyst-journey.html</code>. Datasets, owners, terms ' +
                'and code sets are the synthetic records shared with that file and with ' +
                '<code class="mono">steward-journey.html</code>; all figures are representative, ' +
                'not measured.'
            }
          })),

        h('aside', { className: 'dh-side', dangerouslySetInnerHTML: { __html: sidebar(st) } })),

      h(Joyride, {
        steps: TOUR.map(function (s2) {
          return {
            target: s2.target, placement: s2.placement || 'auto', disableBeacon: true,
            content: h('div', null,
              h('div', { className: 'jr-t', dangerouslySetInnerHTML: { __html: s2.title } }),
              h('div', { className: 'jr-b', dangerouslySetInnerHTML: { __html: s2.body } }),
              s2.key ? h('div', { className: 'jr-k' }, s2.key) : null)
          };
        }),
        run: tour.run, stepIndex: tour.index, continuous: true, showProgress: true,
        showSkipButton: true, scrollOffset: TOUR_OFFSET, disableOverlayClose: true,
        callback: onJoyride,
        locale: { back: 'Back', close: 'Close', last: 'Finish', next: 'Next', skip: 'End tour' },
        styles: {
          options: {
            primaryColor: '#2A78D6', textColor: '#16181D', backgroundColor: '#FFFFFF',
            /* 500, not Joyride's 420: a wider tooltip is a shorter one, and height
               is the scarce dimension here — it competes with the panel it sits
               under for a 637px viewport, while width is not contested at all. */
            arrowColor: '#FFFFFF', overlayColor: 'rgba(16,20,30,0.55)', width: 500, zIndex: 10000
          },
          /* Joyride's default chrome is generous — roughly 60px of padding and
             footer margin. On a 637px viewport that is 60px the tooltip cannot
             spend beside a target, so it is trimmed rather than the copy. */
          tooltip: { padding: 14, borderRadius: 7 },
          tooltipContainer: { textAlign: 'left' },
          tooltipContent: { padding: '4px 0' },
          tooltipFooter: { marginTop: 8 },
          buttonNext: { borderRadius: 5, fontSize: 13, fontWeight: 600, padding: '8px 15px' },
          buttonBack: { color: '#5C6270', fontSize: 13, marginRight: 8 },
          buttonSkip: { color: '#868C99', fontSize: 12.5 }
        }
      })
    );
  }

  window.createRoot(document.getElementById('root')).render(h(App));
})();
