# design/

## `mock.html`
The source design — a bundled React prototype of the **Scotia Data Marketplace**.
Everything below is derived from it: the tokens, the shell, the dataset model and the
"Scotia DataMate" assistant.

Worth knowing if you open it: it is a self-extracting bundle (~1.7 MB), the app is
client-rendered, and it loads Inter from Google Fonts and calls out to a model at
runtime for the assistant's free-text replies.

## `analyst-journey.html` + `analyst-journey.js`
A clickable mock built on that design. Two things are deliberately separated:

- **The prototype is just the product.** A marketplace you can browse, search, inspect,
  ask and query. Nothing on screen explains itself, because a real product does not
  narrate its own value. There is no progress bar, no "next stage" buttons and no task
  inbox — a data catalog does not assign you work. Close the tour and no scaffolding is
  left behind.
- **The journey is a tour.** Every line of narration lives in the `TOUR` array and is
  delivered by **React Joyride**, anchored to the real element it is talking about.
  The tour drives the product into the state each step needs — the product knows
  nothing about the tour.

Start it with **Take the tour** in the top bar. Thirteen steps cover the **Data Analyst
journey**, step 6 of `../end-to-end-journey.md`:

| | Stage | Screen |
|---|---|---|
| 1 | The request | A centred scene-setter — the brief lives in the tour, not in the product |
| 2 | Search the catalog | Real search over the catalog, including column names |
| 3 | Use obligations | Protection groups, masking, request access by purpose |
| 4 | Quality score | Five dimensions, freshness against SLA; Columns and Lineage tabs |
| 5 | Ask DataMate | The assistant states its grounding, then spots the coded field |
| 6 | Run the query | SQL shown, confirmed, executed, ten rows back |
| 7 | Publish the insight | The finding, with provenance attached |

Open `analyst-journey.html` directly. Use it as a product, or press **Take the tour**
for the narrated walkthrough.

## `steward-journey.html` + `steward-journey.js`
The companion, built the same way and covering **step 2** of `../end-to-end-journey.md` —
the **Data Steward**, and both key journeys in `../scripts/data-steward.md`: *Manage
business glossary* and *Certify data assets*. Thirteen steps.

**This is the prequel, and the two files are one story.** The analyst journey asserts two
things into existence: a **Verified** badge on Customer 360 Profile, and a curated
`reference.attrition_reason_codes` for DataMate to offer as a join. Both are the steward's
output, and this is where they get made. Facts shared between the files are held identical
on purpose — the asset and its urn, 96% quality, 41 consuming teams, Aisha Sharma, the
seven attrition codes and their labels, the five quality dimensions against a 95% target.
If you change one of those in either file, change it in both.

| | Stage | Screen |
|---|---|---|
| 1 | The three-numbers problem | The glossary, with three conflicting terms flagged |
| 2–4 | Create a business term | Term entity: definition, classification and tags, inheritance |
| 5–6 | Resolve duplicates, manage lifecycle | Pick the surviving definition; deprecate the rest **with a pointer** |
| 7 | Register reference and code sets | R01–R07, and an explicit *Where the steward stops* |
| 8–12 | Certify the asset | Ownership, completeness, quality rules, then Certify |
| 13 | The handoff | What the asset now carries — and where the analyst picks it up |

### Why it wears a different skin
The catalog is dressed as **DataHub** — blue, dense, squared-off, a browse rail counting
entities and a pinned metadata sidebar — where the marketplace is Scotia red, airy and
card-led. An executive should be able to tell which of the two products is on screen
without reading a word.

### Things worth clicking (with or without the tour)
- On **Duplicates**, try all three definitions. Each one changes the bank's attrition rate.
- On the term's **Lifecycle** tab, deprecate the losers — they stay resolvable, and the
  change history records it.
- On the dataset's **Certification** tab, the Certify button stays disabled until all three
  checks pass, and the ownership check swaps a distribution list for a named person in the
  sidebar.

## `owner-journey.html` + `owner-journey.js`
The middle link, covering **steps 3, 4 and 9** of `../end-to-end-journey.md` and all three key
journeys in `../scripts/data-owner.md`: *Register new Data Product and Dataset*, *Defines
Business Metadata*, *Manage Data Contract*. Thirteen steps. Protagonist: **Marc Deschamps, VP
Retail Deposits** — the person `steward-journey.js` names as this asset's Data Owner.

**Both neighbours depend on this file, and both said so before it existed.** The steward
publishes the term *Attrition (Retail)* and curates `reference.attrition_reason_codes`; the
analyst's assistant offers to join that code set. Attaching either one to an actual element is
the **owner's** act, and this is where it happens. The data contract signed here is what the
quality score the analyst reads is measured against.

**The unit of work is the data product (DP-0142)** — a curated bundle with one accountable
owner, containing logical datasets. Two things that follow are handled rather than left to cause
quiet contradictions. The product carries **its own identifier**, never a table urn; the dataset
the rest of the story consumes, `enterprise.customer.customer_360_profile`, is named separately
as one thing inside it. And because step 4 of `../end-to-end-journey.md` is explicit that terms
and code sets attach to *"the logical data elements in their datasets"* — one level below the
product — every mapping row **names the dataset its element lives in**. Without that the mapping
is ambiguous the moment a product holds more than one dataset.

| | Stage | Screen |
|---|---|---|
| 1 | My data products | Four tier 1 products, each scored with a *named gap* |
| 2 | Register the product | Reference, version, domain, accountable owner |
| 3 | Sensitivity classification | Personal data found; policy elevated; the owner is told, not asked |
| 4 | Logical datasets | One is refused on ownership; one is allowed, priced, and left to the owner |
| 5–6 | Meet the standard | The policy gate, then the ownership that cannot be delegated |
| 7–9 | Glossary | Element → term, the one coded element → its code set, and one element held back |
| 10–12 | The data contract | Two dials, an undeliverable promise refused, then published |
| 13 | Estate report | Five of seven — and the last two are engineering's, not his |

**The counts are the steward's.** `steward-journey.js` certifies `customer_360_profile` against
*four* glossary terms mapped and *one* coded field linked. This file produces exactly those two
numbers, on exactly that dataset; the harness asserts it. Change one and change both.

**Classification is information, not a request.** Three elements are personal data, so the
platform elevates the dataset from Internal to **Restricted** and attaches `PG-PII-RES-09`,
`PG-PII-RES-04` and `PG-CUST-RES-01` on the spot. There is no accept and no decline — the panel
contains no control at all, and the harness asserts that. A sensitivity classification is a
statement of fact about the data; what the owner gets is warning, because the consequences
(access by declared purpose, 7-year retention, Canadian residency) are his to plan around.
This is also where the analyst's obligations panel comes from: until this screen existed, the
masking and residency rules the analyst meets had no origin anywhere in the story.

**Governance here shows consequences; it does not pretend to forbid columns.** A catalog is a
metadata layer — it cannot stop an owner putting a column in their own table, and a mock that
implies otherwise teaches an executive something false. So the two awkward elements fail in two
genuinely different ways. **Credit Bureau Scores** is Risk's: a product bundles what its owner is
accountable for, and nobody can be accountable for another domain's data — so it is refused
outright and offers no override, because ownership is recorded rather than argued about.
**Marketing Campaign Responses** is Marc's and expensive: adding it applies marketing consent
checks to every dataset in the product, so all 41 consuming teams inherit a rule that has nothing
to do with them. The platform prices that and leaves the decision with the owner, who can take it
and undo it.

**Every dataset opens.** Click a dataset's name on the **Datasets** tab and you get what the
platform actually holds: storage kind and region, row and byte counts, partitioning and
clustering, primary and foreign keys, partition expiry, labels, last modified — and a column list
carrying type, mode, **policy tag**, null share and approximate cardinality. Policy tags are not
invented for the mock: BigQuery enforces column-level access with them, and here they arrive from
the sensitivity classification rather than being set by hand. The eleven columns of
`customer_360_profile` are the eleven in `analyst-journey.js`, same types, tags and descriptions —
this is the owner's view of the object the analyst later queries. Datasets the product does *not*
contain open too, which is the point: you inspect Credit Bureau Scores, see it is Risk's and
carries `PG-RISK-RES-01`, and only then decide.

### Things worth clicking (with or without the tour)
- Open **Customer 360 Profile** and read `attrition_reason_cd`: 91.4% null, because most
  customers have not left. `Account & Balance Daily` carries `legacy_status_cd`, the column held
  back from publication, at 46.9% null and no reference set.
- On **Datasets**, press *Why not?* on Credit Bureau Scores. Then try Marketing Campaign
  Responses and take *Add it anyway*: consent checks spread across the whole product, visibly,
  and you can back it out again.
- On **Overview**, the classification panel has no buttons. That is the point.
- On **Governance**, the Register button is dead until all three requirements are supplied.
- On **Glossary**, link the coded element and the seven codes it decodes appear underneath.
  `legacy_status_cd` is held back from publication entirely — nothing says what its values mean,
  so it goes to the steward rather than shipping as a column no one can read.
- On **Contract**, drag freshness below 4.2h or completeness above 99.6% — the platform refuses
  to publish a promise it can already see being broken.

## The three journeys as one story

Chronological demo order, which is not the numeric order of the end-to-end journey:

| | File | Persona | Covers | Ends by |
|---|---|---|---|---|
| 1 | `steward-journey.html` | Data Steward | step 2 | publishing the term and the code set |
| 2 | `owner-journey.html` | Data Owner | steps 3, 4, 9 | attaching them to elements, and signing the contract |
| 3 | `analyst-journey.html` | Data Analyst | step 6 | one certified answer, in English |

The steward file bundles both of that persona's journeys, so its **certification** half logically
happens *after* the owner's work — the owner's tour ends by saying so.

**Facts held identical across all three files.** The asset and its urn, 96% quality, 41 consuming
teams, `Tier 1 · 99.9%`, `attrition_reason_cd` → `reference.attrition_reason_codes`, the seven
attrition codes and their labels, Aisha Sharma as steward and Marc Deschamps as owner. And the
two counts the owner produces and the steward certifies on that dataset: **4 glossary terms, 1
coded field**.
Change one of these anywhere and change it everywhere. One deliberate asymmetry: the glossary
term *Attrition (Retail)* appears only in the two catalog files — the analyst never sees the term
itself, only what attaching it buys, which is a readable label where a raw code would be.

## `catalog.css`
The DataHub skin, shared by `steward-journey.html` and `owner-journey.html`, which are two views
of the same product and would otherwise drift apart. Each page keeps a short inline block for
what only it needs — the owner's contract sliders and mapping rows, for instance. Loaded with a
plain `<link>`, which works from `file://` where `fetch()` and ES modules do not.
`analyst-journey.html` is the marketplace and keeps its own Scotia-red skin.

## Working on any of the tours

All three files pay for the same lessons. None of them is obvious from the Joyride docs.

- **Never anchor a tour step inside a scrolling container.** In the analyst journey the four
  assistant steps target `.dm-panel`, the fixed panel itself, and the thread scrolls to its
  newest message on its own. Targeting a bubble instead (`#dm-sql` and the like) breaks two
  ways at once: Joyride strips `overflow` from a target's scroll parent, so the thread can no
  longer scroll to reveal the message, and with that behaviour disabled the spotlight is
  placed against a scroll offset it cannot see and lands hundreds of pixels off the element.
  Inside the panel, the long query and the result grid carry their own `max-height` so one
  message cannot push the rest of the conversation out of view.
- **Scroll the target into place yourself, before resuming the tour.** Joyride scrolls to a
  target *after* the tooltip has chosen a side, so a tall panel is measured with no room
  beneath it, flips above, and then lands off the top of the screen once the scroll catches
  up. Both catalog journeys scroll in the paused window between applying a step's state and
  resuming, so the tooltip is placed against the geometry the reader will actually see. The
  budget it has to respect: a tooltip needs roughly **its own height plus 50px** of clear
  space below the target, or the placement flips. In practice that caps a tour-anchored panel
  at about 320px on a small laptop, which is why several of them carry a `max-height`.
- Corollaries worth keeping: a sticky column must be `align-self: start` and its containing
  block must reach the bottom of the document, or it unpins exactly when the reader reaches
  the end; a flex child that scrolls needs `min-height: 0`; and `ic()` prefixes every path
  segment with an absolute `M`, so an icon authored with a relative `m` silently draws
  nothing. And a screen that is re-mounted as an HTML string cannot host a range input
  naively — re-rendering on `input` destroys the slider mid-drag, so `owner-journey.js` writes
  the live readout straight to the DOM while dragging and only commits state on `change`.

## `vendor/react-joyride.bundle.js`
React 18.3.1, ReactDOM and react-joyride 2.9.3, pre-bundled into one file so there is a
single React instance and **no network at run time**. Joyride ships CJS/ESM only, with
eleven runtime dependencies, so it cannot be dropped into a `<script>` tag as-is.
All three journeys load this same file; none of them needs it rebuilt.

To rebuild:

```sh
npm i react@18 react-dom@18 react-joyride@2 esbuild
cat > entry.js <<'EOF'
import * as React from 'react';
import { createRoot } from 'react-dom/client';
import Joyride, { STATUS, ACTIONS, EVENTS, LIFECYCLE } from 'react-joyride';
window.React = React; window.createRoot = createRoot;
window.Joyride = Joyride; window.JoyrideConst = { STATUS, ACTIONS, EVENTS, LIFECYCLE };
EOF
esbuild entry.js --bundle --format=iife --minify \
  --define:process.env.NODE_ENV='"production"' \
  --outfile=vendor/react-joyride.bundle.js
```

### What it keeps from the source
Scotia red rail and brand (`#EC111A` / `#E31837`), the `#F2F2F4` canvas, Inter, the
64px top bar with breadcrumbs, the radius and shadow scale, `ds-card` search results,
tag and classification pills, the dataset detail shell with tabs and a right sidebar,
and the DataMate assistant. Datasets, owners, columns, protection groups and
distribution paths are the real synthetic records from `mock.html`.

### What it changes deliberately
- **No build step and no network.** Plain HTML/CSS/JS with globals, matching the rest
  of this repository. Inter is named in the font stack but never fetched, so the file
  works offline and from a USB stick; it falls back to the system UI face.
- **The assistant is scripted, not live.** The source calls a model at runtime. Here
  the transcript is fixed so the demo is repeatable — but the one decision that matters
  is a real branch: accept the reference-data join and the answer reads in English,
  decline it and the same query returns `R01`, `R02`, `R03`.
- **No journey chrome.** The narrative is a Joyride overlay, not a feature of the
  product. There is no progress bar and no "next stage" buttons in the UI.
- **Screen content is built as HTML strings** mounted through one container with a
  single delegated click handler, rather than a tree of JSX components. It keeps this
  file readable and Joyride is unaffected — it resolves targets from the DOM by
  selector. React owns the shell, the state and the tour.
- **Never anchor a tour step inside the assistant's message thread.** The four
  assistant steps target `.dm-panel`, the fixed panel itself. See *Working on either
  tour* above for why, and for the other Joyride traps both files sit on.

### Things worth clicking (with or without the tour)
- Search `reference`, or `churn` — it filters on column names, not just titles.
- Pick **Retail Attrition Extract 2024**: it is unowned and unverified, shown rather
  than hidden, and it cannot be opened.
- On **Use obligations**, try all three purposes. Marketing is refused, external
  sharing goes to a human, the board request is auto-approved.
- On **Run the query**, press *Let me edit it first* — nothing executes.
