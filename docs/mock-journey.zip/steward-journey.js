/* =============================================================================
   steward-journey.js — the Scotia Data Catalog prototype, with the data steward
   journey delivered as a guided tour rather than as product features.

   Sibling of analyst-journey.js, and deliberately the same shape:

     THE PROTOTYPE  is just the product. A catalog you can browse — glossary
                    terms, reference sets, datasets — and work in. Nothing on
                    screen explains itself, because a real product does not
                    narrate its own value.

     THE TOUR       is React Joyride. Every line of journey narration lives in
                    TOUR below and appears in a tooltip anchored to the real
                    element it is talking about. Close the tour and you are left
                    with a product; there is no leftover scaffolding.

   This is the prequel to analyst-journey.html. The steward's tour ends by
   certifying the exact dataset the analyst later trusts, and by curating the
   exact code set DataMate later offers to join. Facts shared between the two
   files — the asset, its quality score, the seven attrition codes, the owner
   the marketplace displays — are held identical on purpose; see design/README.md.

   React 18 and react-joyride 2.9 are vendored and pre-bundled in
   vendor/react-joyride.bundle.js — one React instance, no network at run time.

   Rendering note: screen content is built as HTML strings and mounted through
   one container, with a single delegated click handler, rather than as a tree
   of JSX components. Joyride is unaffected — it resolves targets from the DOM
   by selector.
   ========================================================================== */

(function () {
  'use strict';

  var h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect, useCallback = React.useCallback;
  var JC = window.JoyrideConst;

  /* --- icons (feather-style, matching analyst-journey.js) ------------------ */
  var I = {
    db: 'M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3ZM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6',
    book: 'M4 4h11a3 3 0 0 1 3 3v13H7a3 3 0 0 0-3 3V4ZM18 20H7',
    tag: 'M3 3h8l10 10-8 8L3 11V3ZM7.5 7.5h.01',
    grid: 'M4 4h7v7H4V4ZM13 4h7v7h-7V4ZM4 13h7v7H4v-7ZM13 13h7v7h-7v-7Z',
    hash: 'M5 9h14M5 15h14M10 4 8 20M16 4l-2 16',
    shield: 'M12 3l8 3v6c0 5-3.4 8.4-8 9-4.6-.6-8-4-8-9V6l8-3ZM9 12l2 2 4-4',
    search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14ZM20 20l-3.5-3.5',
    check: 'M5 12L9.5 16.5L19 7',   /* absolute: ic() prefixes each segment with M */
    warn: 'M12 3 22 20H2L12 3ZM12 9v5M12 17.5v.5',
    lock: 'M5 11h14v10H5V11ZM8 11V7a4 4 0 0 1 8 0v4',
    spark: 'M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3.5 3.5M14.5 14.5 18 18M18 6l-3.5 3.5M9.5 14.5 6 18'
  };
  function ic(n, sz) {
    return '<svg width="' + (sz || 16) + '" height="' + (sz || 16) + '" viewBox="0 0 24 24" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      I[n].split('M').filter(Boolean).map(function (p) { return '<path d="M' + p + '"/>'; }).join('') +
      '</svg>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* =======================================================================
     DATA — the Scotia records shared with analyst-journey.js, plus the
     glossary and certification material this journey needs.
     ==================================================================== */

  /* The protagonist. She is the person the marketplace displays as the contact
     on Customer 360 in analyst-journey.js — the same name, the same role. */
  var STEWARD = { initials: 'AS', name: 'Aisha Sharma', role: 'Customer Domain Steward',
    team: 'Retail Data Office' };

  /* Ownership is a stewardship question, not a metadata field. The asset had a
     distribution list in the owner slot, which is what step 9 is about. */
  var MAILBOX = { initials: '@', name: 'retail-data-office@scotia', role: 'Distribution list · 14 members' };
  var OWNER = { initials: 'MD', name: 'Marc Deschamps', role: 'VP, Retail Deposits' };

  /* The dataset being certified — the same record the analyst opens, held to
     the same numbers. Do not let these drift from analyst-journey.js. */
  var ASSET = {
    name: 'Customer 360 Profile',
    urn: 'enterprise.customer.customer_360_profile',
    platform: 'BigQuery', domain: 'Customer', classification: 'Restricted',
    description: 'Authoritative single-customer view across retail, wealth and small business — ' +
      'demographics, contact preferences, household relationships, segment scores, tenure and ' +
      'product holdings.',
    quality: 96, rows: '24.6M', consumers: 41, columns: 11, updated: '2h ago',
    sla: 'Tier 1 · 99.9%', refresh: 'Daily 02:00 ET', retention: '7 years post-closure',
    tags: ['Tier 1', 'customer', 'PII', 'CRM'],
    terms: ['Attrition (Retail)', 'Customer', 'Tenure Band', 'Product Holding'],
    lineage: ['CIF Mainframe', 'KYC Hub', 'Marketing Profile Store', 'Customer 360 Profile']
  };

  /* The glossary as it stands when Aisha opens it. Three of these say the same
     thing three different ways, which is the entire problem. */
  var TERMS = [
    { id: 'attrition', name: 'Attrition (Retail)', status: 'draft', owner: STEWARD.name,
      def: 'The end of a retail customer relationship with the bank.', assets: 12, story: true },
    { id: 'churn', name: 'Churn', status: 'conflict', owner: 'Digital Channels',
      def: 'No app or web login for 60 days.', assets: 4 },
    { id: 'runoff', name: 'Customer Runoff', status: 'conflict', owner: 'Finance',
      def: 'Balance transferred out in full during the period.', assets: 3 },
    { id: 'lapsed', name: 'Lapsed Customer', status: 'conflict', owner: 'Retail Analytics',
      def: 'All accounts closed or zero-balance, and no activity for 90 days.', assets: 6 },
    { id: 'tenure', name: 'Tenure Band', status: 'approved', owner: STEWARD.name,
      def: 'Months since the customer opened their first product, banded as the segmentation model bands them.', assets: 9 },
    { id: 'dormancy', name: 'Dormancy', status: 'approved', owner: STEWARD.name,
      def: 'An open account with no customer-initiated transaction for 12 months. Not attrition.', assets: 5 }
  ];

  /* Each of the three produces a different attrition rate from the same data.
     This is where the board's three answers came from. */
  var DUPES = [
    { id: 'churn', name: 'Churn', team: 'Digital Channels',
      def: 'No app or web login for 60 days.', rate: '14.1%',
      note: 'Measures engagement, not attrition. A customer with a full balance who prefers the branch is not leaving.' },
    { id: 'runoff', name: 'Customer Runoff', team: 'Finance',
      def: 'Balance transferred out in full during the period.', rate: '9.8%',
      note: 'Measures balance, not the relationship. The account is still open and may refill next month.' },
    { id: 'lapsed', name: 'Lapsed Customer', team: 'Retail Analytics',
      def: 'All accounts closed or zero-balance, and no activity for 90 days.', rate: '11.4%',
      note: 'Measures the relationship ending, which is what the board asked about.' }
  ];
  var RECOMMENDED = 'lapsed';

  /* The reference set the analyst's assistant later offers to join. Seven codes,
     the same seven labels that come back in analyst-journey.js. */
  var CODESET = {
    name: 'Attrition Reason Codes', urn: 'reference.attrition_reason_codes',
    decodes: 'attrition_reason_cd', access: 'Open to all staff', classification: 'Public',
    codes: [
      { cd: 'R01', label: 'Moved to competitor', note: 'Customer named another institution at closure.' },
      { cd: 'R02', label: 'Rate dissatisfaction', note: 'Pricing or interest rate given as the reason.' },
      { cd: 'R03', label: 'Service complaint', note: 'An unresolved complaint is on the record.' },
      { cd: 'R04', label: 'Relocation', note: 'Moved outside the branch network.' },
      { cd: 'R05', label: 'Onboarding friction', note: 'Closed within 90 days of opening.' },
      { cd: 'R06', label: 'Bereavement or estate', note: 'Closed by an executor. Never a retention target.' },
      { cd: 'R07', label: 'Fee complaint', note: 'Account or transaction fees given as the reason.' }
    ]
  };

  /* --- certification: the three checks from the steward's second journey --- */

  var COMPLETENESS = [
    { name: 'Column descriptions', have: 11, need: 11,
      note: 'Two were empty a week ago. The owner filled them after this check failed.' },
    { name: 'PII columns classified', have: 3, need: 3 },
    { name: 'Coded fields linked to a reference set', have: 1, need: 1 },
    { name: 'Business glossary terms mapped', have: 4, need: 4 },
    { name: 'Data contract with an SLA', have: 1, need: 1 },
    { name: 'Lineage traced to source', have: 1, need: 1 }
  ];

  var QUALITY_TARGET = 95;
  var QUALITY_DIMS = [
    { name: 'Completeness', v: 98.4 },
    { name: 'Validity', v: 95.2 },
    { name: 'Consistency', v: 94.1 },
    { name: 'Timeliness', v: 96.8 },
    { name: 'Uniqueness', v: 95.5 }
  ];

  var CHECKS = [
    { id: 'owner', act: 'checkOwner', name: 'Review ownership',
      plain: 'Somebody with a name is accountable for this asset.', hint: 'Fails today' },
    { id: 'complete', act: 'checkComplete', name: 'Validate metadata completeness',
      plain: 'Everything the minimum standard requires is actually present.', hint: '6 requirements' },
    { id: 'quality', act: 'checkQuality', name: 'Verify quality rules',
      plain: 'The rules in the data contract are running, and you can see what they say.', hint: '5 dimensions' }
  ];

  var RAIL = [
    ['db', 'Datasets', '3,089', 'rail-datasets', 'dataset'],
    ['book', 'Glossary Terms', '218', 'rail-glossary', 'glossary'],
    ['hash', 'Reference Sets', '39', 'rail-refs', 'codeset'],
    ['tag', 'Tags', '46', 'rail-tags', null],
    ['grid', 'Domains', '8', 'rail-domains', null]
  ];


  /* =======================================================================
     THE TOUR — every line of journey narration lives here and nowhere else.

     Each step names the product state it needs, so the tour drives the
     prototype rather than the prototype knowing about the tour.
     ==================================================================== */

  /* The board question is the premise of the story, not a feature of a catalog.
     It lives here and is delivered by the tour. */
  var BOARD = { asked: 'what our retail attrition rate is', answers: '14.1%, 9.8% and 11.4%' };

  var TOUR = [
    {
      target: 'body', placement: 'center',
      state: { screen: 'glossary', survivor: null, draft: false },
      title: 'One question, three answers',
      body: 'The board asked <b>' + BOARD.asked + '</b> and got three numbers back: <b>' +
        BOARD.answers + '</b>. Nobody lied and nobody made an arithmetic error — three teams ' +
        'were answering three different questions, because the bank had never agreed what the ' +
        'word means. Aisha is the Customer Domain Steward. This is her job, and it is not a ' +
        'technology problem.',
      key: 'Journey step 2 · the data steward'
    },
    {
      target: '#rail-glossary', placement: 'right',
      state: { screen: 'glossary' },
      title: 'The vocabulary is an entity, not a spreadsheet',
      body: 'Two hundred and eighteen agreed terms, sitting in the catalog beside the datasets ' +
        'rather than in a document nobody opens — each with an owner and the columns it is ' +
        'mapped to.',
      key: 'Journey step 2 · manage the business glossary'
    },
    {
      target: '#term-doc', placement: 'bottom',
      state: { screen: 'term', tab: 'doc', draft: true, classified: false },
      title: 'Written once, in a sentence somebody can argue with',
      body: 'A definition, how it is measured, and what it excludes. Vague enough to be ' +
        'agreeable is the failure mode; this one is specific enough to disagree with.',
      key: 'Journey step 2 · create business term'
    },
    {
      target: '#term-meta', placement: 'bottom',
      state: { screen: 'term', tab: 'props', draft: true, classified: true },
      title: 'Govern the word, not each column',
      body: 'Classification and tags sit on the <b>term</b> and travel to every asset mapped to ' +
        'it. Label the word once, and twelve datasets inherit it.',
      key: 'Journey step 2 · classify and tag'
    },
    {
      target: '#dupes', placement: 'bottom',
      state: { screen: 'dupes', draft: true, classified: true, survivor: null },
      title: 'Three definitions, one number',
      body: 'Pick each one and watch the bank\'s attrition rate change. This is the board\'s ' +
        'problem on a single screen, and choosing is the steward\'s call — not the loudest ' +
        'team\'s.',
      key: 'Journey step 2 · resolve duplicates'
    },
    {
      target: '#lifecycle', placement: 'bottom',
      state: { screen: 'term', tab: 'life', draft: true, classified: true,
        survivor: RECOMMENDED, deprecated: true },
      title: 'Deprecate, do not delete',
      body: 'The retired terms stay in the catalog, marked deprecated and pointing at what ' +
        'replaced them, so last year\'s reports still resolve. Deleting them is how a glossary ' +
        'loses trust once.',
      key: 'Journey step 2 · manage lifecycle changes'
    },
    {
      target: '#codeset', placement: 'bottom',
      state: { screen: 'codeset', survivor: RECOMMENDED, deprecated: true, registered: true },
      title: 'Half the useful fields in a bank are codes',
      body: 'R01 to R07, curated as glossary content. Note where the steward stops: she ' +
        'publishes the vocabulary, she does not attach it to anybody\'s column. That is the ' +
        '<b>owner\'s</b> act.',
      key: 'Journey step 2 · register reference and code sets'
    },
    {
      target: '#cert-queue', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', registered: true,
        certOwner: false, certComplete: false, certQuality: false, certified: false },
      title: 'Certified is a checklist, not an opinion',
      body: 'Three checks, and the same three for every asset in the bank: a named owner, ' +
        'metadata that is complete, and quality rules that run.',
      key: 'Journey step 2 · certify data assets'
    },
    {
      target: '#cert-owner', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', certOwner: true, certComplete: false,
        certQuality: false, certified: false },
      title: 'A person, not a mailbox',
      body: 'The owner of record was a distribution list with fourteen members. Fourteen ' +
        'people accountable is nobody accountable.',
      key: 'Journey step 2 · review ownership'
    },
    {
      target: '#cert-complete', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', certOwner: true, certComplete: true,
        certQuality: false, certified: false },
      title: 'Measured, not asserted',
      body: 'Counted against the standard, not ticked by whoever filled in the form. Two column ' +
        'descriptions were empty last week; this check is what caught them.',
      key: 'Journey step 2 · validate completeness'
    },
    {
      target: '#cert-quality', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', certOwner: true, certComplete: true,
        certQuality: true, certified: false },
      title: 'Against the contract',
      body: 'Consistency is weakest at <b>94.1%</b>, under target — certified anyway, and the ' +
        'score travels with the asset.',
      key: 'Journey step 2 · verify quality rules'
    },
    {
      target: '#cert-btn', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', certOwner: true, certComplete: true,
        certQuality: true, certified: false },
      title: 'A badge with a name and a date on it',
      body: 'Certification is a claim somebody made, on a day, against a published standard. ' +
        'That is what makes it worth anything, and what makes it possible to revoke.',
      key: 'Journey step 2 · certify data assets'
    },
    {
      target: '#unlocked', placement: 'bottom',
      state: { screen: 'dataset', tab: 'cert', certOwner: true, certComplete: true,
        certQuality: true, certified: true },
      title: 'This is where the analyst\'s story starts',
      body: 'Open <b>analyst-journey.html</b>: this asset is the one the analyst trusts on ' +
        'sight, and this code set is the one the assistant offers to join.',
      key: 'Journey step 2 → step 6'
    }
  ];

  var STATE_KEYS = ['screen', 'tab', 'draft', 'classified', 'survivor', 'deprecated',
    'registered', 'certOwner', 'certComplete', 'certQuality', 'certified'];


  /* =======================================================================
     SCREEN CONTENT — product copy only. If a sentence explains why the
     product is good, it belongs in TOUR, not here.
     ==================================================================== */

  function pill(kind, label, icon) {
    return '<span class="pill pill--' + kind + '">' + (icon ? ic(icon, 11) : '') + esc(label) + '</span>';
  }
  function chips(list, kind) {
    return list.map(function (t) { return '<span class="chip chip--' + kind + '">' + esc(t) + '</span>'; }).join('');
  }
  function person(p, kind) {
    return '<div class="dh-owner"><i>' + esc(p.initials) + '</i><div><b>' + esc(p.name) + '</b>' +
      '<span>' + esc(kind ? kind + ' · ' + p.role : p.role) + '</span></div></div>';
  }
  function banner(kind, icon, title, body, act) {
    var open = act ? '<button class="alert alert--' + kind + '" data-act="' + act + '">'
                   : '<div class="alert alert--' + kind + '">';
    return open + '<i>' + ic(icon, 13) + '</i><div><b>' + esc(title) + '</b><p>' + esc(body) + '</p></div>' +
      (act ? '</button>' : '</div>');
  }
  function statusPill(s) {
    return s === 'approved' ? pill('ok', 'Approved', 'check')
      : s === 'draft' ? pill('draft', 'Draft')
      : s === 'deprecated' ? pill('bad', 'Deprecated', 'warn')
      : pill('warn', 'Conflicting', 'warn');
  }

  /* the entity header every screen wears — DataHub's crumb, glyph, title and
     contextual tabs, in one place so the five screens cannot drift apart */
  function ehead(o) {
    return '<div class="dh-crumb">' + o.crumb.map(esc).join('<span class="sep">›</span>') + '</div>' +
      '<div class="dh-ehead"><div class="dh-etitle">' +
      '<span class="dh-glyph dh-glyph--' + o.glyph[0] + '">' + esc(o.glyph[1]) + '</span>' +
      '<h1>' + esc(o.title) + '</h1>' + (o.badges || []).join('') + '</div>' +
      (o.urn ? '<div class="dh-eurn">' + esc(o.urn) + '</div>' : '') +
      (o.desc ? '<div class="dh-edesc">' + esc(o.desc) + '</div>' : '') +
      '<div class="dh-tabs">' + o.tabs.map(function (t) {
        return '<button class="dh-tab' + (t[0] === o.tab ? ' on' : '') + '" data-act="' +
          (o.act || 'tab') + '" data-arg="' + t[0] + '">' + esc(t[1]) + '</button>';
      }).join('') + '</div></div>';
  }
  function wrap(head, body) { return head + '<div class="dh-content">' + body + '</div>'; }

  function survivorOf(st) { return DUPES.filter(function (d) { return d.id === st.survivor; })[0]; }
  function agreedDef(st) { return (survivorOf(st) || DUPES.filter(function (d) { return d.id === RECOMMENDED; })[0]).def; }
  function agreedRate(st) { return survivorOf(st) ? survivorOf(st).rate : '—'; }

  /* --- glossary list ------------------------------------------------------ */
  function viewGlossary(st) {
    var unresolved = !st.survivor;
    var rows = TERMS.map(function (t) {
      var status = t.id === 'attrition' ? (st.draft ? (st.survivor ? 'approved' : 'draft') : 'draft')
        : t.status === 'conflict' && st.deprecated && t.id !== st.survivor ? 'deprecated'
        : t.status === 'conflict' && st.survivor === t.id ? 'approved'
        : t.status;
      var def = t.id === 'attrition' && st.draft ? agreedDef(st) : t.def;
      return '<button class="gl-row' + (t.story ? '' : status === 'deprecated' ? ' dim' : '') +
        '" data-act="term" data-arg="' + t.id + '">' +
        '<div><div class="gl-n">' + esc(t.name) + statusPill(status) +
        (t.story && !st.draft ? pill('info', 'Not written yet') : '') + '</div>' +
        '<div class="gl-d">' + esc(st.draft || t.id !== 'attrition' ? def : 'No definition of record.') + '</div></div>' +
        '<div class="gl-r"><b>' + t.assets + '</b>mapped assets<br>' + esc(t.owner) + '</div></button>';
    }).join('');

    return wrap(ehead({
      crumb: ['Catalog', 'Glossary'], glyph: ['term', 'GT'], title: 'Retail Banking Glossary',
      urn: 'glossary.retail', tab: 'terms', act: 'nav',
      desc: 'The agreed vocabulary of the retail bank. Every term here is mapped to the columns ' +
        'that carry it, so a change to a definition is visible everywhere it is used.',
      badges: [pill('info', '218 terms'), unresolved ? pill('bad', '3 conflicting', 'warn') : pill('ok', 'No conflicts', 'check')],
      tabs: [['terms', 'Terms'], ['dupes', 'Duplicates'], ['refs', 'Reference Sets']]
    }),
      (unresolved
        ? banner('bad', 'warn', 'Three terms describe the same thing',
            'Churn, Customer Runoff and Lapsed Customer are all in use, and each produces a ' +
            'different retail attrition rate. Open Duplicates to resolve them.', 'goDupes')
        : banner('ok', 'check', 'Resolved',
            'One agreed definition of retail attrition, with the alternatives deprecated and ' +
            'pointing at it.')) +
      '<div id="gl-list">' + rows + '</div>');
  }

  /* --- a glossary term, as an entity -------------------------------------- */
  function viewTerm(st) {
    var tabs = [['doc', 'Documentation'], ['props', 'Properties'],
      ['related', 'Related entities'], ['life', 'Lifecycle']];
    var status = st.draft ? (st.survivor ? 'approved' : 'draft') : 'draft';
    var body = st.tab === 'props' ? termProps(st)
      : st.tab === 'related' ? termRelated(st)
      : st.tab === 'life' ? termLife(st)
      : termDoc(st);

    return wrap(ehead({
      crumb: ['Catalog', 'Glossary', 'Attrition (Retail)'], glyph: ['term', 'GT'],
      title: 'Attrition (Retail)', urn: 'glossary.retail.attrition_retail',
      badges: [statusPill(status), pill('info', '12 mapped assets')],
      tabs: tabs, tab: st.tab === 'props' || st.tab === 'related' || st.tab === 'life' ? st.tab : 'doc'
    }), body);
  }

  function fld(label, value, ph) {
    return '<div class="fld"><span class="fld-l">' + esc(label) + '</span>' +
      '<span class="fld-v">' + (value ? esc(value) : '<span class="ph">' + esc(ph) + '</span>') + '</span></div>';
  }

  function termDoc(st) {
    return '<div class="panel" id="term-doc"><div class="panel-h">Definition</div>' +
      fld('Term', st.draft ? 'Attrition (Retail)' : '', 'Not written yet') +
      fld('Definition', st.draft ? agreedDef(st) : '', 'Not written yet') +
      fld('How it is measured', st.draft
        ? 'Counted at the customer level, in the quarter the last account closes. One customer, one event.' : '',
        'Not written yet') +
      fld('Does not include', st.draft
        ? 'Dormant accounts, and customers who stop using digital channels but keep their products.' : '',
        'Not written yet') +
      fld('Source of truth', st.draft ? ASSET.urn : '', '—') +
      fld('Steward', STEWARD.name + ' · ' + STEWARD.role) +
      '</div>' +
      (st.draft
        ? (st.survivor
            ? banner('ok', 'check', 'Published',
                'This is the definition of retail attrition for the bank. Every asset mapped to ' +
                'the term inherits it.')
            : banner('warn', 'warn', 'Three conflicting terms are still in use',
                'The definition is written, but Churn, Customer Runoff and Lapsed Customer have ' +
                'not been reconciled with it.'))
        : '') +
      '<div class="acts">' +
      (st.draft
        ? '<button class="btn" data-act="nav" data-arg="dupes">Reconcile the duplicates</button>'
        : '<button class="btn" data-act="write">Write the definition</button>') +
      (st.draft ? '<span class="muted">Version 1.0 · drafted by ' + esc(STEWARD.name) + '</span>' : '') +
      '</div>';
  }

  function termProps(st) {
    return '<div class="panel" id="term-meta"><div class="panel-h">Classification and tags</div>' +
      '<div class="fld"><span class="fld-l">Classification</span><span class="fld-v">' +
      (st.classified ? pill('warn', 'Confidential', 'lock') +
        ' <span class="muted">— any asset mapped to this term inherits it</span>'
        : '<span class="ph">Not assigned</span>') + '</span></div>' +
      '<div class="fld"><span class="fld-l">Tags</span><span class="fld-v">' +
      (st.classified ? chips(['Tier 1', 'Board Metric', 'Modernization'], 'tag')
        : '<span class="ph">None</span>') + '</span></div>' +
      '<div class="fld"><span class="fld-l">Domain</span><span class="fld-v">' +
      chips(['Customer'], 'domain') + '</span></div>' +
      '<div class="fld"><span class="fld-l">Related terms</span><span class="fld-v">' +
      chips(['Tenure Band', 'Dormancy', 'Product Holding'], 'term') + '</span></div>' +
      '<div class="acts">' +
      (st.classified
        ? '<span class="muted">Inherited by 12 assets and 3 related terms.</span>'
        : '<button class="btn" data-act="classify">Assign classification and tags</button>') +
      '</div></div>' +
      '<div class="panel"><div class="panel-h">Inherited by</div>' +
      '<div class="kv">' +
      ['enterprise.customer.customer_360_profile',
       'analytics.customer.customer_segment_scores',
       'reporting.board.retail_attrition_q3'].map(function (u) {
        return '<dt class="mono">' + esc(u) + '</dt><dd>' +
          (st.classified ? 'Confidential · Tier 1' : 'nothing to inherit yet') + '</dd>';
      }).join('') + '</div>' +
      '<p class="muted" style="font-size:12px;margin-top:9px">…and 9 more. Changing the term ' +
      'changes all of them.</p></div>';
  }

  function termRelated(st) {
    var rows = [
      [ASSET.urn, 'attrition_reason_cd', 'Coded reason recorded at closure'],
      [ASSET.urn, 'tenure_months', 'Used to band the customer'],
      ['analytics.customer.customer_segment_scores', 'churn_band', 'Model output, scored quarterly'],
      ['reporting.board.retail_attrition_q3', 'attrition_rate', 'The number in the board pack']
    ];
    return '<div class="panel" style="padding:0"><table class="tbl">' +
      '<thead><tr><th>Asset</th><th>Column</th><th>Why it carries the term</th></tr></thead><tbody>' +
      rows.map(function (r) {
        return '<tr><td class="mono">' + esc(r[0]) + '</td><td><code>' + esc(r[1]) + '</code></td>' +
          '<td>' + esc(r[2]) + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<p class="muted" style="font-size:12px;margin-top:10px">Mappings are made by each ' +
      'dataset\'s owner, not by the steward. This tab shows where the term has been accepted.</p>';
  }

  function termLife(st) {
    var rows = DUPES.map(function (d) {
      var won = st.survivor === d.id;
      var dep = st.deprecated && !won;
      return '<div class="life"><div><div class="life-n">' + esc(d.name) + ' ' +
        (won ? statusPill('approved') : dep ? statusPill('deprecated') : statusPill('conflict')) + '</div>' +
        '<div class="life-p">' + esc(d.team) + ' · ' +
        (won ? 'adopted as the group standard, published as Attrition (Retail)'
          : dep ? 'replaced by <code>glossary.retail.attrition_retail</code>'
          : 'still in use, still producing ' + esc(d.rate)) + '</div></div>' +
        '<div class="gl-r">' + (dep ? 'read-only' : won ? 'v1.0' : esc(d.rate)) + '</div></div>';
    }).join('');

    return '<div class="panel" id="lifecycle"><div class="panel-h">Term lifecycle</div>' + rows +
      '<div class="acts">' +
      (!st.survivor
        ? '<button class="btn" data-act="nav" data-arg="dupes">Resolve the duplicates first</button>'
        : st.deprecated
          ? '<span class="muted">Deprecated terms stay resolvable — reports keep working.</span>'
          : '<button class="btn" data-act="deprecate">Deprecate the two retired terms</button>') +
      '</div></div>' +
      '<div class="panel"><div class="panel-h">Change history</div><dl class="kv">' +
      '<dt>Today</dt><dd>Definition drafted by ' + esc(STEWARD.name) + '</dd>' +
      (st.survivor ? '<dt>Today</dt><dd>Adopted ' +
        esc(survivorOf(st).team) + '’s definition as the group standard</dd>' : '') +
      (st.deprecated ? '<dt>Today</dt><dd>2 terms deprecated, redirected to this one</dd>' : '') +
      '<dt>Retention</dt><dd>Deprecated terms are kept indefinitely and stay resolvable</dd>' +
      '</dl></div>';
  }

  /* --- duplicate resolution ----------------------------------------------- */
  function viewDupes(st) {
    var cards = DUPES.map(function (d) {
      var won = st.survivor === d.id, lost = st.survivor && !won;
      return '<button class="dup' + (won ? ' win' : lost ? ' lose' : '') +
        '" data-act="survivor" data-arg="' + d.id + '" aria-pressed="' + won + '">' +
        '<span><span class="dup-n">' + esc(d.name) +
        ' <span class="dup-o">· ' + esc(d.team) + '</span></span>' +
        '<span class="dup-d">' + esc(d.def) + '</span>' +
        (st.survivor ? '<span class="dup-note">' + esc(won ? 'Adopted as the group standard.' : d.note) +
          '</span>' : '') + '</span>' +
        '<span class="dup-r"><span class="dup-rate">' + esc(d.rate) + '</span>' +
        '<span class="dup-rl">attrition</span></span></button>';
    }).join('');

    return wrap(ehead({
      crumb: ['Catalog', 'Glossary', 'Duplicates'], glyph: ['term', 'GT'],
      title: 'Retail Banking Glossary', urn: 'glossary.retail', tab: 'dupes', act: 'nav',
      badges: [st.survivor ? pill('ok', 'Resolved', 'check') : pill('bad', '3 conflicting', 'warn')],
      tabs: [['terms', 'Terms'], ['dupes', 'Duplicates'], ['refs', 'Reference Sets']]
    }),
      '<div class="panel" id="dupes"><div class="panel-h">Same thing, three names</div>' +
      '<p class="lede">Each is in production somewhere, and each returns a different retail ' +
      'attrition rate from the same data. Choose the one that becomes <b>Attrition (Retail)</b>.</p>' +
      '<div class="dups">' + cards + '</div></div>' +
      (st.survivor
        ? '<div class="tally"><span class="tally-v">' + esc(agreedRate(st)) + '</span>' +
          '<span class="tally-l">is now <b>the</b> retail attrition rate. One number, for every ' +
          'team, from here on — and the two definitions it replaced are about to be deprecated ' +
          'rather than deleted.</span></div>' +
          '<div class="acts"><button class="btn" data-act="life">Manage the retired terms</button></div>'
        : '<div class="tally"><span class="tally-v muted">—</span>' +
          '<span class="tally-l">Pick a definition to see what the bank\'s attrition rate ' +
          'becomes.</span></div>'));
  }

  /* --- the reference code set --------------------------------------------- */
  function viewCodeset(st) {
    var rows = CODESET.codes.map(function (c) {
      return '<tr><td><code>' + esc(c.cd) + '</code></td><td><b>' + esc(c.label) + '</b></td>' +
        '<td class="muted">' + esc(c.note) + '</td></tr>';
    }).join('');

    return wrap(ehead({
      crumb: ['Catalog', 'Reference Sets', CODESET.name], glyph: ['ref', 'RS'],
      title: CODESET.name, urn: CODESET.urn,
      desc: 'Curated code set decoding ' + CODESET.decodes + '. Maintained as glossary content by ' +
        'the Customer Domain Steward.',
      badges: [st.registered ? pill('ok', 'Certified', 'check') : pill('draft', 'Draft'),
        pill('info', CODESET.access)],
      tabs: [['codes', 'Codes']], tab: 'codes', act: 'noop'
    }),
      '<div class="panel" id="codeset" style="padding:0"><div class="tbl-scroll">' +
      '<table class="tbl">' +
      '<thead><tr><th>Code</th><th>Means</th><th>Recorded when</th></tr></thead><tbody>' +
      rows + '</tbody></table></div></div>' +
      '<div class="panel"><div class="panel-h">Where the steward stops</div>' +
      '<p style="font-size:12.5px;color:var(--ink-2);margin-bottom:7px">The steward publishes the ' +
      'vocabulary. She does not decide which of anyone\'s columns it applies to.</p>' +
      '<p class="muted" style="font-size:12.5px">Attaching this set — or a business term — to a ' +
      'specific field is the data owner\'s act, because the owner is accountable for what that ' +
      'field means. A steward proposing mappings into somebody else\'s dataset is how a glossary ' +
      'ends up authoritative on paper and wrong in practice.</p></div>' +
      '<div class="acts">' +
      (st.registered
        ? '<span class="muted">Registered and open to all staff · 26 consuming teams.</span>'
        : '<button class="btn" data-act="register">Register the code set</button>') +
      '</div>');
  }

  /* --- the dataset being certified ---------------------------------------- */
  function viewDataset(st) {
    var tabs = [['doc', 'Documentation'], ['schema', 'Schema'], ['lineage', 'Lineage'],
      ['cert', 'Certification']];
    var tab = ['doc', 'schema', 'lineage', 'cert'].indexOf(st.tab) === -1 ? 'doc' : st.tab;
    var body = tab === 'cert' ? tabCert(st) : tab === 'schema' ? tabSchema(st)
      : tab === 'lineage' ? tabLineage(st) : tabDoc(st);

    return wrap(ehead({
      crumb: ['Catalog', 'Datasets', ASSET.name], glyph: ['ds', 'BQ'],
      title: ASSET.name, urn: ASSET.urn, desc: ASSET.description,
      badges: [st.certified ? pill('ok', 'Certified', 'check') : pill('warn', 'Certification pending', 'warn'),
        pill('info', ASSET.classification)],
      tabs: tabs, tab: tab
    }), body);
  }

  function tabDoc(st) {
    return '<div class="panel"><div class="panel-h">About</div>' +
      '<p style="font-size:12.5px">' + esc(ASSET.description) + '</p>' +
      '<div class="stats">' +
      '<div class="stat"><b>' + ASSET.quality + '%</b><span>Quality score</span></div>' +
      '<div class="stat"><b>' + esc(ASSET.rows) + '</b><span>Rows</span></div>' +
      '<div class="stat"><b>' + ASSET.columns + '</b><span>Columns</span></div>' +
      '<div class="stat"><b>' + ASSET.consumers + '</b><span>Consuming teams</span></div>' +
      '<div class="stat"><b>' + esc(ASSET.updated) + '</b><span>Last updated</span></div>' +
      '</div></div>' +
      '<div class="panel"><div class="panel-h">Data contract</div><dl class="kv">' +
      '<dt>SLA</dt><dd>' + esc(ASSET.sla) + '</dd>' +
      '<dt>Refresh</dt><dd>' + esc(ASSET.refresh) + '</dd>' +
      '<dt>Retention</dt><dd>' + esc(ASSET.retention) + '</dd></dl></div>';
  }

  function tabSchema(st) {
    var cols = [
      ['customer_id', 'STRING', 'PK', 'Enterprise customer identifier (CIF).'],
      ['sin_hash', 'STRING', 'PII', 'SHA-256 of Social Insurance Number with enterprise pepper.'],
      ['full_name', 'STRING', 'PII', 'Legal name as captured during KYC.'],
      ['date_of_birth', 'DATE', 'PII', 'Date of birth from KYC.'],
      ['tenure_months', 'INT64', 'Tenure Band', 'Months since the customer opened their first product.'],
      ['attrition_reason_cd', 'STRING', 'coded', 'Coded reason recorded at closure. Decodes via ' +
        CODESET.urn + '.']
    ];
    return '<div class="panel" style="padding:0"><table class="tbl">' +
      '<thead><tr><th>Column</th><th>Type</th><th>Glossary / class</th><th>Description</th></tr></thead><tbody>' +
      cols.map(function (c) {
        var mark = c[2] === 'PII' ? pill('bad', 'PII', 'lock')
          : c[2] === 'PK' ? '<span class="chip">PK</span>'
          : c[2] === 'coded' ? pill('warn', 'coded', 'warn')
          : '<span class="chip chip--term">' + esc(c[2]) + '</span>';
        return '<tr><td><code>' + esc(c[0]) + '</code></td><td class="mono">' + esc(c[1]) + '</td>' +
          '<td>' + mark + '</td><td class="muted">' + esc(c[3]) + '</td></tr>';
      }).join('') + '</tbody></table></div>' +
      '<p class="muted" style="font-size:12px;margin-top:10px">Showing 6 of ' + ASSET.columns +
      ' columns.</p>';
  }

  function tabLineage(st) {
    return '<div class="panel"><div class="panel-h">Upstream</div>' +
      '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
      ASSET.lineage.map(function (n, i) {
        return (i ? '<span class="muted">→</span>' : '') + '<span class="chip">' + esc(n) + '</span>';
      }).join('') + '</div></div>' +
      '<div class="panel"><div class="panel-h">Downstream consumers</div>' +
      '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">' +
      chips(['Board Attrition Dashboard', 'OSFI Regulatory Return', 'Churn Propensity Model',
        'Retail Marketplace listing'], 'tag') + '</div></div>';
  }

  /* the three checks, each showing its evidence once it has been run */
  function tabCert(st) {
    var done = { owner: st.certOwner, complete: st.certComplete, quality: st.certQuality };
    var passed = CHECKS.filter(function (c) { return done[c.id]; }).length;

    var rows = CHECKS.map(function (c) {
      var on = done[c.id];
      return '<div class="chk' + (on ? ' on' : '') + '" id="cert-' + c.id + '">' +
        '<button class="chk-t" data-act="' + c.act + '" aria-pressed="' + on + '" ' +
        'aria-label="' + esc(c.name) + '">' + (on ? ic('check', 11) : '') + '</button>' +
        '<div><div class="chk-n">' + esc(c.name) + '</div>' +
        '<div class="chk-p">' + esc(c.plain) + '</div>' +
        (on ? evidence(c.id, st) : '') + '</div>' +
        '<div class="chk-r">' + (on ? 'Passed' : esc(c.hint)) + '</div></div>';
    }).join('');

    return '<div class="panel">' +
      '<div class="panel-h">Certification · ' + passed + ' of ' + CHECKS.length + ' checks passed</div>' +
      '<p class="lede">What certification requires, from the minimum metadata standard.</p>' +
      '<div id="cert-queue">' + rows + '</div>' +
      '<div class="acts" id="cert-btn">' +
      (st.certified
        ? pill('ok', 'Certified today by ' + STEWARD.name, 'check')
        : '<button class="btn" data-act="certify"' + (passed < CHECKS.length ? ' disabled' : '') + '>' +
          'Certify ' + esc(ASSET.name) + '</button>' +
          '<span class="muted">' + (passed < CHECKS.length
            ? 'All three checks must pass first.'
            : 'Your name goes on it, and it can be revoked.') + '</span>') +
      '</div></div>' +
      (st.certified ? unlocked() : '');
  }

  function evidence(id, st) {
    if (id === 'owner') {
      return '<div class="panel" style="margin-top:11px;box-shadow:none;background:var(--surface-2)">' +
        person(OWNER, 'Data Owner') + person(STEWARD, 'Data Steward') +
        '<p class="muted" style="font-size:12px;margin-top:6px">Replaced ' +
        '<span class="mono">' + esc(MAILBOX.name) + '</span> — a ' +
        esc(MAILBOX.role.toLowerCase()) + '.</p></div>';
    }
    if (id === 'complete') {
      return '<div style="margin-top:11px">' + COMPLETENESS.map(function (r) {
        var pct = Math.round(r.have / r.need * 100);
        return '<div class="bar"><span class="bar-l">' + esc(r.name) + '</span>' +
          '<span class="bar-t"><span class="bar-f blue" style="width:' + pct + '%"></span></span>' +
          '<span class="bar-v">' + r.have + ' / ' + r.need + '</span></div>' +
          (r.note ? '<p class="muted" style="font-size:11.5px;margin:-4px 0 4px">' + esc(r.note) + '</p>' : '');
      }).join('') + '</div>';
    }
    return '<div style="margin-top:11px">' + QUALITY_DIMS.map(function (q) {
      var under = q.v < QUALITY_TARGET;
      return '<div class="bar"><span class="bar-l">' + esc(q.name) + '</span>' +
        '<span class="bar-t"><span class="bar-f' + (under ? ' warn' : '') + '" style="width:' + q.v + '%"></span>' +
        '<span class="bar-mark" style="left:' + QUALITY_TARGET + '%"></span></span>' +
        '<span class="bar-v' + (under ? ' under' : '') + '">' + q.v + '%</span></div>';
    }).join('') +
      '<div class="bar-key"><i></i>Target ' + QUALITY_TARGET + '% · scale is 0–100, not zoomed · ' +
      'overall ' + ASSET.quality + '%</div></div>';
  }

  function unlocked() {
    return '<div class="panel" id="unlocked"><div class="panel-h">What this asset now carries</div>' +
      '<dl class="kv">' +
      '<dt>Certified</dt><dd>Today, by ' + esc(STEWARD.name) + ', against the minimum metadata standard</dd>' +
      '<dt>Definition</dt><dd>Attrition (Retail) — one agreed meaning, mapped to ' +
        '<span class="mono">attrition_reason_cd</span> and <span class="mono">tenure_months</span></dd>' +
      '<dt>Decoded by</dt><dd><span class="mono">' + esc(CODESET.urn) + '</span> · 7 codes · ' +
        'open to all staff</dd>' +
      '<dt>Quality</dt><dd>' + ASSET.quality + '% overall, measured continuously against the contract</dd>' +
      '<dt>Published to</dt><dd>Scotia Data Marketplace · ' + ASSET.consumers + ' consuming teams</dd>' +
      '</dl></div>';
  }

  /* --- the pinned metadata sidebar ---------------------------------------- */
  function sidebar(st) {
    var secs;
    if (st.screen === 'dataset') {
      secs = [
        ['About', '<div class="dh-sec-b">' + esc(ASSET.description.slice(0, 128)) + '…</div>'],
        ['Owners', (st.certOwner ? person(OWNER, 'Data Owner') : person(MAILBOX, 'Owner of record')) +
          person(STEWARD, 'Data Steward')],
        ['Tags', chips(ASSET.tags, 'tag')],
        ['Glossary terms', chips(ASSET.terms, 'term')],
        ['Domain', chips([ASSET.domain], 'domain')],
        ['Platform', '<div class="dh-sec-b">' + esc(ASSET.platform) + ' · northamerica-northeast2</div>']
      ];
    } else if (st.screen === 'codeset') {
      secs = [
        ['About', '<div class="dh-sec-b">Seven codes recorded at account closure. Decodes ' +
          '<span class="mono">' + esc(CODESET.decodes) + '</span>.</div>'],
        ['Owners', person(STEWARD, 'Data Steward')],
        ['Tags', chips(['reference', 'code-set', 'customer'], 'tag')],
        ['Glossary terms', chips(['Attrition (Retail)'], 'term')],
        ['Domain', chips(['Reference'], 'domain')],
        ['Access', '<div class="dh-sec-b">' + esc(CODESET.access) + ' · classification ' +
          esc(CODESET.classification) + '</div>']
      ];
    } else if (st.screen === 'term') {
      secs = [
        ['About', '<div class="dh-sec-b">' +
          esc(st.draft ? agreedDef(st) : 'No definition of record yet.') + '</div>'],
        ['Owners', person(STEWARD, 'Data Steward')],
        ['Tags', st.classified ? chips(['Tier 1', 'Board Metric', 'Modernization'], 'tag')
          : '<div class="dh-sec-b muted">None assigned</div>'],
        ['Related terms', chips(['Tenure Band', 'Dormancy', 'Product Holding'], 'term')],
        ['Domain', chips(['Customer'], 'domain')],
        ['Mapped assets', '<div class="dh-sec-b">12 datasets carry this term.</div>']
      ];
    } else {
      secs = [
        ['About', '<div class="dh-sec-b">The agreed vocabulary of the retail bank — 218 terms, ' +
          'each mapped to the columns that carry it.</div>'],
        ['Owners', person(STEWARD, 'Data Steward')],
        ['Tags', chips(['Tier 1', 'Modernization'], 'tag')],
        ['Related terms', chips(['Tenure Band', 'Dormancy', 'Product Holding'], 'term')],
        ['Domain', chips(['Customer'], 'domain')],
        ['Adoption', '<div class="dh-sec-b">86% of tier 1 assets carry at least one glossary ' +
          'term.</div>']
      ];
    }
    return secs.map(function (s) {
      return '<div class="dh-sec"><div class="dh-sec-h">' + esc(s[0]) + '</div>' + s[1] + '</div>';
    }).join('');
  }


  /* =======================================================================
     APP
     ==================================================================== */

  /* The gap left above a tour target once the page has been scrolled to it —
     enough to clear the 52px sticky top bar and no more, because every extra
     pixel is one the tooltip cannot use on a short laptop screen. */
  var TOUR_OFFSET = 60;

  function scrollToTarget(sel) {
    if (!sel || sel === 'body') { window.scrollTo(0, 0); return; }
    var el = document.querySelector(sel);
    if (!el) return;
    window.scrollTo(0, Math.max(0, el.getBoundingClientRect().top + window.scrollY - TOUR_OFFSET));
  }

  function App() {
    var s = useState({
      screen: 'glossary', tab: 'doc', draft: false, classified: false, survivor: null,
      deprecated: false, registered: false,
      certOwner: false, certComplete: false, certQuality: false, certified: false
    });
    var st = s[0], setSt = s[1];
    var tr = useState({ run: false, index: 0 });
    var tour = tr[0], setTour = tr[1];

    var patch = useCallback(function (p) { setSt(function (x) { return Object.assign({}, x, p); }); }, []);

    /* the tour drives the product, never the other way round */
    var applyStep = useCallback(function (i) {
      var step = TOUR[i];
      if (!step || !step.state) return;
      var p = {};
      STATE_KEYS.forEach(function (k) { if (k in step.state) p[k] = step.state[k]; });
      setSt(function (x) { return Object.assign({}, x, p); });
    }, []);

    var onJoyride = useCallback(function (data) {
      var status = data.status, type = data.type, action = data.action, index = data.index;
      if (status === JC.STATUS.FINISHED || status === JC.STATUS.SKIPPED || action === JC.ACTIONS.CLOSE) {
        setTour({ run: false, index: 0 });
        return;
      }
      if (type === JC.EVENTS.STEP_AFTER || type === JC.EVENTS.TARGET_NOT_FOUND) {
        var next = index + (action === JC.ACTIONS.PREV ? -1 : 1);
        if (next < 0 || next >= TOUR.length) { setTour({ run: false, index: 0 }); return; }
        /* Pause, move the product into the state the next step needs, let the DOM
           settle, scroll the target into place ourselves, and only then resume.

           The scroll has to happen here rather than being left to Joyride. Joyride
           scrolls the target into view *after* the tooltip has chosen a side, so a
           tall panel low on the page is measured with no room beneath it, flips
           above, and then lands off the top of the screen once the scroll catches
           up. Scrolling first means the tooltip is placed against the geometry the
           reader will actually see. */
        setTour(function (t) { return { run: false, index: t.index }; });
        applyStep(next);
        setTimeout(function () {
          scrollToTarget(TOUR[next].target);
          setTimeout(function () { setTour({ run: true, index: next }); }, 60);
        }, 170);
      }
    }, [applyStep]);

    var startTour = useCallback(function () {
      applyStep(0);
      setTimeout(function () {
        scrollToTarget(TOUR[0].target);
        setTour({ run: true, index: 0 });
      }, 60);
    }, [applyStep]);

    /* Joyride measures against the document, so a step whose target sits below
       the fold is only correct once the page has finished scrolling. Reset to
       the top on every screen change and let Joyride scroll from there. */
    useEffect(function () { window.scrollTo(0, 0); }, [st.screen, st.tab]);

    /* one delegated handler for every control on every screen */
    function onClick(ev) {
      var el = ev.target.closest('[data-act]');
      if (!el || el.disabled) return;
      ev.preventDefault();
      var a = el.dataset.act, v = el.dataset.arg;
      if (a === 'nav') {
        patch(v === 'terms' ? { screen: 'glossary' }
          : v === 'dupes' ? { screen: 'dupes' }
          : v === 'refs' ? { screen: 'codeset' }
          : { screen: v });
      } else if (a === 'tab') patch({ tab: v });
      else if (a === 'term') patch(v === 'attrition' ? { screen: 'term', tab: 'doc' } : { screen: 'dupes' });
      else if (a === 'goDupes') patch({ screen: 'dupes' });
      else if (a === 'life') patch({ screen: 'term', tab: 'life' });
      else if (a === 'write') patch({ draft: true });
      else if (a === 'classify') patch({ classified: true });
      else if (a === 'survivor') patch({ survivor: v, draft: true });
      else if (a === 'deprecate') patch({ deprecated: true });
      else if (a === 'register') patch({ registered: true });
      else if (a === 'checkOwner') patch({ certOwner: !st.certOwner });
      else if (a === 'checkComplete') patch({ certComplete: !st.certComplete });
      else if (a === 'checkQuality') patch({ certQuality: !st.certQuality });
      else if (a === 'certify') patch({ certified: true });
    }

    var view = st.screen === 'term' ? viewTerm(st)
      : st.screen === 'dupes' ? viewDupes(st)
      : st.screen === 'codeset' ? viewCodeset(st)
      : st.screen === 'dataset' ? viewDataset(st)
      : viewGlossary(st);

    var activeRail = st.screen === 'dataset' ? 'rail-datasets'
      : st.screen === 'codeset' ? 'rail-refs' : 'rail-glossary';

    return h('div', null,
      h('header', { className: 'dh-top' },
        h('div', { className: 'dh-logo' }, h('i', null), 'Scotia Data Catalog'),
        h('div', {
          className: 'dh-search',
          dangerouslySetInnerHTML: { __html: ic('search', 14) + '<span>Search datasets, terms, tags…</span>' }
        }),
        h('div', { className: 'dh-top-r' },
          h('button', {
            className: 'tour-btn', id: 'tour-btn', onClick: startTour,
            dangerouslySetInnerHTML: { __html: ic('spark', 13) + 'Take the tour' }
          }),
          h('span', { className: 'dh-av' }, STEWARD.initials))),

      h('div', { className: 'dh-body' },
        h('nav', { className: 'dh-rail' },
          h('div', { className: 'dh-rail-h' }, 'Browse'),
          RAIL.map(function (r) {
            return h('button', {
              key: r[3], id: r[3], className: 'dh-rail-i' + (r[3] === activeRail ? ' on' : ''),
              onClick: function () { if (r[4]) patch({ screen: r[4] }); },
              dangerouslySetInnerHTML: { __html: '<span>' + r[1] + '</span><b>' + r[2] + '</b>' }
            });
          }),
          h('div', { className: 'dh-rail-h' }, 'My work'),
          h('button', {
            className: 'dh-rail-i', id: 'rail-cert',
            onClick: function () { patch({ screen: 'dataset', tab: 'cert' }); },
            dangerouslySetInnerHTML: { __html: '<span>Certification queue</span><b>4</b>' }
          }),
          h('button', {
            className: 'dh-rail-i', id: 'rail-dupes',
            onClick: function () { patch({ screen: 'dupes' }); },
            dangerouslySetInnerHTML: {
              __html: '<span>Duplicates</span><b>' + (st.survivor ? '0' : '3') + '</b>'
            }
          })),

        /* the footer lives inside the content column, not after the grid: a
           sticky rail can only stay pinned while its containing block is still
           on screen, so anything below the grid unpins both side columns just
           as the reader reaches the bottom of the page */
        h('main', { className: 'dh-main' },
          h('div', { id: 'view', onClick: onClick, dangerouslySetInnerHTML: { __html: view } }),
          h('div', {
            className: 'foot',
            dangerouslySetInnerHTML: {
              __html: 'Illustrative prototype · the catalog behind ' +
                '<code class="mono">design/analyst-journey.html</code>. Datasets, owners, terms ' +
                'and code sets are the synthetic records shared with that file; all figures are ' +
                'representative, not measured.'
            }
          })),

        h('aside', { className: 'dh-side', dangerouslySetInnerHTML: { __html: sidebar(st) } })),

      h(Joyride, {
        steps: TOUR.map(function (s2) {
          return {
            target: s2.target, placement: s2.placement || 'auto', disableBeacon: true,
            content: h('div', null,
              h('div', { className: 'jr-t' }, s2.title),
              h('div', { className: 'jr-b', dangerouslySetInnerHTML: { __html: s2.body } }),
              s2.key ? h('div', { className: 'jr-k' }, s2.key) : null)
          };
        }),
        run: tour.run, stepIndex: tour.index, continuous: true, showProgress: true,
        /* 60, not Joyride's default: it is the gap left above a target after the
           tour scrolls to it, and every pixel of it is a pixel the tooltip does
           not get on a short laptop screen. 60 clears the 52px sticky top bar. */
        showSkipButton: true, scrollOffset: TOUR_OFFSET, disableOverlayClose: true,
        callback: onJoyride,
        locale: { back: 'Back', close: 'Close', last: 'Finish', next: 'Next', skip: 'End tour' },
        styles: {
          options: {
            primaryColor: '#2A78D6', textColor: '#16181D', backgroundColor: '#FFFFFF',
            arrowColor: '#FFFFFF', overlayColor: 'rgba(16,20,30,0.55)', width: 420, zIndex: 10000
          },
          /* Joyride's default chrome is generous — roughly 60px of padding and
             footer margin. On a 637px viewport that is 60px the tooltip cannot
             spend beside a target, so it is trimmed rather than the copy. */
          tooltip: { padding: 14, borderRadius: 7 },
          tooltipContainer: { textAlign: 'left' },
          tooltipContent: { padding: '4px 0' },
          tooltipFooter: { marginTop: 8 },
          buttonNext: { borderRadius: 5, fontSize: 13, fontWeight: 600, padding: '8px 15px' },
          buttonBack: { color: '#5C6270', fontSize: 13, marginRight: 8 },
          buttonSkip: { color: '#868C99', fontSize: 12.5 }
        }
      })
    );
  }

  window.createRoot(document.getElementById('root')).render(h(App));
})();
