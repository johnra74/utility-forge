/* =============================================================================
   analyst-journey.js — the Scotia Data Marketplace prototype, with the analyst
   journey delivered as a guided tour rather than as product features.

   The split that matters:

     THE PROTOTYPE  is just the product. A marketplace you can browse, search,
                    inspect, ask and query. Nothing on screen explains itself,
                    because a real product does not narrate its own value.

     THE TOUR       is React Joyride. Every line of journey narration lives in
                    TOUR below and appears in a tooltip anchored to the real
                    element it is talking about. Close the tour and you are left
                    with a product; there is no leftover scaffolding.

   React 18 and react-joyride 2.9 are vendored and pre-bundled in
   vendor/react-joyride.bundle.js — one React instance, no network at run time.

   Rendering note: screen content is built as HTML strings and mounted through
   one container, with a single delegated click handler, rather than as a tree
   of JSX components. That keeps this file readable next to the vanilla version
   it replaces, and Joyride is unaffected — it resolves its targets from the DOM
   by selector.
   ========================================================================== */

(function () {
  'use strict';

  var h = React.createElement;
  var useState = React.useState, useEffect = React.useEffect,
      useRef = React.useRef, useCallback = React.useCallback;
  var JC = window.JoyrideConst;

  /* --- icons (feather-style, matching the source mock) -------------------- */
  var I = {
    home: 'M3 10.5 12 3l9 7.5M5 9.5V21h14V9.5',
    db: 'M12 3c4.4 0 8 1.3 8 3s-3.6 3-8 3-8-1.3-8-3 3.6-3 8-3ZM4 6v12c0 1.7 3.6 3 8 3s8-1.3 8-3V6',
    compass: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18ZM15.5 8.5l-2 5-5 2 2-5 5-2Z',
    bookmark: 'M6 3h12v18l-6-4.5L6 21V3Z',
    activity: 'M3 12h4l3 8 4-16 3 8h4',
    search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14ZM20 20l-3.5-3.5',
    check: 'm5 12 4.5 4.5L19 7',
    lock: 'M5 11h14v10H5V11ZM8 11V7a4 4 0 0 1 8 0v4',
    warn: 'M12 3 22 20H2L12 3ZM12 9v5M12 17.5v.5',
    arrow: 'M4 12h15M13 6l6 6-6 6',
    spark: 'M12 3v5M12 16v5M3 12h5M16 12h5M6 6l3.5 3.5M14.5 14.5 18 18M18 6l-3.5 3.5M9.5 14.5 6 18'
  };
  function ic(n, sz) {
    return '<svg width="' + (sz || 18) + '" height="' + (sz || 18) + '" viewBox="0 0 24 24" fill="none" ' +
      'stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">' +
      I[n].split('M').filter(Boolean).map(function (p) { return '<path d="M' + p + '"/>'; }).join('') +
      '</svg>';
  }
  function esc(s) {
    return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* =======================================================================
     DATA — the real Scotia records from design/mock.html, plus the reference
     set and the assistant transcript this journey needs.
     ==================================================================== */

  var OWNERS = {
    AS: { initials: 'AS', name: 'Aisha Sharma', role: 'Customer Domain Steward', team: 'Retail Data Office' },
    NO: { initials: 'NO', name: 'Nadia Okonkwo', role: 'Marketing Analytics Lead', team: 'Customer Insights' },
    PR: { initials: 'PR', name: 'Priya Ramanathan', role: 'Product Data Manager', team: 'Cards Data Platform' },
    NONE: { initials: '—', name: 'Unassigned', role: 'No owner of record', team: '—' }
  };

  var DATASETS = [
    {
      id: 'cust-360', name: 'Customer 360 Profile',
      schema: 'enterprise.customer', table: 'customer_360_profile',
      domain: 'Customer', classification: 'restricted', verified: true,
      description: 'Authoritative single-customer view across retail, wealth and small business — ' +
        'demographics, contact preferences, household relationships, segment scores, tenure and ' +
        'product holdings.',
      tags: ['customer', 'PII', 'CRM', 'kyc'], queries30d: 18420, rows: '24.6M', consumers: 41,
      owner: OWNERS.AS, updated: '2h ago', sla: 'Tier 1 · 99.9%', refresh: 'Daily 02:00 ET',
      sensitivity: 'PII · Restricted', retention: '7 years post-closure',
      lineage: ['CIF Mainframe', 'KYC Hub', 'Marketing Profile Store', 'Customer 360 Profile'],
      quality: 96,
      distributions: [
        { platform: 'BigQuery', path: 'scotia-prod-data.enterprise_customer.customer_360_profile',
          region: 'northamerica-northeast2', size: '342 GB', rows: '24.6M',
          protectionGroup: 'PG-CUST-RES-01', accessRequest: 'AccessHub · 1-day approval' },
        { platform: 'Azure', path: 'scotialake/curated/customer/customer_360_profile',
          region: 'canadacentral', size: '318 GB', rows: '24.6M',
          protectionGroup: 'PG-CUST-RES-01', accessRequest: 'AccessHub · 1-day approval' }
      ],
      columns: [
        { name: 'customer_id', type: 'STRING', pk: true, pg: 'PG-CUST-RES-01', desc: 'Enterprise customer identifier (CIF). Surrogate key issued by the Customer Data Hub at onboarding.' },
        { name: 'sin_hash', type: 'STRING', pii: true, pg: 'PG-PII-RES-09', desc: 'SHA-256 of Social Insurance Number with enterprise pepper. Never reversible; cross-system join only.' },
        { name: 'full_name', type: 'STRING', pii: true, pg: 'PG-PII-RES-04', desc: 'Legal name as captured during KYC, with preferred-name overlay where expressed.' },
        { name: 'date_of_birth', type: 'DATE', pii: true, pg: 'PG-PII-RES-04', desc: 'Date of birth from KYC. Masked to year-only for analytics roles.' },
        { name: 'segment_code', type: 'STRING', pg: 'PG-CUST-INT-02', desc: 'Marketing segment assigned quarterly by the segmentation model.' },
        { name: 'tenure_months', type: 'INT64', pg: 'PG-CUST-INT-02', desc: 'Months since the customer opened their first product with the bank.' },
        { name: 'attrition_reason_cd', type: 'STRING', coded: true, pg: 'PG-CUST-INT-02', desc: 'Coded reason recorded at closure. Decodes via reference.attrition_reason_codes.' },
        { name: 'product_holdings_count', type: 'INT64', pg: 'PG-CUST-INT-02', desc: 'Count of open products held at the as-of date.' },
        { name: 'is_scene_member', type: 'BOOL', pg: 'PG-CUST-INT-02', desc: 'Whether the customer is enrolled in Scene+.' },
        { name: 'last_login_ts', type: 'TIMESTAMP', pg: 'PG-CUST-INT-02', desc: 'Most recent authenticated digital session.' },
        { name: 'updated_at', type: 'TIMESTAMP', pg: 'PG-META-PUB-01', desc: 'Row last-modified timestamp from the curation job.' }
      ]
    },
    {
      id: 'cust-segments', name: 'Customer Segmentation Scores',
      schema: 'analytics.customer', table: 'customer_segment_scores',
      domain: 'Analytics', classification: 'internal', verified: true,
      description: 'Quarterly model output: primary segment, churn risk band, next-best-product and ' +
        'Scene+ engagement decile for every retail customer.',
      tags: ['segmentation', 'CRM', 'analytics', 'ML'], queries30d: 6240, rows: '24.6M', consumers: 18,
      owner: OWNERS.NO, updated: '6d ago', sla: 'Tier 2 · 99%', refresh: 'Quarterly',
      sensitivity: 'Internal', retention: '5 years',
      lineage: ['Customer 360 Profile', 'Holdings Snapshot', 'Behaviour Features', 'Customer Segment Scores'],
      quality: 93,
      distributions: [
        { platform: 'BigQuery', path: 'scotia-prod-data.analytics_customer.customer_segment_scores',
          region: 'northamerica-northeast2', size: '61 GB', rows: '24.6M',
          protectionGroup: 'PG-CUST-INT-02', accessRequest: 'AccessHub · same-day' }
      ],
      columns: [
        { name: 'customer_id', type: 'STRING', pk: true, pg: 'PG-CUST-INT-02', desc: 'Enterprise customer identifier (CIF).' },
        { name: 'primary_segment', type: 'STRING', pg: 'PG-CUST-INT-02', desc: 'Assigned marketing segment for the quarter.' },
        { name: 'churn_band', type: 'STRING', pg: 'PG-CUST-INT-02', desc: 'Churn risk band — Low, Medium, High, Severe.' },
        { name: 'scored_at', type: 'TIMESTAMP', pg: 'PG-META-PUB-01', desc: 'Timestamp the score was produced.' }
      ]
    },
    {
      id: 'attrition-extract-2024', name: 'Retail Attrition Extract 2024',
      schema: 'sandbox.retail', table: 'attrition_extract_2024',
      domain: 'Customer', classification: 'confidential', verified: false,
      description: 'One-off extract built for the 2024 attrition review. No owner of record and no ' +
        'refresh since. Kept visible so the gap is obvious rather than hidden.',
      tags: ['attrition', 'ad-hoc', 'legacy'], queries30d: 34, rows: '4.1M', consumers: 2,
      owner: OWNERS.NONE, updated: '14 months ago', sla: 'None', refresh: 'None — static extract',
      sensitivity: 'Confidential', retention: 'Undefined',
      lineage: ['Unknown upstream', 'Retail Attrition Extract 2024'],
      quality: 61,
      warning: 'No owner and no refresh in 14 months. Flagged, not hidden — an honest catalog shows its gaps.',
      distributions: [
        { platform: 'BigQuery', path: 'scotia-sandbox.retail.attrition_extract_2024',
          region: 'northamerica-northeast2', size: '2.1 GB', rows: '4.1M',
          protectionGroup: 'PG-UNCLASSIFIED', accessRequest: 'Not available — no owner' }
      ],
      columns: []
    },
    {
      id: 'ref-attrition', name: 'Attrition Reason Codes',
      schema: 'reference', table: 'attrition_reason_codes',
      domain: 'Reference', classification: 'public', verified: true, isRef: true,
      description: 'Curated reference set decoding attrition_reason_cd. Seven codes, maintained by ' +
        'the Customer Domain Steward as glossary content.',
      tags: ['reference', 'code-set', 'customer'], queries30d: 2110, rows: '7', consumers: 26,
      owner: OWNERS.AS, updated: '3mo ago', sla: 'Tier 2 · 99%', refresh: 'On change',
      sensitivity: 'Public', retention: 'Indefinite',
      lineage: ['Customer Data Hub', 'Attrition Reason Codes'],
      quality: 100,
      distributions: [
        { platform: 'BigQuery', path: 'scotia-prod-data.reference.attrition_reason_codes',
          region: 'northamerica-northeast2', size: '4 KB', rows: '7',
          protectionGroup: 'PG-META-PUB-01', accessRequest: 'Open to all staff' }
      ],
      columns: [
        { name: 'reason_cd', type: 'STRING', pk: true, pg: 'PG-META-PUB-01', desc: 'Code as stored on the customer record — R01 through R07.' },
        { name: 'reason_label', type: 'STRING', pg: 'PG-META-PUB-01', desc: 'Plain-English label, e.g. "Moved to competitor".' }
      ]
    }
  ];

  var DOMAINS = [
    { name: 'Customer', count: 142 }, { name: 'Cards', count: 87 },
    { name: 'Risk & AML', count: 64 }, { name: 'Wealth', count: 96 },
    { name: 'Lending', count: 71 }, { name: 'Digital', count: 118 },
    { name: 'Analytics', count: 53 }, { name: 'Reference', count: 39 }
  ];

  var QUALITY_TARGET = 95;

  var QUALITY_DIMS = [
    { name: 'Completeness', v: 98.4, plain: 'How much of the expected data actually arrived.' },
    { name: 'Validity', v: 95.2, plain: 'How much of it is in a shape the rules allow.' },
    { name: 'Consistency', v: 94.1, plain: 'Whether it agrees with itself and with source systems.' },
    { name: 'Timeliness', v: 96.8, plain: 'Whether it landed inside the window the SLA promises.' },
    { name: 'Uniqueness', v: 95.5, plain: 'Whether a customer appears once, not three times.' }
  ];

  var OBLIGATIONS = [
    { pg: 'PG-PII-RES-04', effect: 'limited', rule: 'Name and date of birth are masked for your role.', plain: 'You get what you need, not what you do not.' },
    { pg: 'PG-PII-RES-09', effect: 'limited', rule: 'SIN hash is withheld entirely from analytics roles.', plain: 'Join keys you cannot see, and do not need.' },
    { pg: 'PG-CUST-RES-01', effect: 'allowed', rule: 'Customer records stay in the Canadian region.', plain: 'Enforced by the platform. You cannot get it wrong by accident.' },
    { pg: 'PG-CUST-INT-02', effect: 'allowed', rule: 'Approved for attrition and retention analysis.', plain: 'The purpose you declared matches the rule.' }
  ];

  var PURPOSES = [
    { id: 'attrition', label: 'Attrition and retention analysis', turnaround: '6 minutes',
      decision: 'auto', why: 'Role (Business Analyst, Retail) and declared purpose match an existing AccessHub rule. No human approval needed.' },
    { id: 'marketing', label: 'Build a marketing target list', turnaround: 'instant',
      decision: 'blocked', why: 'Purpose limitation forbids reusing this data for outbound marketing without an active consent flag. Blocked at request time rather than discovered at audit.' },
    { id: 'external', label: 'Share with an external consultancy', turnaround: '2 days',
      decision: 'review', why: 'Cross-border transfer requires a named human approver. Routed to Aisha Sharma, the domain steward.' }
  ];

  var CHAT = {
    prompt: 'Retail attrition for Q3 by customer tenure band, with the top reasons in each band.',
    grounding: [
      'enterprise.customer.customer_360_profile — verified, and you have access',
      'Name, date of birth and SIN hash will be masked for your role',
      'Using the tenure_months field, banded as the segmentation model does'
    ],
    recTitle: 'One thing before I write this.',
    rec: 'attrition_reason_cd is a coded field — it returns R01, R02, R03. The catalog says ' +
      'reference.attrition_reason_codes decodes it, and it is open to all staff. Shall I join it so ' +
      'your report reads in English?',
    yes: 'Yes, join the reference data', no: 'No, just give me the codes',
    declined: 'Understood — raw codes it is. Worth knowing that whoever reads this report will have ' +
      'to look up what R01 means, and the catalog is where they would have to look anyway.',
    sqlJoined:
      'SELECT  CASE\n' +
      '          WHEN c.tenure_months <  6 THEN \'0–6 months\'\n' +
      '          WHEN c.tenure_months < 12 THEN \'6–12 months\'\n' +
      '          WHEN c.tenure_months < 18 THEN \'12–18 months\'\n' +
      '          WHEN c.tenure_months < 24 THEN \'18–24 months\'\n' +
      '          WHEN c.tenure_months < 60 THEN \'2–5 years\'\n' +
      '          ELSE \'5+ years\'\n' +
      '        END                                   AS tenure_band,\n' +
      '        r.reason_label                        AS leaving_reason,\n' +
      '        COUNT(*)                              AS customers_lost\n' +
      'FROM    `scotia-prod-data.enterprise_customer.customer_360_profile` c\n' +
      'JOIN    `scotia-prod-data.reference.attrition_reason_codes`         r\n' +
      '        ON r.reason_cd = c.attrition_reason_cd\n' +
      'WHERE   c.attrition_reason_cd IS NOT NULL\n' +
      '  AND   c.updated_at BETWEEN \'2026-07-01\' AND \'2026-09-30\'\n' +
      'GROUP BY tenure_band, leaving_reason\n' +
      'ORDER BY customers_lost DESC\n' +
      'LIMIT   10;',
    sqlRaw:
      'SELECT  CASE\n' +
      '          WHEN c.tenure_months <  6 THEN \'0–6 months\'\n' +
      '          WHEN c.tenure_months < 12 THEN \'6–12 months\'\n' +
      '          WHEN c.tenure_months < 18 THEN \'12–18 months\'\n' +
      '          WHEN c.tenure_months < 24 THEN \'18–24 months\'\n' +
      '          WHEN c.tenure_months < 60 THEN \'2–5 years\'\n' +
      '          ELSE \'5+ years\'\n' +
      '        END                                   AS tenure_band,\n' +
      '        c.attrition_reason_cd                 AS leaving_reason,\n' +
      '        COUNT(*)                              AS customers_lost\n' +
      'FROM    `scotia-prod-data.enterprise_customer.customer_360_profile` c\n' +
      'WHERE   c.attrition_reason_cd IS NOT NULL\n' +
      '  AND   c.updated_at BETWEEN \'2026-07-01\' AND \'2026-09-30\'\n' +
      'GROUP BY tenure_band, leaving_reason\n' +
      'ORDER BY customers_lost DESC\n' +
      'LIMIT   10;',
    ask: 'That is the query. Shall I run it?',
    exec: { scanned: '24,612,884', returned: 10, seconds: '2.3', masked: 3, bytes: '18.4 GB' },
    rows: [
      { band: '12–18 months', code: 'R01', label: 'Moved to competitor', lost: '11,204', pct: '41%' },
      { band: '18–24 months', code: 'R01', label: 'Moved to competitor', lost: '9,377', pct: '38%' },
      { band: '12–18 months', code: 'R02', label: 'Rate dissatisfaction', lost: '4,918', pct: '18%' },
      { band: '6–12 months', code: 'R02', label: 'Rate dissatisfaction', lost: '3,880', pct: '29%' },
      { band: '18–24 months', code: 'R03', label: 'Service complaint', lost: '3,102', pct: '13%' },
      { band: '2–5 years', code: 'R04', label: 'Relocation', lost: '2,455', pct: '22%' },
      { band: '0–6 months', code: 'R05', label: 'Onboarding friction', lost: '2,209', pct: '31%' },
      { band: '5+ years', code: 'R06', label: 'Bereavement or estate', lost: '1,640', pct: '27%' },
      { band: '6–12 months', code: 'R01', label: 'Moved to competitor', lost: '1,588', pct: '12%' },
      { band: '2–5 years', code: 'R07', label: 'Fee complaint', lost: '1,204', pct: '11%' }
    ]
  };

  var INSIGHT = {
    byTenure: [
      { label: '0–6 months', v: 6.1 }, { label: '6–12 months', v: 8.4 },
      { label: '12–18 months', v: 19.8, hot: true }, { label: '18–24 months', v: 17.2, hot: true },
      { label: '2–5 years', v: 7.9 }, { label: '5+ years', v: 3.2 }
    ],
    finding: 'Attrition is concentrated in customers 12 to 24 months into the relationship, and in ' +
      'both bands the main reason is the same: they are moving to a competitor.',
    action: 'A retention offer aimed at that single band costs $3.1M and protects an estimated ' +
      '$42M — a decision the board can take in the room.'
  };


  /* =======================================================================
     THE TOUR — every line of journey narration lives here and nowhere else.

     Each step names the product state it needs, so the tour drives the
     prototype rather than the prototype knowing about the tour.
     ==================================================================== */

  /* The brief is the premise of the story, not a feature of a data marketplace.
     A catalog has no task inbox, so it lives here and is delivered by the tour. */
  var BRIEF = {
    id: 'TSK-4471', from: 'the Group Chief Customer Officer', due: 'Thursday',
    title: 'Q3 board pack — retail attrition by tenure band',
    ask: 'Retail attrition for Q3, split by how long the customer has been with us, with the ' +
      'main reason people are leaving in each band.'
  };

  var TOUR = [
    {
      target: 'body', placement: 'center',
      state: { screen: 'task', chat: false, picked: null },
      title: 'It starts with a deadline, not a data strategy',
      body: 'David is a business analyst. This morning ' + BRIEF.from + ' raised ' + BRIEF.id +
        ': ' +
        '<b>' + BRIEF.title.toLowerCase() + '</b> — ' + BRIEF.ask.charAt(0).toLowerCase() +
        BRIEF.ask.slice(1) + ' It is due ' + BRIEF.due + ', and he has never used the data ' +
        'he needs. Nobody in this story woke up wanting to do data governance.',
      key: 'Journey step 1 · the request'
    },
    {
      target: '#search-shell', placement: 'bottom',
      state: { screen: 'search', q: 'attrition' },
      title: 'Three weeks of asking around becomes a search box',
      body: 'This is a real search — type anything. It matches column names too, ' +
        'which is why <b>attrition</b> finds a dataset whose title never says it.',
      key: 'Journey step 2 · search the catalog'
    },
    {
      target: '#ds-cust-360', placement: 'bottom',
      state: { screen: 'search', q: 'attrition' },
      title: 'Trust is a visible property',
      body: 'Verified, 96% quality, refreshed two hours ago, 41 teams already using it, ' +
        'and a named owner. He can judge this without asking a soul.',
      key: 'Journey step 2 · search the catalog'
    },
    {
      target: '#ds-attrition-extract-2024', placement: 'top',
      state: { screen: 'search', q: 'attrition' },
      title: 'And the bad one is shown, not hidden',
      body: 'An unowned extract, fourteen months stale. An honest catalog surfaces its gaps — ' +
        'and this one cannot be opened at all.',
      key: 'Journey step 2 · search the catalog'
    },
    {
      target: '#oblig', placement: 'right',
      state: { screen: 'detail', tab: 'access', picked: 'cust-360' },
      title: 'What you may do with it, before you touch it',
      body: 'These are not a wiki page. They are generated from the protection groups on the ' +
        'columns themselves — so three fields are masked for his role before any query runs.',
      key: 'Journey step 3 · data use obligations'
    },
    {
      target: '#purposes', placement: 'right',
      state: { screen: 'detail', tab: 'access', picked: 'cust-360' },
      title: 'Try all three',
      body: 'He has to say why he wants it. The board request is approved in minutes; a marketing ' +
        'list is refused outright; external sharing goes to a human. He finds out now, not at an audit.',
      key: 'Journey step 3 · access'
    },
    {
      target: '#quality', placement: 'right',
      state: { screen: 'detail', tab: 'quality', picked: 'cust-360' },
      title: 'Good enough for a board pack?',
      body: 'Five dimensions, measured continuously against the contract. Consistency is the ' +
        'weakest at 94.1% — and he knows that <b>before</b> writing a line of code, not after ' +
        'someone challenges the number in the meeting.',
      key: 'Journey step 4 · quality score'
    },
    {
      target: '#coded-col', placement: 'top',
      state: { screen: 'detail', tab: 'columns', picked: 'cust-360' },
      title: 'Remember this column',
      body: '<b>attrition_reason_cd</b> is coded — it comes back as R01, R02, R03. The catalog ' +
        'records which reference set decodes it. That single fact is about to do a lot of work.',
      key: 'Journey step 4 · columns'
    },
    {
      /* the assistant panel, not the individual bubble: it is position:fixed and
         always fully on screen, while the thread inside it scrolls to the newest
         message on its own. Anchoring into a scrolling thread leaves Joyride
         measuring against a scroll offset it cannot see. */
      target: '.dm-panel', placement: 'left',
      state: { screen: 'detail', tab: 'overview', picked: 'cust-360', chat: true, joinRef: null, ran: false },
      title: 'It checks before it writes',
      body: 'Asked in plain English, DataMate first states what it is working from, what he is ' +
        'allowed to see, and what will be masked. No SQL yet.',
      key: 'Journey step 5 · ask the assistant'
    },
    {
      target: '.dm-panel', placement: 'left',
      state: { screen: 'detail', tab: 'overview', picked: 'cust-360', chat: true, joinRef: null, ran: false },
      title: 'This is the whole argument, in one interaction',
      body: 'It spotted the coded field and knows which reference set decodes it — because the ' +
        'steward curated that set and the owner linked it to this column. <b>Decline the join</b> ' +
        'and see what a board pack full of R01 looks like.',
      key: 'Journey step 5 · ask the assistant'
    },
    {
      target: '.dm-panel', placement: 'left',
      state: { screen: 'detail', tab: 'overview', picked: 'cust-360', chat: true, joinRef: 'yes', ran: false },
      title: 'It shows its working, and asks',
      body: 'The SQL is on screen rather than hidden, with the scan cost, and nothing executes ' +
        'until he says so. Try <b>Let me edit it first</b> — nothing runs.',
      key: 'Journey step 6 · confirm and run'
    },
    {
      target: '.dm-panel', placement: 'left',
      state: { screen: 'detail', tab: 'overview', picked: 'cust-360', chat: true, joinRef: 'yes', ran: true },
      title: 'Readable, because the catalog knew what the codes meant',
      body: 'Ten rows in 2.3 seconds, three columns masked automatically. Nobody had to know ' +
        'reference.attrition_reason_codes existed — DataMate did.',
      key: 'Journey step 6 · confirm and run'
    },
    {
      /* top-start, not top: the insight panel is tall, and a centred top placement
         pushes the tooltip off the bottom of a short laptop screen. */
      target: '#insight', placement: 'top-start',
      state: { screen: 'insight', chat: false },
      title: 'Tuesday to Thursday',
      body: 'The answer, with its provenance attached — source, reference set, access grant, what ' +
        'was masked, and the lineage behind it. That is what makes the number defensible in the room.',
      key: 'Journey step 6 · publish the insight'
    }
  ];

  var STATE_KEYS = ['screen', 'tab', 'picked', 'q', 'chat', 'joinRef', 'ran'];


  /* =======================================================================
     SCREEN CONTENT — product copy only. If a sentence explains why the
     product is good, it belongs in TOUR, not here.
     ==================================================================== */

  function classPill(c) {
    var m = { restricted: ['res', 'Restricted'], confidential: ['conf', 'Confidential'],
      internal: ['int', 'Internal'], public: ['int', 'Public'] };
    var x = m[c] || ['int', c];
    return '<span class="pill pill--' + x[0] + '">' + ic('lock', 11) + esc(x[1]) + '</span>';
  }
  function verifiedPill(v) {
    return v ? '<span class="pill pill--ok">' + ic('check', 11) + 'Verified</span>'
             : '<span class="pill pill--bad">' + ic('warn', 11) + 'Unverified</span>';
  }
  function ownerRow(o) {
    return '<div class="owner-row"><span class="owner-avatar">' + esc(o.initials) + '</span>' +
      '<span class="owner-info"><b>' + esc(o.name) + '</b><span>' + esc(o.role) + '</span></span></div>';
  }
  function verdict(kind, title, body) {
    var icons = { ok: 'check', bad: 'warn', warn: 'lock' };
    return '<div class="verdict verdict--' + kind + '"><i>' + ic(icons[kind], 14) + '</i>' +
      '<div><b>' + esc(title) + '</b><p>' + esc(body) + '</p></div></div>';
  }
  function ds(id) { return DATASETS.filter(function (d) { return d.id === id; })[0]; }

  function results(st) {
    var q = (st.q || '').trim().toLowerCase();
    return DATASETS.filter(function (d) {
      if (st.domain && d.domain !== st.domain) return false;
      if (!q) return true;
      var hay = (d.name + ' ' + d.schema + ' ' + d.table + ' ' + d.description + ' ' +
        d.tags.join(' ') + ' ' + d.domain + ' ' +
        d.columns.map(function (c) { return c.name + ' ' + c.desc; }).join(' ')).toLowerCase();
      return q.split(/\s+/).every(function (t) { return hay.indexOf(t) !== -1; });
    });
  }

  /* --- marketplace home -------------------------------------------------- */
  function viewHome() {
    return '<div class="hero">' +
      '<div class="hero-eyebrow">Data Marketplace</div>' +
      '<h1>Good morning, David.</h1>' +
      '<p>Find, understand and request data from across the bank.</p>' +
      '<button class="search-shell" id="home-search" data-act="screen" data-arg="search" ' +
      'style="margin-top:20px;width:100%;text-align:left">' + ic('search', 18) +
      '<span class="muted" style="flex:1;font-size:15px">Search datasets, tables, columns…</span></button>' +
      '<div style="margin-top:12px">' +
      ['attrition', 'customer', 'churn', 'reference'].map(function (q) {
        return '<button class="chip" data-act="q" data-arg="' + q + '">' + q + '</button>';
      }).join('') + '</div>' +
      '<div class="hero-stats">' +
      '<div class="hero-stat"><b>3,089</b><span>Datasets in the catalog</span></div>' +
      '<div class="hero-stat"><b>142</b><span>In the Customer domain</span></div>' +
      '<div class="hero-stat"><b>2</b><span>Access grants you hold</span></div>' +
      '</div></div>' +
      '<div class="section"><div class="section-head"><h2>Browse by domain</h2></div>' +
      '<div class="domain-grid">' + DOMAINS.map(function (d) {
        return '<button class="domain-tile" data-act="domain" data-arg="' + esc(d.name) + '">' +
          '<b>' + esc(d.name) + '</b><span>' + d.count + ' datasets</span></button>';
      }).join('') + '</div></div>';
  }

  /* --- search ------------------------------------------------------------ */
  function viewSearch(st) {
    var r = results(st);
    return '<div class="search-shell" id="search-shell">' + ic('search', 18) +
      '<input id="q" value="' + esc(st.q) + '" data-act="q" placeholder="Search datasets, tables, columns…" ' +
      'aria-label="Search the catalog">' +
      '<span class="muted">' + r.length + ' result' + (r.length === 1 ? '' : 's') + '</span></div>' +
      '<div class="results-toolbar"><span class="muted">' +
      (st.domain ? 'Filtered to ' + esc(st.domain) : 'All domains') + '</span>' +
      ['attrition', 'customer', 'churn', 'reference'].map(function (t) {
        return '<button class="chip' + (st.q === t ? ' on' : '') + '" data-act="q" data-arg="' + t + '">' + t + '</button>';
      }).join('') +
      (st.domain ? '<button class="chip on" data-act="domain" data-arg="">' + esc(st.domain) + ' ✕</button>' : '') +
      '</div>' +
      (r.length ? r.map(function (d) { return dsCard(d, st); }).join('')
        : '<div class="panel"><p class="muted">No datasets match that search.</p></div>');
  }

  function dsCard(d, st) {
    return '<button class="ds-card' + (st.picked === d.id ? ' on' : '') + (d.verified ? '' : ' weak') +
      '" id="ds-' + d.id + '" data-act="open" data-arg="' + d.id + '"><div>' +
      '<div class="ds-title"><b>' + esc(d.name) + '</b>' + verifiedPill(d.verified) + classPill(d.classification) +
      (d.isRef ? '<span class="tag">reference</span>' : '') + '</div>' +
      '<div class="ds-path">' + esc(d.schema + '.' + d.table) + '</div>' +
      '<div class="ds-desc">' + esc(d.description) + '</div>' +
      '<div class="ds-meta">' +
      '<span><b>' + d.quality + '%</b> quality</span>' +
      '<span><b>' + esc(d.rows) + '</b> rows</span>' +
      '<span><b>' + d.queries30d.toLocaleString() + '</b> queries · 30d</span>' +
      '<span><b>' + d.consumers + '</b> teams</span>' +
      '<span>updated ' + esc(d.updated) + '</span></div>' +
      (d.verified ? '' : '<div class="ds-warn">No owner of record and no refresh in 14 months. Cannot be requested.</div>') +
      '</div><div class="ds-right">' + ownerRow(d.owner) +
      '<span class="muted" style="font-size:11.5px">' + esc(d.domain) + '</span></div></button>';
  }

  /* --- dataset detail ---------------------------------------------------- */
  function viewDetail(st) {
    var d = ds(st.picked) || ds('cust-360');
    var tabs = [['overview', 'Overview'], ['columns', 'Columns'], ['quality', 'Quality'],
      ['lineage', 'Lineage'], ['access', 'Access']];
    var body = { overview: tabOverview, columns: tabColumns, quality: tabQuality,
      lineage: tabLineage, access: tabAccess }[st.tab] || tabOverview;
    return '<div class="detail-header">' +
      '<div class="ds-title"><h1>' + esc(d.name) + '</h1>' + verifiedPill(d.verified) + classPill(d.classification) + '</div>' +
      '<div class="ds-path">' + esc(d.schema + '.' + d.table) + '</div>' +
      '<p class="ds-desc" style="margin-top:10px">' + esc(d.description) + '</p>' +
      '<div>' + d.tags.map(function (t) { return '<span class="tag">' + esc(t) + '</span>'; }).join('') + '</div>' +
      '<div class="detail-stats">' +
      '<div class="detail-stat"><b>' + d.quality + '%</b><span>Quality score</span></div>' +
      '<div class="detail-stat"><b>' + esc(d.rows) + '</b><span>Rows</span></div>' +
      '<div class="detail-stat"><b>' + d.queries30d.toLocaleString() + '</b><span>Queries · 30d</span></div>' +
      '<div class="detail-stat"><b>' + d.consumers + '</b><span>Consuming teams</span></div>' +
      '<div class="detail-stat"><b>' + esc(d.updated) + '</b><span>Last updated</span></div>' +
      '</div></div>' +
      '<div class="tabs">' + tabs.map(function (t) {
        return '<button class="tab' + (t[0] === st.tab ? ' on' : '') + '" data-act="tab" data-arg="' + t[0] + '">' +
          t[1] + '</button>';
      }).join('') + '</div>' +
      '<div class="detail-grid"><div>' + body(st, d) + '</div>' + sidebar(d) + '</div>';
  }

  function sidebar(d) {
    return '<aside><div class="side-card"><div class="panel-h">Owner</div>' + ownerRow(d.owner) +
      '<div class="muted" style="font-size:12px;margin-top:6px">' + esc(d.owner.team) + '</div></div>' +
      '<div class="side-card"><div class="panel-h">Service</div><dl class="kv">' +
      '<dt>SLA</dt><dd>' + esc(d.sla) + '</dd>' +
      '<dt>Refresh</dt><dd>' + esc(d.refresh) + '</dd>' +
      '<dt>Sensitivity</dt><dd>' + esc(d.sensitivity) + '</dd>' +
      '<dt>Retention</dt><dd>' + esc(d.retention) + '</dd>' +
      '<dt>Domain</dt><dd>' + esc(d.domain) + '</dd></dl></div>' +
      '<div class="side-card"><div class="panel-h">Distributions</div>' +
      d.distributions.map(function (x) {
        return '<div style="margin-bottom:12px"><b style="font-size:12.5px">' + esc(x.platform) + '</b>' +
          '<div class="mono" style="color:var(--ink-4);word-break:break-all;margin:3px 0">' + esc(x.path) + '</div>' +
          '<div class="muted" style="font-size:11.5px">' + esc(x.size) + ' · ' + esc(x.region) + '</div></div>';
      }).join('') + '</div></aside>';
  }

  function tabOverview(st, d) {
    return '<div class="panel"><div class="panel-h">Description</div>' +
      '<p style="font-size:13.5px">' + esc(d.description) + '</p></div>' +
      '<div class="panel"><div class="panel-h">Upstream lineage</div>' +
      '<div class="lineage-mini">' + d.lineage.map(function (n, i) {
        return (i ? '<span class="lineage-arrow">→</span>' : '') +
          '<span class="lineage-node' + (i === d.lineage.length - 1 ? ' final' : '') + '">' + esc(n) + '</span>';
      }).join('') + '</div></div>';
  }

  function tabColumns(st, d) {
    if (!d.columns.length) {
      return '<div class="panel"><p class="muted">No schema recorded for this asset.</p></div>';
    }
    return '<div class="panel" style="padding:0"><table class="cols-table">' +
      '<thead><tr><th>Column</th><th>Type</th><th>Protection group</th></tr></thead><tbody>' +
      d.columns.map(function (c) {
        return '<tr' + (c.coded ? ' id="coded-col"' : '') + '><td><code>' + esc(c.name) + '</code>' +
          (c.pk ? ' <span class="tag">PK</span>' : '') +
          (c.pii ? ' <span class="pill pill--bad">' + ic('lock', 11) + 'PII</span>' : '') +
          (c.coded ? ' <span class="pill pill--warn">' + ic('warn', 11) + 'coded</span>' : '') +
          '<div class="col-desc">' + esc(c.desc) + '</div></td>' +
          '<td class="mono">' + esc(c.type) + '</td>' +
          '<td class="mono">' + esc(c.pg) + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }

  function tabQuality(st, d) {
    return '<div class="panel" id="quality"><div class="panel-h">Quality by dimension · rolling 30 days</div>' +
      QUALITY_DIMS.map(function (q) {
        var under = q.v < QUALITY_TARGET;
        return '<div class="qbar"><span class="bar-l">' + esc(q.name) + '</span>' +
          '<span class="qbar-t">' +
          '<span class="qbar-f' + (under ? ' warn' : '') + '" style="width:' + q.v + '%"></span>' +
          '<span class="qbar-mark" style="left:' + QUALITY_TARGET + '%"></span></span>' +
          '<span class="qbar-v' + (under ? ' under' : '') + '">' + q.v + '%</span></div>';
      }).join('') +
      '<div class="qbar-key"><i></i>Target ' + QUALITY_TARGET + '% · scale is 0–100, not zoomed</div>' +
      '<p class="muted" style="font-size:12.5px;margin-top:10px">Overall ' +
      '<b style="color:var(--ink)">' + d.quality + '%</b>.</p></div>' +
      '<div class="panel"><div class="panel-h">Freshness against the SLA</div><dl class="kv">' +
      '<dt>Promised</dt><dd>' + esc(d.refresh) + ' · ' + esc(d.sla) + '</dd>' +
      '<dt>Actual</dt><dd>Last load completed 02:14 ET — 2h ago</dd>' +
      '<dt>Breaches, 12m</dt><dd>1 (source outage, consumers notified in 11 minutes)</dd></dl></div>';
  }

  function tabLineage(st, d) {
    return '<div class="panel"><div class="panel-h">Upstream</div>' +
      '<div class="lineage-mini">' + d.lineage.map(function (n, i) {
        return (i ? '<span class="lineage-arrow">→</span>' : '') +
          '<span class="lineage-node' + (i === d.lineage.length - 1 ? ' final' : '') + '">' + esc(n) + '</span>';
      }).join('') + '</div></div>' +
      '<div class="panel"><div class="panel-h">Downstream consumers</div>' +
      '<div class="lineage-mini">' +
      ['Board Attrition Dashboard', 'OSFI Regulatory Return', 'Churn Propensity Model', 'Marketing Segments']
        .map(function (n) { return '<span class="lineage-node">' + esc(n) + '</span>'; }).join('') + '</div></div>';
  }

  function tabAccess(st, d) {
    var pur = st.purpose ? PURPOSES.filter(function (p) { return p.id === st.purpose; })[0] : null;
    return '<div class="panel" id="oblig"><div class="panel-h">Data use obligations</div>' +
      OBLIGATIONS.map(function (o) {
        return '<div style="display:grid;grid-template-columns:auto 1fr;gap:11px;padding:9px 0;border-bottom:1px solid var(--line-2)">' +
          (o.effect === 'limited'
            ? '<span class="pill pill--warn">' + ic('lock', 11) + 'Limited</span>'
            : '<span class="pill pill--ok">' + ic('check', 11) + 'Allowed</span>') +
          '<div><div style="font-size:13.5px">' + esc(o.rule) + '</div>' +
          '<div class="muted" style="font-size:12px;margin-top:2px">' + esc(o.pg) + '</div></div></div>';
      }).join('') + '</div>' +
      '<div class="panel" id="purposes"><div class="panel-h">Request access · declare a purpose</div>' +
      PURPOSES.map(function (p) {
        return '<button class="opt' + (st.purpose === p.id ? ' on' : '') + '" data-act="purpose" data-arg="' + p.id + '">' +
          '<i></i><span><b>' + esc(p.label) + '</b><span>Typical turnaround: ' + esc(p.turnaround) + '</span></span></button>';
      }).join('') +
      (pur
        ? (pur.decision === 'auto' ? verdict('ok', 'Approved automatically in ' + pur.turnaround, pur.why)
          : pur.decision === 'blocked' ? verdict('bad', 'Request refused', pur.why)
          : verdict('warn', 'Routed for approval · ' + pur.turnaround, pur.why))
        : '') + '</div>';
  }

  /* --- saved insight ------------------------------------------------------ */
  function viewInsight() {
    var max = Math.max.apply(null, INSIGHT.byTenure.map(function (b) { return b.v; }));
    return '<div class="panel" id="insight"><div class="panel-h">Q3 retail attrition by tenure band</div>' +
      '<div class="bars">' + INSIGHT.byTenure.map(function (b) {
        return '<div class="bar"><span class="bar-l">' + esc(b.label) + '</span>' +
          '<span class="bar-t"><span class="bar-f' + (b.hot ? ' hot' : '') + '" style="width:' +
          (b.v / max * 100).toFixed(1) + '%"></span></span>' +
          '<span class="bar-v">' + b.v + '%</span></div>';
      }).join('') + '</div>' +
      '<p style="font-size:14px;margin-top:16px"><b>' + esc(INSIGHT.finding) + '</b></p>' +
      '<p class="muted" style="font-size:13px;margin-top:8px">' + esc(INSIGHT.action) + '</p></div>' +
      '<div class="panel"><div class="panel-h">Provenance</div><dl class="kv">' +
      '<dt>Source</dt><dd class="mono">enterprise.customer.customer_360_profile</dd>' +
      '<dt>Reference</dt><dd class="mono">reference.attrition_reason_codes</dd>' +
      '<dt>Access</dt><dd>Granted 6 minutes after request · purpose: attrition analysis</dd>' +
      '<dt>Masked</dt><dd>3 columns withheld for this role</dd>' +
      '<dt>Lineage</dt><dd>CIF Mainframe → KYC Hub → Marketing Profile Store → Customer 360</dd>' +
      '</dl></div>';
  }

  /* --- DataMate ----------------------------------------------------------- */
  function bubble(who, html, id, wide) {
    return '<div class="cb-msg ' + who + '"' + (id ? ' id="' + id + '"' : '') + '>' +
      '<span class="cb-avatar">' + (who === 'ai' ? ic('spark', 14) : 'DO') + '</span>' +
      '<div class="cb-bubble' + (wide ? ' cb-wide' : '') + '">' + html + '</div></div>';
  }

  function viewChat(st) {
    var joined = st.joinRef !== 'no';
    var E = CHAT.exec;
    var out = bubble('me', '<p>' + esc(CHAT.prompt) + '</p>') +
      bubble('ai', '<p>Working from <b>enterprise.customer.customer_360_profile</b>. Before I write anything:</p>' +
        '<ul>' + CHAT.grounding.map(function (g) { return '<li>' + esc(g) + '</li>'; }).join('') + '</ul>', 'dm-ground') +
      bubble('ai', '<p><b>' + esc(CHAT.recTitle) + '</b></p><p>' + esc(CHAT.rec) + '</p>' +
        (st.joinRef ? '' : '<div class="cb-actions">' +
          '<button class="btn btn--sm" data-act="join" data-arg="yes">' + esc(CHAT.yes) + '</button>' +
          '<button class="btn btn--sm btn--ghost" data-act="join" data-arg="no">' + esc(CHAT.no) + '</button></div>'),
        'dm-rec');

    if (st.joinRef === 'yes') {
      out += bubble('me', '<p>' + esc(CHAT.yes) + '</p>') +
        bubble('ai', '<p>Joining <b>reference.attrition_reason_codes</b> — verified, maintained by ' +
          'Aisha Sharma, open to all staff.</p>');
    } else if (st.joinRef === 'no') {
      out += bubble('me', '<p>' + esc(CHAT.no) + '</p>') + bubble('ai', '<p>' + esc(CHAT.declined) + '</p>');
    }

    if (st.joinRef) {
      out += bubble('ai',
        '<div class="nb"><div class="nb-bar"><span class="nb-in">In [1]:</span>' +
        '<span>DataMate · generated SQL · BigQuery</span></div>' +
        '<pre class="sql"><code>' + esc(joined ? CHAT.sqlJoined : CHAT.sqlRaw) + '</code></pre></div>' +
        '<p>' + esc(CHAT.ask) + ' Estimated scan: ' + esc(E.bytes) + '.</p>' +
        (st.ran || st.edited ? '' : '<div class="cb-actions">' +
          '<button class="btn btn--sm" data-act="run">Run it</button>' +
          '<button class="btn btn--sm btn--ghost" data-act="edit">Let me edit it first</button></div>'),
        'dm-sql', true);
    }
    if (st.edited) {
      out += bubble('me', '<p>Hold on — restrict it to Q3 only, and keep the top ten.</p>') +
        bubble('ai', '<p>Updated: the period filter is 1 July to 30 September and the limit stays at ten. ' +
          '<b>Nothing has been executed yet.</b> Shall I run it now?</p>' +
          (st.ran ? '' : '<div class="cb-actions"><button class="btn btn--sm" data-act="run">Run it</button></div>'),
          null, true);
    }
    if (st.ran) {
      out += bubble('me', '<p>Run it.</p>') +
        bubble('ai',
          '<div class="nb"><div class="nb-bar"><span class="nb-in">Out [1]:</span>' +
          '<span>' + E.returned + ' rows · ' + esc(E.seconds) + 's · ' + esc(E.scanned) + ' scanned</span></div>' +
          '<div class="nb-out"><table class="cols-table"><thead><tr>' +
          '<th>Tenure band</th><th>Leaving reason</th><th>Customers lost</th><th>% of band</th></tr></thead><tbody>' +
          CHAT.rows.map(function (r) {
            return '<tr><td>' + esc(r.band) + '</td><td>' +
              (joined ? '<b>' + esc(r.label) + '</b>' : '<code>' + esc(r.code) + '</code>') +
              '</td><td class="mono">' + esc(r.lost) + '</td><td class="mono">' + esc(r.pct) + '</td></tr>';
          }).join('') + '</tbody></table></div></div>' +
          '<p>' + E.masked + ' columns were masked for your role before the query ran.</p>' +
          '<div class="cb-actions"><button class="btn btn--sm" data-act="save">Save to my insights</button></div>',
          'dm-out', true);
    }
    return out;
  }

  /* =======================================================================
     APP
     ==================================================================== */

  function App() {
    var s = useState({
      screen: 'task', tab: 'overview', q: 'attrition', picked: null, domain: null,
      purpose: null, chat: false, joinRef: null, edited: false, ran: false
    });
    var st = s[0], setSt = s[1];
    var tr = useState({ run: false, index: 0 });
    var tour = tr[0], setTour = tr[1];
    var caret = useRef(null);

    var patch = useCallback(function (p) { setSt(function (x) { return Object.assign({}, x, p); }); }, []);

    /* the tour drives the product, never the other way round */
    var applyStep = useCallback(function (i) {
      var step = TOUR[i];
      if (!step || !step.state) return;
      var p = {};
      STATE_KEYS.forEach(function (k) { if (k in step.state) p[k] = step.state[k]; });
      setSt(function (x) { return Object.assign({}, x, p); });
    }, []);

    var onJoyride = useCallback(function (data) {
      var status = data.status, type = data.type, action = data.action, index = data.index;
      if (status === JC.STATUS.FINISHED || status === JC.STATUS.SKIPPED || action === JC.ACTIONS.CLOSE) {
        setTour({ run: false, index: 0 });
        return;
      }
      if (type === JC.EVENTS.STEP_AFTER || type === JC.EVENTS.TARGET_NOT_FOUND) {
        var next = index + (action === JC.ACTIONS.PREV ? -1 : 1);
        if (next < 0 || next >= TOUR.length) { setTour({ run: false, index: 0 }); return; }
        /* Pause, move the product into the state the next step needs, bring the
           target into view, then resume. Scrolling while paused matters: if the
           panel moves after Joyride has measured, the spotlight lands off target. */
        setTour(function (t) { return { run: false, index: t.index }; });
        applyStep(next);
        setTimeout(function () {
          setTour({ run: true, index: next });
        }, 220);
      }
    }, [applyStep]);

    var startTour = useCallback(function () {
      applyStep(0);
      setTimeout(function () {
        setTour({ run: true, index: 0 });
      }, 60);
    }, [applyStep]);

    /* one delegated handler for every control on every screen */
    function onClick(ev) {
      var el = ev.target.closest('[data-act]');
      if (!el || el.disabled) return;
      if (el.tagName === 'INPUT') return;
      ev.preventDefault();
      var a = el.dataset.act, v = el.dataset.arg;
      if (a === 'screen') patch({ screen: v });
      else if (a === 'domain') patch({ domain: v || null, screen: 'search' });
      else if (a === 'q') patch({ q: v, picked: null, screen: 'search' });
      else if (a === 'open') {
        var d = ds(v);
        if (!d || !d.verified) return;           /* unverified assets cannot be opened */
        patch({ picked: v, screen: 'detail', tab: 'overview' });
      } else if (a === 'tab') patch({ tab: v });
      else if (a === 'purpose') patch({ purpose: v });
      else if (a === 'join') patch({ joinRef: v });
      else if (a === 'edit') patch({ edited: true });   /* editing must not execute */
      else if (a === 'run') patch({ ran: true });
      else if (a === 'save') patch({ screen: 'insight', chat: false });
    }

    function onInput(ev) {
      var el = ev.target.closest('[data-act]');
      if (!el || el.tagName !== 'INPUT') return;
      caret.current = { id: el.id, p: el.selectionStart };
      patch({ q: el.value, picked: null });
    }

    /* The assistant behaves like any chat: the newest message stays in view.
       This runs during the tour too — the panel is position:fixed, so Joyride
       never recognises it as a scroll parent and will not scroll it for us.
       It fires on the state change, 220ms before the tour resumes and measures,
       so the spotlight is placed against a settled panel. */
    useEffect(function () {
      if (!st.chat) return;
      var box = document.querySelector('.dm-panel .cb-scroll');
      if (box) box.scrollTop = box.scrollHeight;
    }, [st.chat, st.joinRef, st.edited, st.ran, tour.index]);

    useEffect(function () {
      if (!caret.current) return;
      var el = document.getElementById(caret.current.id);
      if (el) { el.focus(); try { el.setSelectionRange(caret.current.p, caret.current.p); } catch (e) {} }
      caret.current = null;
    });

    var view = st.screen === 'task' ? viewHome()
      : st.screen === 'search' ? viewSearch(st)
      : st.screen === 'insight' ? viewInsight()
      : viewDetail(st);

    var crumbs = [['Marketplace', 'task']];
    if (st.screen === 'search') crumbs.push(['Search', null]);
    if (st.screen === 'detail') crumbs.push(['Search', 'search'], [(ds(st.picked) || ds('cust-360')).name, null]);
    if (st.screen === 'insight') crumbs.push(['My insights', null]);

    var railItems = [['home', 'Browse', 'task'], ['db', 'Catalog', 'search'],
      ['compass', 'Discover', null], ['bookmark', 'Saved', 'insight'], ['activity', 'Activity', null]];
    var activeRail = st.screen === 'task' ? 0 : st.screen === 'insight' ? 3 : 1;

    return h('div', { className: 'app' },
      h('aside', { className: 'rail' },
        h('div', { className: 'rail-logo' }, h('i', null, 'S')),
        h('nav', { className: 'rail-nav' }, railItems.map(function (r, i) {
          return h('button', {
            key: r[1], className: 'rail-item' + (i === activeRail ? ' active' : ''),
            onClick: function () { if (r[2]) patch({ screen: r[2] }); },
            dangerouslySetInnerHTML: { __html: ic(r[0], 19) + '<span>' + r[1] + '</span>' }
          });
        }))),
      h('main', { className: 'main' },
        h('div', { className: 'topbar' },
          h('div', { className: 'crumbs' }, crumbs.map(function (c, i) {
            return h(React.Fragment, { key: i },
              i ? h('span', { className: 'sep' }, '/') : null,
              c[1] ? h('a', { onClick: function () { patch({ screen: c[1] }); } }, c[0])
                   : h('span', { className: 'now' }, c[0]));
          })),
          h('div', { className: 'topbar-spacer' }),
          h('div', { className: 'topbar-actions' },
            h('button', {
              className: 'tour-btn', id: 'tour-btn', onClick: startTour,
              dangerouslySetInnerHTML: { __html: ic('spark', 13) + 'Take the tour' }
            }),
            h('div', { className: 'divider-v' }),
            h('button', { className: 'avatar-btn' }, 'DO'))),
        h('div', {
          className: 'content', id: 'view', onClick: onClick, onInput: onInput,
          dangerouslySetInnerHTML: { __html: view }
        }),
        h('div', {
          className: 'foot',
          dangerouslySetInnerHTML: {
            __html: 'Illustrative prototype · built on the Scotia Data Marketplace design in ' +
              '<code class="mono">design/mock.html</code>. Datasets, owners and columns are the ' +
              'synthetic records from that file; all figures are representative, not measured.'
          }
        })),

      /* DataMate — a floating assistant, as in the source */
      st.chat
        ? h('div', { className: 'dm-panel', onClick: onClick },
            h('div', {
              className: 'cb-head',
              dangerouslySetInnerHTML: {
                __html: '<i>' + ic('spark', 15) + '</i><div><b>Scotia DataMate</b>' +
                  '<span>Grounded in the catalog · Customer 360 Profile</span></div>'
              }
            }),
            h('button', {
              className: 'dm-close', style: { position: 'absolute', right: '14px', top: '14px' },
              onClick: function (e) { e.stopPropagation(); patch({ chat: false }); }, 'aria-label': 'Close'
            }, '✕'),
            h('div', { className: 'cb-scroll', dangerouslySetInnerHTML: { __html: viewChat(st) } }),
            h('div', {
              className: 'cb-input',
              dangerouslySetInnerHTML: { __html: ic('spark', 16) + '<span>Ask DataMate anything…</span>' }
            }))
        : h('button', {
            className: 'dm-fab', id: 'dm-fab', onClick: function () { patch({ chat: true }); },
            dangerouslySetInnerHTML: { __html: ic('spark', 16) + 'Ask DataMate' }
          }),

      h(Joyride, {
        steps: TOUR.map(function (s2) {
          return {
            target: s2.target, placement: s2.placement || 'auto', disableBeacon: true,
            content: h('div', null,
              h('div', { className: 'jr-t' }, s2.title),
              h('div', { className: 'jr-b', dangerouslySetInnerHTML: { __html: s2.body } }),
              s2.key ? h('div', { className: 'jr-k' }, s2.key) : null)
          };
        }),
        run: tour.run, stepIndex: tour.index, continuous: true, showProgress: true,
        showSkipButton: true, scrollOffset: 90, disableOverlayClose: true,
        callback: onJoyride,
        locale: { back: 'Back', close: 'Close', last: 'Finish', next: 'Next', skip: 'End tour' },
        styles: {
          options: {
            primaryColor: '#EC111A', textColor: '#1A1A1A', backgroundColor: '#FFFFFF',
            arrowColor: '#FFFFFF', overlayColor: 'rgba(20,20,30,0.55)', width: 420, zIndex: 10000
          },
          tooltipContainer: { textAlign: 'left' },
          buttonNext: { borderRadius: 8, fontSize: 13, fontWeight: 600, padding: '9px 16px' },
          buttonBack: { color: '#5A5A60', fontSize: 13, marginRight: 8 },
          buttonSkip: { color: '#8A8A92', fontSize: 12.5 }
        }
      })
    );
  }

  window.createRoot(document.getElementById('root')).render(h(App));
})();
