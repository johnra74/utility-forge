# Migration Factory — Architecture

A multi-agent system that converts **any** Informatica PowerCenter repository to
Databricks, under audit: **analyse** the repository export, **plan** the
migration, **produce** an equivalent Databricks/PySpark solution, and **track**
every object from discovery to cutover.

Scope is the PowerCenter metamodel, declared construct by construct in
[construct-coverage.md](construct-coverage.md)
([ADR-0006](adr/0006-general-converter-scope.md)). Target is Databricks with
Delta Lake and Unity Catalog
([ADR-0001](adr/0001-databricks-delta-lake-target.md)), behind an emitter-backend
seam ([ADR-0007](adr/0007-extensibility-and-backends.md)).

---

## 1. The shape of the problem

The input is a repository export: `POWERMART` XML describing folders, workflows,
sessions, mappings, transformations, ports, connectors, sources, targets and
tasks. Small in file count, large in semantic surface — the metamodel spans
roughly 30 transformation types, 11 task types, 20 port types and eight
source/target mechanism groups, across repository versions 181–190.

The **reference corpus** (`hhs-payroll`, in `../PowerCenter/`) is one
conformance corpus, used for realism and scale. Its dimensions are illustrative,
not definitional:

| | reference corpus |
| --- | --- |
| Repository exports | 11 (7 Test, 4 Production) |
| Workflows / mappings / transformations | 11 / 108 / 752 |
| Field-level connectors | 30,445 |
| Sources / targets | 87 / 115 |
| Transformation types exercised | 14 of ~30 |
| Worklets, shortcuts, reusable transformations | 0 |

That last row is the reason for
[Article XI](../.specify/memory/constitution.md#article-xi--corpus-independence):
an estate's silence about a construct is not evidence the construct is rare.

Three properties drive the whole architecture.

**Most of the work is deterministic.** Object graphs, port expressions, workflow
DAGs, record layouts, connection bindings and session commands are all *present*
in the XML. They must be parsed, not inferred. Handing 21 MB of XML to a language
model to "summarise the mappings" produces fluent output that is wrong in exactly
the details a migration depends on.

**The residue is genuinely hard judgment.** What a mapping *means*, which of
several defensible Spark shapes to use, whether a predicate is business logic or
an accident, what tolerance a parity test should carry — these need a reasoning
agent with the parsed facts in front of it.

**Coverage is never complete.** Informatica adds constructs, customers use
adapters nobody has seen, and some constructs — Java, External Procedure,
Custom — reference code the repository does not contain and so are *in
principle* unconvertible. The architecture must therefore answer "can you handle
this?" honestly and per construct, and grow coverage by addition rather than by
forking ([ADR-0007](adr/0007-extensibility-and-backends.md)).

The architecture is therefore a **deterministic core with a judging shell and a
declared coverage surface**
([ADR-0005](adr/0005-deterministic-core-agent-boundary.md)), not an agent swarm
that reads XML.

## 2. Layers

```mermaid
flowchart TB
    subgraph corpus["① Input — read-only"]
        XML["Repository exports<br>POWERMART XML"]
        SH["Companion scripts<br>shell, control files"]
        EXT["External evidence<br>parameter files, schedules,<br>XSDs, sample data, env map"]
    end

    subgraph core["② Deterministic core — Python, no model calls"]
        PARSE["Repository parser<br>feature 001"]
        LIN["Lineage resolver<br>feature 001"]
        EXPR["Expression compiler<br>PowerCenter → Spark AST<br>feature 002"]
        EMIT["Code emitters<br>PySpark + pytest + job JSON<br>feature 006"]
        PAR["Parity harness<br>feature 007"]
    end

    subgraph model["③ Canonical model, registry, ledger"]
        CM[("Canonical repository model<br>scope-accurate identity")]
        REG["Construct registry<br>tiers T1-T4, restrictions<br>feature 009"]
        CAT["Pattern catalog + plugins<br>semantics + counter-examples"]
        LED[("Migration ledger<br>state, provenance, approvals<br>feature 003")]
    end

    subgraph agents["④ Agent layer — judgment only"]
        AN["Analyst<br>feature 004"]
        AR["Architect<br>feature 005"]
        CG["Codegen author<br>feature 006"]
        VA["Validation analyst<br>feature 007"]
        RV["Reviewer / constitution gate"]
    end

    subgraph orch["⑤ Orchestration — Temporal + LangGraph feature 008"]
        WF["Per-object migration workflow<br>durable, replayable"]
        HITL["Human approval gates"]
    end

    subgraph out["⑥ Outputs"]
        SPECS["specs/ — spec, plan, tasks per wave"]
        REPO["Generated Databricks repo<br>PySpark modules + tests + jobs"]
        DOCS["Migration docs + burndown"]
    end

    XML --> PARSE --> CM
    SH --> PARSE
    PARSE --> LIN --> CM
    CM --> EXPR
    EXT --> LED
    CM --> COV["Coverage report<br>feature 009"] --> REG
    REG --> CAT

    CM --> AN --> LED
    CM --> AR
    CAT --> AR
    REG --> AR
    AR --> LED
    LED --> CG
    EXPR --> EMIT
    CG --> EMIT --> REPO
    REPO --> PAR --> VA --> LED

    AN --> RV
    AR --> RV
    CG --> RV
    RV --> LED

    WF -.drives.-> AN
    WF -.drives.-> AR
    WF -.drives.-> CG
    WF -.drives.-> VA
    WF --> HITL --> LED

    AR --> SPECS
    LED --> DOCS
```

### ① Input

Read-only. Never written by the factory. A repository export set plus its
companion scripts, and **external evidence** — the material a PowerCenter export
structurally cannot contain: session parameter files, whatever actually triggers
on-demand workflows, XSDs for XML sources, sample data files needed to confirm
packed-decimal encodings, the bodies of Stored Procedure and Java
transformations, and the mapping from repository names to environments.
[Article VII](../.specify/memory/constitution.md#article-vii--gaps-are-first-class-never-assumed-away)
requires all of these be modelled as gaps rather than guessed, and they recur in
every engagement because they are properties of the format.

### ② Deterministic core

Plain Python. No model calls, no network. Fully reproducible: same input digest
in, same bytes out. This is where the existing `PowerCenter/tools/` prototype
graduates into `migration-factory/core/`.

The **expression compiler** ([002](../specs/002-expression-translation/spec.md))
is the most consequential component and the largest departure from the prototype.
Documenting lineage only required knowing *which* ports an expression references,
which a token-matching heuristic answers well enough. *Translating* an expression
requires a real parser and AST, because you must reproduce semantics —
`DECODE`, `IIF`, `IS_SPACES`, `TO_DECIMAL`, and above all the stateful
behaviour of variable ports.

### ③ Canonical model, registry, ledger, pattern catalog

The **canonical model** is the parsed repository, keyed per Article III at the
scope PowerCenter actually declares each object — mapping-scoped for a
transformation declared inside a mapping, folder-scoped for a reusable object, a
source or a target, and worklet-scoped for a task inside a worklet. Shortcuts
carry an identity in the referring folder and a definition resolved from the
referenced one.

The **construct registry** ([009](../specs/009-construct-coverage/spec.md)) is
versioned data, not code: every construct's coverage tier, its restrictions, the
pattern that implements it, the repository-version range it was verified
against, and which conformance corpora exercise it. It is what makes
`mfctl coverage` answerable without converting anything, and what makes a
coverage regression a reviewable diff.

The **ledger** ([003](../specs/003-migration-ledger/spec.md)) is the system of
record for migration state, and the only place approvals live. Postgres, because
this is auditable government work and the state must outlive any agent run.

The **pattern catalog** ([pattern-catalog.md](pattern-catalog.md)) is the shared
semantic contract between the architect who selects a pattern and the emitter
that implements it. Each entry carries PowerCenter semantics — cited to
Informatica's documented behaviour, not inferred from one estate — the Spark
equivalent, the naive translation that is wrong, and the test that distinguishes
them (Article V). A pattern ships as a plugin bundling all three parts, so the
registry cannot reference a pattern whose counter-example is missing
([ADR-0007](adr/0007-extensibility-and-backends.md)).

### ④ Agent layer

Five roles. Each receives parsed facts, never raw XML, and each produces output
that a deterministic checker validates where validation is possible.

| Agent | Feature | Consumes | Produces | Deterministic check on its output |
| --- | --- | --- | --- | --- |
| **Analyst** | [004](../specs/004-semantic-analysis/spec.md) | canonical model for one object | purpose, complexity band, pattern classification, gap list | every cited fact resolves to a model field; every pattern name exists in the catalog |
| **Architect** | [005](../specs/005-migration-planning/spec.md) | analysis + catalog + dependency graph | target Delta design, pattern selection, wave assignment, parity tolerance, `plan.md` | referenced tables exist; wave order respects the dependency graph; every pattern has a counter-example test |
| **Codegen author** | [006](../specs/006-spark-codegen/spec.md) | approved plan + compiled expression ASTs | module docstrings, naming, comments, non-mechanical glue | module imports, compiles, passes generated tests; expression bodies come from the compiler, not the agent |
| **Validation analyst** | [007](../specs/007-parity-validation/spec.md) | parity report | diagnosis of each mismatch, remediation proposal | proposed root cause reproduces the observed diff |
| **Reviewer** | cross-cutting | any artifact | constitution verdict per article | verdict cites article numbers; blocking findings map to gates |

The codegen split matters. The agent does **not** write transformation logic —
expression bodies are compiled deterministically from the PowerCenter AST. The
agent writes what a machine writes badly: names, docstrings, the comment
explaining which construct a line came from, and the readability that Article X
demands.

### ⑤ Orchestration

Temporal for durability, LangGraph for the reasoning graph inside each agent step
([ADR-0002](adr/0002-durable-orchestration.md)). One Temporal workflow instance
per migrated object, one per wave.

Temporal because a 108-object government migration needs: state that survives
process death, retries with backoff on model and Databricks API calls, human
approval as a first-class durable signal that can wait days, and complete replay
of any object's history for audit. LangGraph inside a step because the reasoning
loops — analyse, self-check against the constitution, revise — are graphs, and
Temporal activities are the wrong granularity for them.

### ⑥ Outputs

Spec Kit artifacts under `specs/`, the generated Databricks repository, and
migration reporting driven off the ledger. All regenerable (Article IX): CI
reparses the corpus, re-emits everything, and fails on any diff.

## 3. Per-object state machine

The ledger's core. Every one of the 108 mappings and 11 workflows walks this.

```mermaid
stateDiagram-v2
    [*] --> DISCOVERED
    DISCOVERED --> SCOPED : coverage report; every construct has a tier
    SCOPED --> OUT_OF_SCOPE : contains a T4 unknown construct
    OUT_OF_SCOPE --> SCOPED : coverage extended (plugin + corpus + test)
    SCOPED --> ANALYSED : analyst run passes checks
    ANALYSED --> BLOCKED : blocking gap, or unmet T2 restriction
    BLOCKED --> ANALYSED : gap resolved with evidence
    ANALYSED --> PLANNED : architect produces plan
    PLANNED --> APPROVED : human approval (Art. VIII)
    APPROVED --> GENERATED : emitters produce code + tests
    APPROVED --> MANUAL_PORT : T3 construct; contract emitted
    MANUAL_PORT --> TESTED : hand-written part satisfies the contract
    GENERATED --> TESTED : generated tests pass
    TESTED --> VALIDATED : parity within tolerance (Art. VI)
    TESTED --> GENERATED : parity fails, remediation
    VALIDATED --> CUTOVER : human approval (Art. VIII)
    CUTOVER --> DECOMMISSIONED : legacy job disabled, dual-run window closed
    DECOMMISSIONED --> [*]

    note right of OUT_OF_SCOPE
        T4: not in the registry.
        Extending coverage is a
        visible decision, not a
        silent best effort.
    end note

    note right of MANUAL_PORT
        T3: Java, External Procedure,
        Stored Procedure, adapters.
        Body is not in the repository,
        so a contract is the honest
        deliverable.
    end note
```

`SCOPED` and `OUT_OF_SCOPE` are new in v2 and exist because of
[Article XII](../.specify/memory/constitution.md#article-xii--declared-coverage):
no object may be analysed before every construct in it has a declared tier.
`MANUAL_PORT` is the T3 path — an object that is partly generated and partly
hand-written, which still has to reach parity like any other.

Transitions are append-only events with actor, timestamp, evidence pointer, and
the artifact digest that justified them. Backward transitions require human
approval and never delete history.

## 4. Migration waves from the dependency graph

Wave order is *derived*, not chosen. The algorithm is fixed; the waves it yields
are whatever a given repository implies.

1. Build the producer/consumer graph over every object read, written or looked
   up by each mapping, normalising instance-name suffixes to the underlying
   table.
2. Exclude **shared-infrastructure** objects — those written by three or more
   workflows, typically error and audit logs — because they constrain nothing
   about run order.
3. Topologically sort the remainder. Report cycles for a human ordering
   decision rather than breaking them.
4. Prepend **Wave 0**: the cross-cutting capabilities that are prerequisites for
   every object and are not per-mapping work. Which capabilities land here is
   itself derived from the coverage report — copybook decoding appears only if
   the repository has COBOL sources, an XSD registry only if it has XML sources.

The reference corpus yields the following, as an illustration of the output
shape:

```mermaid
flowchart LR
    W0["Wave 0<br>Foundations"] --> W1["Wave 1<br>Pay calendar"]
    W1 --> W2["Wave 2<br>CPM core"]
    W2 --> W3["Wave 3<br>Agency extracts"]
    W1 --> W4["Wave 4<br>Independent pipelines"]

    W0 -.- W0D["Copybook ingest framework,<br>parameter-file replacement,<br>Delta layout, parity harness"]
    W1 -.- W1D["wf_Pay_Calendar<br>→ PAY_PERIOD<br>read by all 10 others"]
    W2 -.- W2D["wf_CPM<br>→ CPM_NEWPAY_TBL<br>+ Pseudossn (PSEUDOSSN_TBL)"]
    W3 -.- W3D["wf_CPM_NIH, wf_CPM_CDC,<br>wf_CPM_OIG, wf_CPM_AFPS,<br>wf_FDA_Leave"]
    W4 -.- W4D["wf_LES, wf_COMPTIME,<br>wf_EHRP2BIIS_UPDATE"]
```

Read as an example of the algorithm, not as a template: `Pay_Calendar` is the
root because every other workflow resolves its pay period from `PAY_PERIOD`
first; `CPM` is the second root, producing `CPM_NEWPAY_TBL` for the four agency
extracts; `Pseudossn` precedes CPM, LES and FDA, which use `PSEUDOSSN_TBL` as a
lookup. A different repository yields a different shape with the same
derivation.

Wave 0 here contains four capabilities: decoding COBOL copybooks, replacing the
parameter-file mechanism, fixing the Delta/Unity layout, and standing up the
parity harness. The last two are universal; the first appears because this
repository has VSAM sources.

## 5. What runs where

```mermaid
sequenceDiagram
    participant T as Temporal
    participant C as Deterministic core
    participant A as Agent (LangGraph)
    participant L as Ledger
    participant H as Human approver
    participant D as Databricks

    T->>C: parse corpus (digest-keyed, cached)
    C-->>T: canonical model
    T->>A: analyse object (facts only)
    A->>A: classify, self-check vs constitution
    A-->>T: analysis + citations
    T->>C: verify every citation resolves
    C-->>T: ok
    T->>L: record ANALYSED
    T->>A: design target + select patterns
    A-->>T: migration plan
    T->>H: request plan approval
    H-->>T: approved (durable signal, may wait days)
    T->>L: record APPROVED (actor, timestamp)
    T->>C: compile expressions -> Spark AST
    T->>A: author module docstrings + comments
    T->>C: emit PySpark + pytest + job JSON
    C-->>T: generated artifacts
    T->>D: run generated tests
    T->>D: run parity harness vs legacy output
    D-->>T: parity report
    T->>A: diagnose mismatches
    A-->>T: root cause + remediation
    T->>L: record TESTED / VALIDATED
    T->>H: request cutover approval
```

The pattern to notice: **every agent output passes through a deterministic
verifier before it reaches the ledger.** An analysis whose citations do not
resolve is rejected and retried, not recorded with a caveat.

## 6. Component inventory

| Component | Feature spec | Kind | Language |
| --- | --- | --- | --- |
| Repository parser + lineage resolver | [001](../specs/001-repository-ingestion/spec.md) | deterministic | Python (stdlib) |
| Expression compiler | [002](../specs/002-expression-translation/spec.md) | deterministic | Python + Lark |
| Migration ledger | [003](../specs/003-migration-ledger/spec.md) | service | Python + Postgres |
| Semantic analysis agent | [004](../specs/004-semantic-analysis/spec.md) | agent | LangGraph |
| Migration planning agent | [005](../specs/005-migration-planning/spec.md) | agent | LangGraph |
| Spark code generator | [006](../specs/006-spark-codegen/spec.md) | deterministic + agent | Python / PySpark |
| Parity validation harness | [007](../specs/007-parity-validation/spec.md) | deterministic | PySpark |
| Agent orchestration | [008](../specs/008-agent-orchestration/spec.md) | service | Temporal + LangGraph |
| Construct coverage & conformance | [009](../specs/009-construct-coverage/spec.md) | deterministic | Python + registry data |

## 7. Source layout

```
migration-factory/
├── .specify/
│   ├── memory/constitution.md          # Articles I-X, the gates
│   └── templates/                      # spec / plan / tasks / checklist
├── docs/
│   ├── architecture.md                 # this file
│   ├── pattern-catalog.md              # PowerCenter -> Spark semantics
│   └── adr/                            # 0001..0005
├── specs/001-...008-/                  # Spec Kit feature artifacts
├── core/                               # ② deterministic core
│   ├── parse/                          # 001 — version-aware POWERMART reader
│   ├── lineage/                        # 001
│   ├── expr/                           # 002 — grammar, AST, IR lowering
│   ├── emit/                           # 006 — IR -> backend
│   │   ├── ir/                         #       platform-neutral IR
│   │   └── backends/databricks/        #       the one implemented backend
│   ├── coverage/                       # 009 — registry loader, coverage report
│   └── parity/                         # 007
├── patterns/                           # pattern plugins: catalog entry +
│                                       # counter-example test + emitter
├── registry/
│   └── constructs.yaml                 # 009 — tiers, restrictions, versions
├── corpora/
│   ├── synthetic-core/                 # every T1/T2 construct
│   ├── synthetic-identity/             # shortcuts, worklets, reusables
│   ├── synthetic-adversarial/          # the failure modes, deliberately
│   └── hhs-payroll -> ../../PowerCenter  # reference corpus (real)
├── agents/                             # ④ LangGraph graphs + prompts
├── orchestration/                      # ⑤ Temporal workflows and activities
├── ledger/                             # ③ schema, migrations, API
└── generated/                          # ⑥ output repo — never hand-edited
```

## 8. Scope boundaries and non-goals

**Scope is the PowerCenter metamodel**, declared per construct in
[construct-coverage.md](construct-coverage.md). Not every construct is
convertible, and the tiers say which:

- **T1/T2 — converted.** The majority of the metamodel. T2 refuses when a stated
  restriction is unmet rather than guessing.
- **T3 — declared unsupported, by nature.** Java, External Procedure, Custom,
  Stored Procedure, application adapters, messaging and web-service
  transformations reference logic the repository does not contain. No converter
  can translate a Java body that is not there. The deliverable is a
  **manual-port contract**: the interface the hand-written replacement must
  satisfy, plus everything around it generated normally.
- **T4 — refused.** An unknown construct halts the object. Extending coverage is
  a plugin, a corpus fixture and a counter-example test
  ([ADR-0007](adr/0007-extensibility-and-backends.md)) — a visible decision, not
  a silent best effort.

Genuine non-goals:

- **Not an autonomous migrator.** Plan approval and cutover are human decisions
  (Article VIII). The factory removes transcription work, not judgment.
- **Not a rewrite.** The target reproduces PowerCenter behaviour, bugs included,
  so parity means something. Improvements are separate, post-cutover changes with
  their own specs. Every real repository supplies candidates — the reference
  corpus alone has inconsistent predicate placement across sibling mappings,
  drifted notification lists, and a dead transfer script no session calls.
- **Not a discovery tool for what the repository never contained.** Trigger
  schedules for on-demand workflows, parameter-file values, XSDs, and external
  procedure bodies are fieldwork. The converter enumerates them precisely as
  gaps (Article VII) and refuses to invent them.
- **Not a PowerCenter repository manager.** Deployment groups, labels and
  queries describe how the repository is administered, not what it computes.
- **Not a multi-platform code generator today.** The emitter-backend seam exists
  to keep the IR honest and the patterns testable; Databricks/PySpark is the only
  backend implemented and the only one planned
  ([ADR-0007](adr/0007-extensibility-and-backends.md)).
