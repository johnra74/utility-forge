# Pattern Catalog — PowerCenter to Databricks/PySpark

The semantic contract between the **architect** agent, which selects a pattern,
and the **emitter**, which implements it.

Constitution [Article V](../.specify/memory/constitution.md#article-v--semantics-before-syntax)
requires every entry to carry four things: the PowerCenter semantics, the Spark
equivalent, **the naive translation that looks right and is wrong**, and the
counter-example test that distinguishes them. An entry without a counter-example
blocks codegen for that construct.

Entries are keyed to **constructs in the PowerCenter metamodel**, not to
occurrences in any estate
([Article XI](../.specify/memory/constitution.md#article-xi--corpus-independence)).
Semantics are cited to Informatica's documented behaviour; corpus evidence
illustrates a pattern and demonstrates that it matters, but never defines it —
one estate exercises only the paths it happens to use.

Which constructs are convertible at all, and under what restrictions, is
declared in [construct-coverage.md](construct-coverage.md). A pattern ships as a
plugin bundling its catalog entry, its counter-example test and its emitter
([ADR-0007](adr/0007-extensibility-and-backends.md)).

## Pattern index

`observed` counts occurrences in the `hhs-payroll` reference corpus. A zero
means that corpus does not exercise the construct — **not** that the construct
is rare or out of scope. Those rows are covered by `synthetic-core` and
`synthetic-identity` instead.

| Pattern | Construct | Tier | Risk | observed |
| --- | --- | --- | --- | --- |
| [P-01](#p-01-expression-stateless-ports) | Expression, stateless ports | T1 | medium | 345 |
| [P-02](#p-02-expression-stateful-variable-ports) | Expression, stateful variable ports | T2 | **high** | 115 ports |
| [P-03](#p-03-source-qualifier) | Source Qualifier | T1 | medium | 112 |
| [P-04](#p-04-lookup-connected-cached) | Lookup, connected | T1 | **high** | 112 |
| [P-05](#p-05-lookup-sql-override) | Lookup, SQL override | T1 | **high** | 26 |
| [P-06](#p-06-filter) | Filter | T1 | low | 61 |
| [P-07](#p-07-normalizer-vsam-copybook) | Normalizer, VSAM/copybook | T2 | **high** | 23 |
| [P-08](#p-08-aggregator) | Aggregator | T1 | medium | 29 |
| [P-09](#p-09-joiner) | Joiner | T1 | **high** | 27 |
| [P-10](#p-10-router) | Router | T1 | **high** | 7 |
| [P-11](#p-11-update-strategy) | Update Strategy | T2 | **high** | 7 |
| [P-12](#p-12-sorter) | Sorter | T1 | low | 5 |
| [P-13](#p-13-sequence-generator) | Sequence Generator | T2 | **high** | 5 |
| [P-14](#p-14-mapplet) | Mapplet, Input/Output Transformation | T1 | low | 3 |
| [P-15](#p-15-session-shell-commands) | Pre/post-session and standalone Command | T2 | **high** | 17 sessions |
| [P-16](#p-16-mapping-variable-persistence-setvariable) | Mapping variables, `SETVARIABLE` | T1 | **high** | 66 calls |
| [P-17](#p-17-parameter-files) | `$Param_*` parameter files | T2 | **high** | pervasive |
| [P-18](#p-18-powerexchange-mainframe-targets) | PowerExchange non-relational | T3 | **high** | 6 targets |
| [P-19](#p-19-workflow-orchestration) | Workflow, links, scheduler | T1 | medium | 11 |
| [P-20](#p-20-lookup-unconnected) | Lookup, unconnected | T1 | **high** | 0 |
| [P-21](#p-21-normalizer-pipeline) | Normalizer, pipeline | T1 | medium | 16 |
| [P-22](#p-22-union) | Union | T1 | medium | 0 |
| [P-23](#p-23-rank) | Rank | T1 | medium | 0 |
| [P-24](#p-24-transaction-control) | Transaction Control | T2 | **high** | 0 |
| [P-25](#p-25-sql-transformation) | SQL transformation | T2 | **high** | 0 |
| [P-26](#p-26-stored-procedure) | Stored Procedure | T3 | **high** | 0 |
| [P-27](#p-27-xml-parser-generator-and-source-qualifier) | XML Parser / Generator / Source Qualifier | T2 | medium | 0 |
| [P-28](#p-28-decision-assignment-and-control-tasks) | Decision, Assignment, Control, Timer | T1 | medium | 0 |
| [P-29](#p-29-worklets-and-event-tasks) | Worklet, Event-Wait, Event-Raise | T1 | **high** | 0 |
| [P-30](#p-30-shortcuts-and-reusable-objects) | Shortcut, reusable transformation/session | T1 | **high** | 0 |

Fifteen of thirty patterns are high risk, and every one is high risk for the
same reason: the obvious translation runs cleanly and computes the wrong answer.

Note that **six high-risk patterns have zero occurrences in the reference
corpus** — unconnected lookups, transaction control, SQL transformations,
worklets, event tasks, shortcuts and reusable objects. A converter validated
only against that corpus would ship all six untested while reporting success.

---

## P-01 Expression: stateless ports

**PowerCenter.** Output ports evaluate per row in declared port order. Local
variable ports are scratch values evaluated in the same order and are not
emitted.

**Spark.** Each output port becomes a `Column` expression; variable ports become
intermediate expressions inlined or bound to `withColumn` in port order.

```python
# from exp_Initial in m_CPM_NIH_Set_CPM_Calendar
v_param_pp_end_year = F.when(~is_number(P["MAP_PP_END_YEAR"]), F.lit(0)) \
                       .otherwise(to_decimal(P["MAP_PP_END_YEAR"]))
df = df.withColumn("o_PARAM_PP_END_YEAR", v_param_pp_end_year)
```

**Naive translation that is wrong.** Evaluating ports in *dictionary* order
rather than *declared* order. A variable port may reference an earlier variable
port; reordering silently reads an unset value (PowerCenter default, not null).

**Counter-example.** `tests/patterns/test_p01_port_order.py` — a transformation
where `v_b := v_a + 1` is declared after `v_a := 1`. Correct output `2`;
dictionary-ordered evaluation yields `1` or an error.

---

## P-02 Expression: stateful variable ports

**This is the highest-risk pattern in the corpus. 115 instances.**

**PowerCenter.** A local variable port **retains its value across rows**. A
variable port whose expression references itself is a running accumulator,
evaluated in the order rows arrive at the transformation. This is how
PowerCenter writes running totals, previous-row comparisons, and
group-sequence counters.

Real instance —
`Test_Repo_Srvc/CPM/m_CPM_Load_CPM_NEWPAY_STG_ALT_TBL/exp_Determine_Allotments`:

```
v_NEW_EMP_FLAG      := IIF(v_CURR_KEY != v_PREV_KEY, TRUE, FALSE)
v_ALLOTMENT_COUNTER := DECODE(TRUE,
                          v_NEW_EMP_FLAG = TRUE,  1,
                          v_NEW_EMP_FLAG = FALSE, v_ALLOTMENT_COUNTER + 1)
```

That is: sort by employee key, then number each employee's allotment rows
1, 2, 3 … so they can be pivoted into `ALT_1_*`, `ALT_2_*` columns.

**Spark.** A window function over the partition and ordering that the upstream
pipeline actually guarantees:

```python
# v_CURR_KEY != v_PREV_KEY  -> group boundary detection
# v_ALLOTMENT_COUNTER       -> position within the group
w = Window.partitionBy(*key_cols).orderBy(*sort_cols)
df = df.withColumn("v_ALLOTMENT_COUNTER", F.row_number().over(w))
```

The ordering **must** come from the upstream Source Qualifier's
`Number Of Sorted Ports` / `Sql Query` `ORDER BY`, or from an explicit Sorter.
If neither exists, the PowerCenter behaviour was already non-deterministic and
that is a finding for the SME, not something to paper over.

**Naive translation that is wrong.** Treating the port as stateless — emitting
`F.lit(1)` or a per-row `when`. Runs fine, produces `1` for every row, and every
allotment after the first is silently dropped or overwritten in the pivot. No
error, no null, no row-count change. Parity on row count passes.

**Counter-example.** `tests/patterns/test_p02_stateful_variable.py` — six rows
across two employee keys; expected counters `1,2,3,1,2,1`; the stateless
translation yields all `1`s.

**Emitter obligation.** The compiler MUST detect self-reference in a
`LOCAL VARIABLE` port and either emit a window translation with a proven
ordering, or **refuse** and mark the object `BLOCKED` with gap type
`ordering-unproven`. It MUST NOT fall back to a stateless expression.

---

## P-03 Source Qualifier

**PowerCenter.** Generates the SQL that reads the source. Predicates may live in
*any* of `Sql Query` (a full override), `Source Filter` (appended to `WHERE`), or
`User Defined Join` (appended to the join/`WHERE` clause). All three fold into
one statement. `Number Of Sorted Ports = N` adds an `ORDER BY` over the first N
ports.

**Spark.** A read plus `.where()` plus `.orderBy()`, or the override SQL executed
against the source. Predicates push down to the JDBC read.

**Naive translation that is wrong.** Reading only `Source Filter` and assuming an
empty value means no predicate. In this corpus
`m_CPM_NIH_Load_CPM_NIH_Data_File` has an **empty** `Source Filter` and puts the
whole pay-period-and-business-unit predicate in `User Defined Join`, while its
sibling `m_CPM_NIH_Build_Message` puts the identical predicate in
`Source Filter`. Reading one field yields an unfiltered read of a 501-column
payroll master — every pay period, every agency.

**Counter-example.** `tests/patterns/test_p03_predicate_placement.py` — parses
both `SQ_CPM_NEWPAY_TBL` definitions and asserts the compiled predicate is
identical.

**Emitter obligation.** Compile the union of all three attributes; assert that at
least one is non-empty for any source read whose target is a filtered extract.

---

## P-04 Lookup: connected, cached

**PowerCenter.** Reads a table into a cache keyed on the `Lookup condition`,
returns the first matching row's output ports. `Lookup policy on multiple
match = Use Any Value` (the setting in every lookup in this corpus) means the
result on a multi-match is **arbitrary**. Unmatched → all lookup ports null.

**Spark.** A broadcast left-outer join on the lookup condition.

```python
# lkp_PSEUDOSSN_FROM_SDA_TBL: condition SSN = in_SSN
df = df.join(F.broadcast(lkp_df), df["in_SSN"] == lkp_df["SSN"], "left")
```

**Naive translation that is wrong.** An inner join. A lookup miss in PowerCenter
yields nulls and the row survives; an inner join deletes the row. In
`m_CPM_Load_CPM_NEWPAY_STG_TYPE_1_2_TBL` a pseudo-SSN lookup miss is a normal,
expected condition — inner-joining drops real employees from the payroll master.

A second, subtler error: leaving a multi-match unresolved. `Use Any Value` is
non-deterministic in PowerCenter, so a left join that fans out changes the row
count. The plan MUST pin an explicit tie-break with the SME and record it.

**Counter-example.** `tests/patterns/test_p04_lookup_miss_and_fanout.py` — one
row with no match (must survive with nulls) and one with two matches (must not
fan out).

---

## P-05 Lookup: SQL override

**PowerCenter.** `Lookup Sql Override` replaces the generated lookup query
entirely; the `Lookup condition` is then applied to *that* result set. 26 of the
112 lookups in this corpus use one, several aggregating:

```sql
SELECT COUNT(*) as COUNT_TOTAL FROM PAY_PERIOD
WHERE PP_END_YEAR = TO_NUMBER('$$MAP_PP_END_YEAR')
  AND PP_NUM      = TO_NUMBER('$$MAP_PP_NUM')
-- condition: COUNT_TOTAL >= in_CONSTANT
```

**Spark.** Execute the override as a query against the source, then join on the
condition. Note the condition here is `>=`, not equality — a non-equi join.

**Naive translation that is wrong.** Ignoring the override and reading
`Lookup table name` directly. You would read all of `PAY_PERIOD` instead of a
scalar count, and the `>=` condition would match a different number of rows.
Also wrong: assuming `Lookup condition` is always equality — this corpus proves
otherwise.

**Counter-example.** `tests/patterns/test_p05_sql_override_nonequi.py`.

---

## P-06 Filter

**PowerCenter.** Rows where `Filter Condition` is true pass; false **and null**
are dropped.

**Spark.** `.where(condition)` — matching semantics, since `where` also drops
nulls.

**Naive translation that is wrong.** Writing `.where(~F.col("x"))` for a negated
condition. Null negated is still null, so both branches drop null rows and rows
vanish from *both* sides of what should be a partition. Use
`F.coalesce(cond, F.lit(False))` when the two branches must be complementary.

**Counter-example.** `tests/patterns/test_p06_null_condition.py`.

---

## P-07 Normalizer: VSAM copybook

**PowerCenter.** For a COBOL source, splits one physical record into multiple
output rows and generates two special ports: a **GCID** (generated column id,
identifying which `OCCURS` slot a row came from) and a **generated key**. Every
normalizers in this corpus carry `ISVSAM_NORMALIZER=YES`; the other 16 of the
39 are pipeline normalizers, which do not read a copybook and must not be given
the fixed-width treatment below.

The upstream source is a multi-record fixed-width file where each top-level
`GRPITEM` `REDEFINES` the same bytes. `YTD_FILE` has three layouts over the same
1,050-byte record; `MER_FILE` has a 700-byte header layout and a 768-byte detail
layout.

**Spark.** Two steps, both explicit:

```python
# 1. read raw fixed-width lines, discriminate the record type
raw = spark.read.text(path)
rec_type = F.substring("value", 1, 1)          # DFAS_YTD_RECORD_TYPE1 at offset 0

# 2. per layout, slice by offset/length from the copybook, then explode OCCURS
detail = raw.where(rec_type == "2").select(*[
    F.substring("value", f.offset + 1, f.length).alias(f.name)
    for f in layout("DFAS_YTD_DETAIL").leaves
])
# OCCURS n -> posexplode gives the GCID
exploded = detail.select("*", F.posexplode(F.array(*slots)).alias("GCID", "value"))
```

**Naive translations that are wrong.** Three, all common:

1. Reading the file as CSV or by whitespace. These are fixed-width records with
   no delimiter; `LINESEQUENTIAL=YES`, `DELIMITED=NO`.
2. Using `explode` instead of `posexplode`. `explode` discards the occurrence
   index, which *is* the GCID and is frequently a business key.
3. Treating `PICTURE +9(3)V9(2)` as a plain string or float. `V` is an **implied
   decimal point with no byte on disk**, and `USAGE_FLAGS=TRAILING_SIGN` means
   the sign is carried in the last byte. Read as text and divided by 100 by
   guesswork, monetary amounts are wrong by factors of ten and negatives become
   positive.

**Counter-example.** `tests/patterns/test_p07_copybook_decode.py` — fixture bytes
for `+9(3)V9(2)` covering a positive, a negative, and a zero-filled value;
asserts exact `Decimal` results.

**Gap.** The physical encoding of packed/signed fields MUST be confirmed against
a real data file before any object using it leaves `PLANNED` (Article VII).

---

## P-08 Aggregator

**PowerCenter.** Groups by the ports flagged `EXPRESSIONTYPE=GROUPBY`. **With no
group-by ports it produces exactly one row over the whole input.** Aggregate
functions ignore nulls. `FIRST`/`LAST` depend on input order.

**Spark.** `.groupBy(*group_cols).agg(...)`, or `.agg(...)` with no `groupBy` for
the single-group case.

**Naive translation that is wrong.** Assuming a group-by always exists. Several
counter mappings here aggregate with none — `agg_Count_CPM_NIH` computes
`COUNT(*)` over everything to build the record-count trailer that the receiving
agency reconciles against. Inventing a group-by turns one trailer row into
thousands.

Also wrong: translating `FIRST`/`LAST` (108 and 31 uses) without an explicit
ordering. Spark's `first`/`last` are non-deterministic without a window.

**Counter-example.** `tests/patterns/test_p08_no_groupby.py`.

---

## P-09 Joiner

**PowerCenter.** Joins two pipelines on `Join Condition`. `Join Type` is one of
Normal, Master Outer, Detail Outer, Full Outer. The **master** is the cached
side, marked by ports with `PORTTYPE` containing `MASTER`.

**Spark.** `.join(other, cond, how)` with a mapped join type.

**Naive translation that is wrong.** Mapping "Master Outer" to `"left"`.
PowerCenter's naming is the reverse of the SQL intuition:

| PowerCenter | Keeps all rows from | Spark `how` |
| --- | --- | --- |
| Normal Join | matching only | `inner` |
| Master Outer Join | **detail** | `right` (detail is the right side) |
| Detail Outer Join | **master** | `left` |
| Full Outer Join | both | `full_outer` |

A "Master Outer" join translated as `left` retains the wrong side and silently
drops unmatched detail rows.

**Counter-example.** `tests/patterns/test_p09_master_detail_outer.py` — asserts
row counts for all four types with unmatched rows on each side.

---

## P-10 Router

**PowerCenter.** Evaluates every output group's condition against every row and
sends the row to **every group whose condition is true** — a row can leave
through more than one branch. The `DEFAULT` group receives only rows that matched
*no* other group.

Real instance —
`Prd_Repo_Srvc/LES/m_LES_Load_LES_EMP_DETAIL_TBL/rtr_GOOD_BAD_RECORDS`:

| # | Group | Condition |
| --- | --- | --- |
| 1 | `GOOD_RECORDS` | `TRUE` |
| 2 | `BAD_RECORDS` | `ERROR_FLAG = TRUE` |
| 3 | `DEFAULT1` | default |

Because group 1 is literally `TRUE`, **every** row goes to `GOOD_RECORDS`, and
error rows *additionally* go to `BAD_RECORDS`. The bad rows are written to both
`LES_EMP_DETAIL_TBL` and `ERROR_TBL`. That is the intended behaviour and it is
invisible if you read the router as a switch.

**Spark.** One independent filtered DataFrame per group, all derived from the
same input:

```python
good    = df.where(F.lit(True))
bad     = df.where(F.col("ERROR_FLAG") == True)
default = df.where(~(F.lit(True) | (F.col("ERROR_FLAG") == True)))
```

**Naive translation that is wrong.** An if/elif chain, or `otherwise`. Under
if/elif the `TRUE` group consumes every row and `BAD_RECORDS` receives nothing —
`ERROR_TBL` silently stops being populated. Row counts on the primary target are
*identical*, so count-based parity passes and the error feed dies quietly.

**Counter-example.** `tests/patterns/test_p10_router_multicast.py` — asserts a
row satisfying two groups appears in both outputs.

---

## P-11 Update Strategy

**PowerCenter.** `Update Strategy Expression` returns `DD_INSERT` (0),
`DD_UPDATE` (1), `DD_DELETE` (2) or `DD_REJECT` (3) per row.
`Forward Rejected Rows` controls whether rejects continue downstream.

Real instance —
`Prd_Repo_Srvc/Pseudossn/m_Pseudossn_Update_Timekeeper_Number/upd_Update_TK_NUM`:
expression `DD_UPDATE`, `Forward Rejected Rows = YES`.

**Spark.** `MERGE INTO` on Delta, with the flag driving the clauses:

```sql
MERGE INTO pseudossn_tbl t
USING updates s ON t.SSN = s.SSN AND t.PP_END_YEAR = s.PP_END_YEAR
WHEN MATCHED AND s._dd_flag = 1 THEN UPDATE SET ...
WHEN MATCHED AND s._dd_flag = 2 THEN DELETE
WHEN NOT MATCHED AND s._dd_flag = 0 THEN INSERT ...
```

**Naive translation that is wrong.** `df.write.mode("overwrite")` or
`mode("append")`. A constant `DD_UPDATE` mapping is a **targeted column update on
existing rows**; overwrite destroys every row the mapping did not select, and
append duplicates keys. This mapping updates only the timekeeper number on rows
it matched — an overwrite would erase the rest of `PSEUDOSSN_TBL`.

The merge key is **not** in the XML. It must come from the target's `KEYTYPE`
fields plus SME confirmation, and is a required field of the migration plan.

**Counter-example.** `tests/patterns/test_p11_merge_preserves_unselected.py` —
target has 5 rows, update selects 2; asserts 5 rows remain and only 2 changed.

---

## P-12 Sorter

**PowerCenter.** Sorts on ports flagged `ISSORTKEY` per `SORTDIRECTION`.
`Distinct = YES` de-duplicates on the sort keys only.

**Spark.** `.orderBy(...)`, plus `.dropDuplicates(sort_keys)` when distinct.

**Naive translation that is wrong.** `.distinct()` for `Distinct = YES`.
PowerCenter de-duplicates on the **sort keys**; `.distinct()` uses all columns
and therefore keeps rows PowerCenter would have collapsed.

**Counter-example.** `tests/patterns/test_p12_distinct_on_keys.py`.

---

## P-13 Sequence Generator

**PowerCenter.** Emits `NEXTVAL` from persistent repository state, honouring
`Start Value`, `Increment By`, `End Value`, `Cycle`, and
`Is Current Value Shared`. The current value **survives between runs**.

**Spark.** A Delta `GENERATED BY DEFAULT AS IDENTITY` column, or an explicit
sequence-state Delta table read and written transactionally per run.

**Naive translation that is wrong.** `F.monotonically_increasing_id()` or
`row_number()`. Neither is contiguous, neither honours the start value or
increment, and — decisively — neither persists across runs. Keys collide with
existing rows on the second run, or gap unboundedly. If a generated key was ever
exported to a downstream agency, non-reproducible keys break their
reconciliation.

**Counter-example.** `tests/patterns/test_p13_sequence_persistence.py` — two
consecutive runs must not reissue a value.

---

## P-14 Mapplet

**PowerCenter.** A reusable sub-pipeline exposing ports via Input and Output
Transformations. This corpus has one, `mplt_Convert_Num_To_Prec7`, called from
`m_CPM_Load_CPM_NEWPAY_STG_ALT_TBL`.

**Spark.** A plain Python function taking and returning a DataFrame, in a shared
module.

**Naive translation that is wrong.** Resolving the mapplet's internal
transformations at folder scope. Its ports are exposed only through its
Input/Output Transformations; the instance in the calling mapping has no ports of
its own, which is precisely what broke the first validation run of the
documentation generator.

**Counter-example.** `tests/patterns/test_p14_mapplet_ports.py`.

---

## P-15 Session shell commands

**PowerCenter.** Sessions carry pre-session and post-session `Command` tasks
performing **real data movement invisible to lineage**:

```sh
# post-session success, s_CPM_NIH_Concatenate_Files
cd $Param_Root_Directory/data/int/out/CPM
cat $Param_CPM_NIH_HDR_filename $Param_CPM_NIH_DAT_filename > $Param_CPM_NIH_out_filename

# post-session success, s_CPM_NIH_Build_Message
cp $Param_CPM_NIH_out_filename NIHPAYMASTER.PP$$WF_PP_YEAR_NUM
/home/sa-infoadm/scripts/nih_cpm_transfer.sh NIHPAYMASTER.PP$$WF_PP_YEAR_NUM
```

Six workflows also use a dummy-source mapping (`HI_GENERIC_SRC_TBL` →
`GENERIC_TARGET_FILE`) whose mapping does nothing at all; the entire step is the
shell command.

**Spark / Databricks.** Explicit pipeline tasks, not shell:

- header/detail concatenation → an ordered `union` written as a single file, or
  a `coalesce(1)` text write with a controlled row order;
- SFTP delivery → a separate, retryable Databricks Workflows task with the
  destination and credentials in Unity Catalog, replacing the eight ksh scripts;
- `remove_file.sh` pre-session cleanup → idempotent overwrite semantics, which
  Delta gives you for free.

**Naive translation that is wrong.** Migrating only the mappings. A dummy-source
mapping translates to a no-op that runs green while the delivered file is never
built. Every agency stops receiving data and every job succeeds.

**Counter-example.** `tests/patterns/test_p15_concat_order.py` — asserts header
precedes detail byte-for-byte.

**Emitter obligation.** Ingestion (001) MUST extract every session command as a
first-class pipeline step. A mapping whose only real effect is a shell command
MUST be flagged `shell-only` so it cannot be silently marked complete.

---

## P-16 Mapping variable persistence (`SETVARIABLE`)

**PowerCenter.** `SETVARIABLE($$MAP_X, value)` writes a mapping variable whose
value **persists in the repository after the session ends**. Post-session
variable assignment then copies it to a workflow variable, which the next
session reads, and which shell commands interpolate into filenames.

66 calls in this corpus. The chain that produces a delivered filename is:

```
PAY_PERIOD table
  -> lkp_Current_Pay_Period
  -> exp_Set_Parameters: SETVARIABLE($$MAP_PP_YEAR_NUM, v_PAY_PERIOD)
  -> post-session: $$WF_PP_YEAR_NUM := $$MAP_PP_YEAR_NUM
  -> post-session command: cp ... NIHPAYMASTER.PP$$WF_PP_YEAR_NUM
  -> nih_cpm_transfer.sh NIHPAYMASTER.PP$$WF_PP_YEAR_NUM
```

**Spark / Databricks.** An explicit run-context table in Delta plus Workflows
task-value passing (`dbutils.jobs.taskValues`). The run context is written once
by the pay-calendar resolution task and read by every downstream task.

**Naive translation that is wrong.** Treating `SETVARIABLE` as a no-op returning
its second argument. It does return that value, so the expression compiles and
the row-level output matches — but the persistence is lost, the workflow variable
stays empty, and the delivered file is named `NIHPAYMASTER.PP` with no pay
period. Every parity check on table contents passes.

**Counter-example.** `tests/patterns/test_p16_variable_propagation.py` —
end-to-end assertion that the resolved pay period reaches the output filename.

---

## P-17 Parameter files

**PowerCenter.** `$Param_*` values come from a session parameter file supplied at
runtime. **Not present in this export.** Every output filename, every root
directory, and the control-script directory are `$Param_*` values.

**Spark / Databricks.** Databricks Workflows job parameters, with defaults in a
Delta configuration table and secrets in a Unity Catalog secret scope.

**Naive translation that is wrong.** Inferring a value from the surrounding
commands. `$Param_CPM_NIH_out_filename` looks derivable from
`NIHPAYMASTER.PP$$WF_PP_YEAR_NUM` in a sibling command — it is not, and a wrong
filename means an agency's automated pickup finds nothing.

**Counter-example.** `tests/patterns/test_p17_filename_resolution.py` — asserts
the job resolves the delivered filename from supplied parameters and **fails
loudly on a missing parameter** rather than producing a name with an empty
segment. The naive translation yields `NIHPAYMASTER.PP` and exits zero.

**Gap.** Blocking, per Article VII. Owner: PowerCenter administration. No object
depending on an unresolved `$Param_` leaves `PLANNED`.

---

## P-18 PowerExchange mainframe targets

**PowerCenter.** Six targets are `PWX_SEQ_NRDB2`, written through a
PowerExchange listener over the `PWX_NRDB_Batch_Complex_Files` connection — not
SQL, not a local file. `nihtest_NIH_PAYROLL_MASTER` (534 fields) and
`nihhdr_WS_NIH_HDR` (18 fields) are on this path.

**Spark / Databricks.** No direct equivalent. Options, to be settled per target
in an ADR: write a fixed-width file and hand it to a separate mainframe transfer
step; or replace the mainframe consumer entirely.

**Naive translation that is wrong.** Treating it as a flat-file write. The
listener applies EBCDIC conversion and record-format rules that a UTF-8 text
write does not, so the mainframe consumer receives unreadable data.

**Counter-example.** `tests/patterns/test_p18_ebcdic_record_format.py` — encodes
a fixture record containing a packed-decimal amount and a signed field, and
asserts the delivered bytes match a captured legacy sample byte for byte. A
UTF-8 text write passes a length check and fails this.

**Gap.** Blocking. The listener configuration is not in the export. Owner:
mainframe operations.

---

## P-19 Workflow orchestration

**PowerCenter.** `WORKFLOWLINK` elements form the task DAG, each carrying a
condition — almost always `$<task>.Status = Succeeded`. `SUSPEND_ON_ERROR = NO`
on all eleven workflows, so a failure stops its branch and fires
`on_failure_mail` without suspending. Ten of eleven schedulers are `ONDEMAND`.

**Spark / Databricks.** Databricks Workflows tasks with `depends_on`, and
`ALL_SUCCESS` as the default dependency rule. Email notifications become job
notification settings.

**Naive translation that is wrong.** Assuming the eleven workflows are
independent because each export contains one. They are not: `PAY_PERIOD` links
Pay_Calendar to all ten others, `CPM_NEWPAY_TBL` links CPM to four agency
extracts, and `PSEUDOSSN_TBL` links Pseudossn to CPM, LES and FDA. Running them
concurrently reads half-built tables.

**Counter-example.** `tests/patterns/test_p19_dependency_order.py` — runs the
generated `wf_CPM_NIH` job against a `CPM_NEWPAY_TBL` that `wf_CPM` has not yet
populated for the pay period, and asserts the job fails rather than emitting an
empty or partial extract. Treating the workflows as independent passes.

**Gap.** The actual trigger order for the ten `ONDEMAND` workflows is external
to the export and must be recovered from the operations team before wave
sequencing is final. The derived dependency graph is a lower bound on the
constraints, not the schedule.

---

## P-20 Lookup: unconnected

**PowerCenter.** An unconnected Lookup is not in the pipeline. It is invoked
from an expression as `:LKP.lkp_Name(arg, ...)` and returns exactly one port,
the one flagged `LOOKUP/RETURN/OUTPUT`. It may be called from several
expressions, and each call is an independent evaluation.

**Spark.** Depends on the call's cardinality. A single scalar lookup on a small
table becomes a broadcast join on a de-duplicated key; a call inside a
conditional becomes a join plus a `when`, because Spark has no per-row function
call against another DataFrame.

**Naive translation that is wrong.** Treating `:LKP.` as an undefined function
and failing — or worse, treating it as a no-op returning null, which compiles and
silently nulls a column. The expression compiler must recognise `:LKP.` as a
first-class call form, resolve it to the named lookup, and rewrite the enclosing
expression into a join. That rewrite changes the *shape* of the pipeline, not
just an expression, which is why this is high risk despite looking like a
function call.

A second error: forgetting that a call inside a conditional branch is evaluated
lazily in PowerCenter. Hoisting it into an unconditional join can fan out rows
the condition would have excluded.

**Counter-example.** `tests/patterns/test_p20_unconnected_lookup.py` — an
expression calling `:LKP.lkp_Rate(x)` inside an `IIF` false-branch; asserts the
returned value is correct, that no row fans out, and that a row taking the true
branch is unaffected by a missing lookup row.

---

## P-21 Normalizer: pipeline

**PowerCenter.** A pipeline Normalizer (`ISVSAM_NORMALIZER=NO`) pivots repeating
*columns* into rows. Given `OCCURS n` input port groups, it emits n rows per
input row, with a `GENERATED COLUMN ID/OUTPUT` port giving the occurrence index
and a `GENERATED KEY/OUTPUT` port giving a per-input-row surrogate key.

**Spark.** `posexplode` over an array of the repeating column groups:

```python
groups = F.array(*[F.struct(*[F.col(f"{c}_{i}") for c in base]) for i in range(1, n+1)])
df = df.select("*", F.posexplode(groups).alias("GCID_0", "_g")).select(
    "*", *[F.col(f"_g.{c}").alias(c) for c in base])
df = df.withColumn("GCID", F.col("GCID_0") + 1)   # PowerCenter GCID is 1-based
```

**Naive translations that are wrong.** Two:

1. Using the VSAM emitter (P-07). A pipeline Normalizer has no copybook and no
   byte offsets; the fixed-width path produces nonsense. The two must be
   dispatched on `ISVSAM_NORMALIZER`, not on transformation type. In the
   reference corpus 23 of 39 Normalizers are VSAM and 16 are pipeline, so a
   type-only dispatch is wrong 41% of the time there.
2. Emitting a 0-based occurrence index. PowerCenter's GCID starts at 1, and it is
   frequently a business key.

**Counter-example.** `tests/patterns/test_p21_pipeline_normalizer.py` — three
repeating column groups; asserts three output rows per input, GCID values
`1,2,3`, and a stable generated key per input row.

---

## P-22 Union

**PowerCenter.** Combines multiple input groups with identical port structure
into one output group. It is a **UNION ALL** — duplicates are preserved — and
input group order does not determine output row order.

**Spark.** `unionByName` across the input DataFrames.

**Naive translation that is wrong.** `union` rather than `unionByName`. Spark's
`union` resolves by *position*, PowerCenter's Union by *port name*. When two
input groups declare the same ports in a different order — which the PowerCenter
UI permits — positional union silently transposes column values between
compatible types. Same schema, same row count, wrong data.

Also wrong: using `distinct()`, or Spark SQL `UNION` instead of `UNION ALL`.
PowerCenter's Union never de-duplicates.

**Counter-example.** `tests/patterns/test_p22_union_by_name.py` — two groups
with ports declared in opposite order and duplicate rows; asserts values land in
the right columns and the duplicates survive.

---

## P-23 Rank

**PowerCenter.** Returns the top or bottom N rows per group, ranked on one
designated port, and emits a `RANKINDEX` port. Ties are resolved by input order,
so the result is only deterministic if the input is ordered.

**Spark.** A ranking window function, filtered:

```python
w = Window.partitionBy(*group_cols).orderBy(F.col(rank_port).desc())
df = df.withColumn("RANKINDEX", F.row_number().over(w)).where(F.col("RANKINDEX") <= n)
```

**Naive translation that is wrong.** Using `rank()` or `dense_rank()` instead of
`row_number()`. PowerCenter returns exactly N rows per group; `rank()` returns
more than N when ties straddle the boundary. A top-10 report quietly becomes a
top-13.

Also wrong: omitting the tie-break. Where PowerCenter relies on input order, the
plan must pin an explicit tie-break with the SME — the original behaviour was
non-deterministic and reproducing non-determinism is not achievable.

**Counter-example.** `tests/patterns/test_p23_rank_ties.py` — a group with a tie
spanning the Nth position; asserts exactly N rows and a 1..N `RANKINDEX`.

---

## P-24 Transaction Control

**PowerCenter.** Evaluates an expression per row returning one of
`TC_CONTINUE_TRANSACTION`, `TC_COMMIT_BEFORE`, `TC_COMMIT_AFTER`,
`TC_ROLLBACK_BEFORE`, `TC_ROLLBACK_AFTER`, giving row-level control over commit
boundaries. It is how PowerCenter writes one target file per group, or commits
per logical batch.

**Spark.** No row-level transaction control exists. Two legitimate mappings,
chosen per case and recorded in the plan:

- **Commit boundaries as output partitioning.** If the effect is one file or one
  batch per group, the equivalent is `partitionBy` on the grouping expression, or
  separate writes per group.
- **Commit boundaries as separate Delta transactions.** If the effect is
  atomicity per batch, the equivalent is one `MERGE`/`INSERT` per batch, driven
  by a loop over batch keys.

**Naive translation that is wrong.** Ignoring the transformation, because it has
no data-transforming effect. The mapping still runs and the table still fills —
but a mapping that produced 200 per-group output files now produces one, and the
downstream consumer expecting per-group files receives nothing it recognises.
Rollback semantics vanish silently too: a batch that PowerCenter would have
rolled back is committed.

**Restriction (T2).** Only mappable where the target is transactional (Delta) or
the effect is partitioning. A Transaction Control feeding a non-transactional
target refuses.

**Counter-example.** `tests/patterns/test_p24_commit_boundaries.py` — a mapping
emitting `TC_COMMIT_AFTER` per group key; asserts one output partition per group
and that a rolled-back batch leaves no rows.

---

## P-25 SQL transformation

**PowerCenter.** Two modes. **Query mode** executes a SQL query per input row or
as a static query, returning rows into the pipeline. **Script mode** executes a
SQL script file — arbitrary DDL and DML — against a connection.

**Spark.** Query mode with a static query becomes a read plus a join. Query mode
with a per-row dynamic query has no direct equivalent and must be rewritten as a
set-based join, which is a plan-level decision requiring SME confirmation that
the rewrite is semantically equivalent.

**Naive translation that is wrong.** Translating a per-row dynamic query as a
loop over rows issuing one query each. It is semantically faithful and
operationally catastrophic — one JDBC round trip per row against a table with
millions of rows. This is the rare case where the naive translation is *correct*
and still unusable, so the pattern refuses and demands a set-based rewrite
rather than emitting it.

**Restriction (T2).** Query mode only. **Script mode is T3**: the script file is
not in the repository, so a manual-port contract is emitted.

**Counter-example.** `tests/patterns/test_p25_sql_set_based.py` — asserts the
emitter refuses a per-row dynamic query, and that the approved set-based rewrite
returns identical rows to a reference row-by-row evaluation on a small fixture.

---

## P-26 Stored Procedure

**PowerCenter.** Calls a database stored procedure, either connected in the
pipeline, unconnected from an expression, or as a pre/post-session stored
procedure. The procedure body lives in the database, **not in the repository**.

**Spark.** None automatically. The converter emits a **manual-port contract**:

```python
# MANUAL PORT REQUIRED — T3
# Source: <repo>/<folder>/<mapping>/sp_Calculate_Accrual
# PowerCenter called stored procedure SP_CALC_ACCRUAL on connection INFO_TARGET
#   Input  ports: EMP_ID int, PP_END_DTE date
#   Output ports: ACCRUAL_HRS decimal(9,2)
#   Call type: connected, per row
# Implement this function. Its signature and types are asserted by the
# generated contract test; the surrounding pipeline is already generated.
def sp_calculate_accrual(df: DataFrame) -> DataFrame:
    raise NotImplementedError
```

**Naive translation that is wrong.** Two failure modes, both common in
hand-migrations. Guessing the procedure's logic from its name and port
signature — which produces confident, wrong arithmetic in exactly the domain
where it matters. Or emitting a pass-through that returns nulls, which compiles,
runs, and drops a computed column silently.

**Counter-example.** `tests/patterns/test_p26_manual_port_contract.py` —
asserts the emitter produces a contract with correct signature and types, that
the contract test fails while `NotImplementedError` stands, and that no
pass-through or guessed implementation is emitted.

---

## P-27 XML Parser, Generator and Source Qualifier

**PowerCenter.** Parses or generates XML against a schema, flattening a
hierarchy into multiple output groups linked by generated keys. The referenced
XSD or DTD is **not embedded** in the export.

**Spark.** `from_xml` / `to_xml` with an explicit schema derived from the XSD,
then `posexplode` per repeating element to reproduce the group structure and
generated keys.

**Naive translation that is wrong.** Inferring the schema from sample data.
Spark's XML schema inference makes an optional element that never appears in the
sample simply absent, and an element that appears once non-repeating. Both
diverge from the XSD, so a later file with different optionality either loses
columns or fails. The XSD is the contract; inference is a guess that works until
it does not.

**Restriction (T2).** Refuses without the referenced XSD.

**Counter-example.** `tests/patterns/test_p27_xml_optional_elements.py` — an XSD
with an optional repeating element absent from the sample; asserts the schema
still contains it and that a later document carrying it parses.

---

## P-28 Decision, Assignment and Control tasks

**PowerCenter.** Workflow-level, not pipeline-level. **Decision** evaluates an
expression and exposes `$task.Condition` for downstream links. **Assignment**
sets workflow variables. **Control** stops, aborts or fails the workflow.
**Timer** waits until an absolute time or a relative offset.

**Spark / Databricks.** Workflows condition tasks (`if/else`), task values for
assignment, and explicit failure tasks for Control. Timer maps to a schedule or a
wait task.

**Naive translation that is wrong.** Collapsing a Decision into a data filter.
A Decision gates *task execution*, not rows: when it is false, an entire branch
of sessions does not run. Translated as a `where`, all the sessions run and
process zero rows — which succeeds, writes nothing, and reports green. Any
downstream consumer sees an empty load rather than a skipped one, and no alert
fires.

`ABORT` inside a Control task must fail the job. Article II applies at run time
too: a converted pipeline that swallows an abort is quietly wrong.

**Counter-example.** `tests/patterns/test_p28_decision_skips_branch.py` —
asserts that when the Decision is false the downstream task is *skipped*, not
run with an empty input, and that the job status distinguishes the two.

---

## P-29 Worklets and event tasks

**PowerCenter.** A **worklet** is a reusable group of tasks embedded in a
workflow, nestable to any depth, with its own variables. **Event-Wait** blocks
until a file appears (predefined) or until an **Event-Raise** fires a
user-defined event.

**Spark / Databricks.** A worklet becomes a Databricks Workflow **job task of
type `run_job`**, or an inlined task group, with variables passed as job
parameters. Predefined file-watch events become Auto Loader or a file-arrival
trigger; user-defined events become task dependencies.

**Naive translation that is wrong.** Flattening the worklet into its parent and
discarding its variable scope. A worklet's variables are scoped to the worklet
and reinitialised per execution; flattened into the parent they become shared
mutable state, so two invocations of the same worklet in one workflow interfere.
The DAG looks right and the second invocation reads the first's values.

Event-Wait flattened away is worse: the dependency simply disappears, and a job
reads a file that has not arrived.

**Counter-example.** `tests/patterns/test_p29_worklet_variable_scope.py` — one
worklet invoked twice in a workflow with different parameters; asserts the second
invocation does not observe the first's variable values, and that a nested
worklet three deep preserves scope at each level.

---

## P-30 Shortcuts and reusable objects

**PowerCenter.** A **shortcut** is a reference to an object defined in another
folder — local within a repository, or global into a shared folder. A
**reusable transformation** is one folder-level definition instantiated in many
mappings; likewise reusable sessions and schedulers. Editing the definition
changes every instance.

**Spark.** One generated module or function per *definition*, imported by every
consumer. The instance carries only its instance-specific overrides — reusable
transformation instances may override port defaults and some attributes, and
those overrides must be emitted at the call site.

**Naive translation that is wrong.** Resolving the shortcut in place and
inlining a copy per consumer. Everything works and the semantics invert: a
single upstream definition becomes n independent copies, so the next change to
the original produces n divergent modules and n unrelated-looking diffs. The
migration silently converts a maintained shared object into a maintenance
liability.

The reverse error is equally available: treating a reusable *instance* as
identical to its definition and dropping instance-level overrides.

**Restriction.** A global shortcut whose shared folder is absent from the input
set refuses — the definition cannot be resolved and must not be guessed from the
shortcut's port signature.

**Counter-example.** `tests/patterns/test_p30_shortcut_single_definition.py` —
a reusable transformation instantiated in three mappings with one override;
asserts exactly one definition is emitted, all three import it, the override
appears only at its call site, and a missing shared folder refuses.

---

## Adding an entry

1. Confirm the construct's semantics against Informatica documentation **and**
   against an instance in this corpus. Cite both.
2. Write the counter-example test first. It must fail under the naive
   translation and pass under the correct one.
3. Add the entry with all four required sections.
4. Register the pattern id in the emitter's dispatch table.
5. Update the census above.

An architect agent MUST NOT select a pattern that is not in this catalog. A
construct with no pattern is tier T4: the object goes `OUT_OF_SCOPE`, and
extending coverage is a deliberate, reviewable act
([Article XII](../.specify/memory/constitution.md#article-xii--declared-coverage)).

Steps 2 and 3 are not optional. A pattern promoted to T1 without a conformance
fixture and a counter-example test is precisely the silent-partial-support state
the constitution forbids — and the reference corpus is not a substitute, because
it exercises 14 of roughly 30 transformation types and none of the identity
constructs.
