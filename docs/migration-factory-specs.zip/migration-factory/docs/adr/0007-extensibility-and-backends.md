# ADR-0007 — Extensibility: construct registry, pattern plugins, emitter backends

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

## Context

[ADR-0006](0006-general-converter-scope.md) makes scope the whole PowerCenter
metamodel, which cannot be delivered in one pass and will never be finally
complete — Informatica adds constructs, customers use adapters nobody has seen,
and every engagement finds something. The converter therefore needs coverage to
grow **without forking**, and it needs the growth to be visible.

A second pressure comes from the target side. [ADR-0001](0001-databricks-delta-lake-target.md)
chose Databricks and noted that only `core/emit/` should bind to it. Once the
converter is general on the source side, that boundary is worth making real
rather than aspirational.

## Decision

Three extension points, each with a declared contract, and no others.

**1. Construct registry — data, not code.** Every construct's tier,
restrictions, implementing pattern, verified repository-version range, and
conformance-corpus coverage live in a versioned data file. `mfctl coverage`
reads it. Promoting a tier is a data change plus the evidence Article XII
requires; it is reviewable as a diff.

**2. Pattern plugins.** A pattern is a unit of `(catalog entry,
counter-example test, emitter)` registered against one or more constructs.
Adding a construct means adding a plugin, not editing a dispatcher. The plugin
contract requires all three parts, so the registry cannot reference a pattern
whose test is missing.

**3. Emitter backends.** The emitter consumes a platform-neutral intermediate
representation. The Databricks/PySpark backend is the only one implemented and
the only one planned; the seam exists because it is what keeps the IR honest,
and because pattern semantics stated against the IR rather than against PySpark
idiom are testable in isolation.

Deliberately **not** extension points: the parser (the metamodel is fixed by
Informatica, so parsing is a coverage question, not a plugin question), the
validator (weakening a check must never be a configuration option), and the
constitution's gates.

## Consequences

**Positive.**

- Coverage grows by addition. A customer-specific construct ships as a plugin
  and a corpus without touching the core.
- The three-part plugin contract makes Article V mechanically enforceable rather
  than a review convention: a plugin missing its counter-example does not load.
- Tier changes are diffs in a data file, so coverage regressions are visible in
  code review and catchable in CI.
- The IR boundary forces pattern semantics to be stated independently of PySpark
  idiom, which is where several of the catalog's counter-examples came from.

**Negative.**

- An IR is a real design cost, and with one backend it is speculative
  generality. Accepted because it is load-bearing for testing, not because a
  second backend is expected.
- A plugin surface is a compatibility surface. Plugin contracts need versioning
  and deprecation once anyone outside the team writes one.
- Registry and reality can drift: a plugin can be deleted while its registry
  entry survives. CI must assert that every T1/T2 entry resolves to a loadable
  plugin with a passing test.

## Alternatives rejected

**Hard-coded dispatch table.** What v1 had, and adequate for 19 patterns. It
puts tier information in code comments where no report can read it, and makes
every construct addition a core change.

**Configuration-driven translation — patterns as declarative rules.** Attractive
until the third hard construct. Stateful variable ports need a window
specification derived from upstream sort ports; VSAM normalizers need byte-level
`PICTURE` decoding. Both are code. A rules engine expressive enough for them is
a programming language with worse tooling.

**Fully plugin-based parser.** Rejected: the PowerCenter metamodel is fixed by
the vendor, so a parser plugin surface invites divergent partial parsers of the
same format — precisely the silent-partial-support state Article XII forbids.
