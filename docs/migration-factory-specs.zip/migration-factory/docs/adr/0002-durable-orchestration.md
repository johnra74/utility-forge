# ADR-0002 — Temporal for durable orchestration, LangGraph for agent reasoning

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

## Context

The factory must carry 119 objects (108 mappings, 11 workflows) through a
ten-state lifecycle that includes two human approval gates which may wait days,
model calls that fail transiently, and Databricks jobs that take minutes to
hours. Constitution Article VIII requires recorded human approval at irreversible
boundaries; Article IV requires provenance on every claim. This is government
work subject to audit: any object's full history must be reconstructable.

## Decision

Two engines, at different granularities.

**Temporal** owns the per-object and per-wave lifecycle. One workflow execution
per object. Human approvals are Temporal signals. Model calls, Databricks API
calls, and generator runs are activities with retry policies.

**LangGraph** owns the reasoning inside a single agent step: the
analyse → self-check-against-constitution → revise loop, and the branch on
whether a deterministic verifier accepted the output.

## Consequences

**Positive.**

- Approval gates that wait days are ordinary durable state, not a bespoke queue
  and a cron job.
- Event history *is* the audit trail. Article IV provenance and Article VIII
  approval records fall out of replay rather than needing separate bookkeeping.
- Retry and backoff on flaky model and platform calls is configuration.
- Deterministic replay means a disputed migration decision can be re-examined
  exactly as it was made, which matters when the disputed object is a payroll
  feed.
- The reasoning loop stays inside one activity, so a self-correcting agent does
  not litter the event history with dozens of activity records per object.

**Negative.**

- Two frameworks to operate and two failure modes to understand.
- Temporal is real infrastructure: a cluster, a database, workers, deployment.
  For 119 objects that is arguably heavy.
- Determinism constraints on workflow code are a genuine footgun; all
  non-determinism must sit in activities.

## Alternatives rejected

**Claude Code subagents and skills.** Runs today with zero infrastructure and
was the recommended option. Rejected because it cannot satisfy Article VIII: an
approval that waits three days for a release board does not survive a developer
session, and there is no durable event history to audit. Still the right choice
for exploratory work against a new corpus, and the deterministic core is a CLI
precisely so it stays usable that way.

**LangGraph alone with checkpointing.** Persists graph state, but has no
first-class human-signal primitive, no retry policy language, and no replay
guarantee. Adequate for the reasoning loop, insufficient for the lifecycle.

**Airflow.** Strong at scheduled batch DAGs, weak at long-lived per-entity state
machines with human gates. The generated Databricks jobs are batch DAGs and
Workflows handles those; the *factory* is not a batch DAG.
