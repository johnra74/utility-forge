# ADR-0003 — Generated output is PySpark modules with generated pytest suites

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

## Context

The corpus contains 345 Expression transformations carrying imperative logic —
nested `DECODE`, `IIF`, `SUBSTR` arithmetic, and 115 stateful variable ports.
Constitution Article X requires the output be reviewable by the Informatica and
Oracle specialists who own the legacy system today.

## Decision

One PySpark module per mapping, exposing typed transform functions, plus a
generated pytest suite per module. Databricks job definitions as JSON alongside.

Module layout mirrors the PowerCenter pipeline order, one function per
transformation instance, each named after and cross-referenced to its source
object.

## Consequences

**Positive.**

- A reviewer can read the generated module top to bottom against the mapping's
  documentation page and check each transformation in turn.
- Stateful variable ports ([P-02](../pattern-catalog.md#p-02-expression-stateful-variable-ports))
  need window functions, which are natural in PySpark and awkward in declarative
  SQL models.
- Copybook ingest ([P-07](../pattern-catalog.md#p-07-normalizer-vsam-copybook))
  needs byte-level slicing, which SQL cannot express.
- Generated tests give parity a per-transformation foothold, not just an
  end-to-end table diff.

**Negative.**

- More code than a declarative approach; 108 modules to review.
- Python is a weaker fit than SQL for the staging-to-master transforms that are
  essentially large projections.
- Generated code must be held to a readability standard that generators do not
  naturally produce, which is why the codegen agent authors names, docstrings and
  provenance comments while the compiler produces expression bodies.

## Alternatives rejected

**Spark SQL with dbt.** Very readable for SQL-fluent staff and lineage comes
free. Rejected because it cannot express three of the highest-risk patterns —
stateful variable ports, copybook ingest, and the shell-layer steps — so it would
need a PySpark escape hatch for exactly the parts most likely to be wrong.

**Delta Live Tables.** Least code, and expectations are a good data-quality
substrate. Rejected as the primary form: the imperative expression logic in 345
Expression transformations does not decompose into declarative table definitions
without a large imperative remainder.

**Hybrid: PySpark ingest, SQL transforms.** Matches the estate's actual shape and
remains a reasonable future refinement. Rejected for now because two toolchains
and two test styles double the surface the incumbent team must learn, against
Article X, before a single object has been migrated.
