# ADR-0004 — Object identity is scope-accurate and fully qualified

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

**Superseded in part by** [ADR-0006](0006-general-converter-scope.md), which
generalises this decision from one estate to the PowerCenter metamodel. The
identity scheme below is unchanged; the scope discussion is extended.

## Context

PowerCenter permits the same object name at different scopes, and name collision
is normal rather than exceptional. Analysis of the reference corpus made the
scale concrete.

Measured in the single folder `Test_Repo_Srvc/CPM`, which six of the eleven
exports contribute to:

| Name | Distinct definitions | Port counts |
| --- | --- | --- |
| `exp_Initial` | 31 | 2 … 507 |
| `exp_Final` | 29 | 2 … 677 |
| `SQ_PAY_PERIOD` | 15 | 8 |
| `SQ_CPM_NEWPAY_TBL` | 10 | 463 … 474 |

Note also that **exports are not one-to-one with folders**: `CPM`, `CPM_AFPS`,
`CPM_CDC`, `CPM_NIH`, `CPM_OIG` and `FDA_Leave` are six partial exports of the
same `Test_Repo_Srvc/CPM` folder, sharing its owner and UUID. Identity must
therefore key on the folder, not the export filename — and the 109 distinct
mapping paths in this corpus confirm no mapping name spans two exports.

The two `SQ_CPM_NEWPAY_TBL` definitions carry the same pay-period predicate in
**different attributes** — `Source Filter` in one mapping, `User Defined Join` in
the other. Every `TRANSFORMATION` element in all eleven exports is declared
inside a `MAPPING`; none are folder-level reusable objects.

## Decision

**Identity is scoped to where PowerCenter declares the object**, and the path
records that scope:

```
<repository>/<folder>/<mapping>/<object>     mapping-scoped transformation
<repository>/<folder>/<object>               folder-level reusable object,
                                             source, target, reusable session
<repository>/<folder>/<worklet>/<task>       task within a worklet, any depth
```

Rules:

- Bare names are never keys — not in the canonical model, the ledger, generated
  module or function names, filenames, or agent prompts.
- A mapping-scoped transformation is resolved **only** within its owning
  mapping. Widening the search to folder level is prohibited.
- A folder-level reusable object has **one** identity and many instance
  references. It is never duplicated per referencing mapping.
- A **shortcut** has its identity in the referring folder and its definition in
  the referenced folder. Both are recorded; the definition is resolved from the
  referenced folder, never re-derived. A global shortcut whose shared folder is
  absent from the input set is a refusal, not a guess.
- An instance name may carry a numeric suffix (`PAY_PERIOD1`) when one table is
  used twice in a mapping. The suffix is part of the instance identity;
  normalisation to the underlying table happens only in dependency analysis.

Note that **exports are not one-to-one with folders in either direction**: one
export may contain several folders, and several exports may be partial exports
of the same folder. Identity therefore keys on repository and folder, never on
the export filename.

## Consequences

**Positive.**

- Eliminates a whole class of silent misattribution where one mapping's logic is
  documented, planned, or generated for another.
- Makes generated module and test names unambiguous without a disambiguation
  pass.
- Ledger rows are stable across re-exports.

**Negative.**

- Verbose keys in every schema, prompt, and log line.
- Cross-mapping deduplication of genuinely identical logic becomes an explicit
  optimisation step rather than a free consequence of naming. Such duplication is
  common: in the reference corpus `exp_Initial` recurs near-identically across
  the four `Set_*_Calendar` mappings.
- Two resolvers are needed rather than one, and the scope of every lookup must be
  decided deliberately. This is the intended cost.

## Notes

This was discovered the expensive way. The first version of the documentation
parser resolved transformations by name at folder level and produced plausible
output; the collision was only caught when a per-mapping spot check showed a
source filter attributed to the wrong mapping.

The reference corpus contains **no** shortcuts, reusable transformations,
reusable sessions or worklets, so it cannot exercise the other half of this
decision at all. The `synthetic-identity` conformance corpus exists for exactly
that reason — an estate's silence about a construct is not evidence the
construct is rare. Constitution Articles III, XI and XII together exist to
prevent a repeat of either error.
