# ADR-0005 — The boundary between the deterministic core and the agent layer

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

## Context

The corpus is 21 MB of XML containing 30,445 field-level connectors. The naive
architecture hands exports to a reasoning agent and asks for analysis. The
opposite extreme writes a complete rule-based converter and uses no agents at
all. Neither works: the first produces fluent, unverifiable output; the second
cannot decide what a mapping *means*, which Spark shape to prefer, or what parity
tolerance a feed deserves.

## Decision

A hard boundary, enforced by Constitution Article I.

**Deterministic core — code only, no model calls.** Anything present in the
export or derivable from it: object graphs, port expressions and their ASTs,
workflow DAGs, record layouts with byte offsets, connection bindings, session
commands, lineage edges, dependency graphs, emitted expression bodies, parity
computations.

**Agent layer — judgment only, facts supplied.** Business purpose, complexity
banding, pattern selection, target table design, wave assignment rationale,
parity tolerance proposals, mismatch diagnosis, prose, naming, docstrings, and
the comments that make output readable.

Two rules make the boundary real:

1. **Agents never see raw XML.** They receive canonical model records.
2. **Every agent output passes a deterministic verifier before it reaches the
   ledger.** Citations must resolve to model fields; pattern names must exist in
   the catalog; referenced tables must exist; wave order must respect the
   dependency graph. Output that fails verification is retried, not recorded with
   a caveat.

## Consequences

**Positive.**

- Reproducibility. Same input digest, same core output, byte for byte. CI can
  regenerate and diff (Article IX).
- Cost and latency stay bounded by the number of *objects*, not the size of the
  corpus.
- The audit answer to "why does this Spark job compute this?" is a compiled AST
  and a catalog entry, not a transcript.
- Agent failures degrade into blocked objects rather than wrong code.

**Negative.**

- The core is a real engineering investment — a PowerCenter expression grammar is
  the hard part of feature 002 — where a model would have produced something
  plausible in an afternoon.
- The boundary needs policing. The temptation to let an agent "just read the
  expression" recurs at every impasse, and each time it would work on the example
  in front of you.

## Evidence

A worked precedent exists. The documentation for this corpus
(`PowerCenter/docs/`, 41,000 lines, 122 diagrams) was produced by a deterministic
generator with hand-authored narrative in exactly two files. Its first run
refused to emit anything and reported 1,100 model inconsistencies — mapplet port
exposure and COBOL copybook nesting the parser had not yet understood. A model
asked to summarise the same XML would have produced eleven confident pipeline
descriptions with silently missing lineage, and the error would have surfaced
during cutover rather than during development.
