# ADR-0001 — Databricks with Delta Lake as the migration target

**Status** Accepted · **Date** 2026-09-10 · **Deciders** migration lead

## Context

The estate is 108 PowerCenter mappings feeding Oracle tables, flat files, and
six PowerExchange mainframe datasets, for five HHS agencies. A target platform
must supply: ACID upsert (7 Update Strategy transformations, all requiring
targeted updates that must not disturb unselected rows), fixed-width and COBOL
copybook ingest (20 VSAM sources), a task DAG with conditional dependencies
(11 workflows), persistent sequence state (5 Sequence Generators), and lineage
we can diff against the PowerCenter lineage already extracted.

## Decision

Databricks Runtime with Delta Lake tables governed by Unity Catalog. Databricks
Workflows for orchestration of the generated jobs. Auto Loader for file ingest.

## Consequences

**Positive.**

- `MERGE INTO` maps directly onto Update Strategy semantics
  ([P-11](../pattern-catalog.md#p-11-update-strategy)); no hand-rolled upsert.
- Delta identity columns cover persistent sequence state
  ([P-13](../pattern-catalog.md#p-13-sequence-generator)), which is otherwise a
  bespoke state table.
- Unity Catalog column-level lineage can be diffed against
  `PowerCenter/docs/lineage/source-to-target.csv`, turning lineage parity into an
  automated check rather than a manual review.
- Workflows `depends_on` maps onto `WORKFLOWLINK`
  ([P-19](../pattern-catalog.md#p-19-workflow-orchestration)).
- Delta overwrite is idempotent, which retires the `remove_file.sh`
  pre-session cleanup pattern entirely.

**Negative.**

- Vendor coupling. Mitigated by keeping the deterministic core
  (parser, expression compiler, emitter IR) platform-neutral, so only
  `core/emit/` binds to Databricks.
- No PowerExchange equivalent. The six `PWX_SEQ_NRDB2` targets remain an open
  gap ([P-18](../pattern-catalog.md#p-18-powerexchange-mainframe-targets)) and
  need a per-target decision.
- Unity Catalog requires a governance model — catalog, schema, and grant layout —
  that does not exist yet. This is Wave 0 work.

## Alternatives rejected

**Open-source Spark on EMR/Kubernetes with Iceberg.** No vendor coupling, but
we would build governance, lineage, and orchestration ourselves. For a
government migration whose primary risk is auditability, building the audit
substrate is the wrong place to spend the budget.

**Microsoft Fabric.** Viable if the wider estate were Azure-aligned; no evidence
in the corpus either way, and Fabric's Spark surface is less mature for the
MERGE-heavy patterns here.

**Platform-neutral specs, deferred vendor.** Rejected as a false economy: nine
of nineteen catalog patterns need a concrete ACID upsert and a concrete
orchestration semantic to have a counter-example test at all, and Article V
requires those tests.
