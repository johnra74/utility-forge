# ADR-0006 — Scope is the PowerCenter metamodel, not one estate

**Status** Accepted · **Date** 2026-09-10 · **Deciders** product lead, migration lead
**Supersedes** the "not a general PowerCenter converter" non-goal in
[architecture.md](../architecture.md) v1

## Context

Version 1 of this project was scoped to a single HHS PowerCenter estate. Its
non-goals said so explicitly: *"Not a general PowerCenter converter. Scoped to
the constructs this corpus uses."* That was a defensible way to start, and it is
the wrong basis for a reusable product.

Measuring the reference corpus against the PowerCenter metamodel shows how narrow
one estate is:

| Dimension | Reference corpus | PowerCenter surface |
| --- | --- | --- |
| Transformation types | 14 | ~30 |
| Task types | 3 (Start, Session, Email) | ~11 |
| Port types | 11 | ~20 |
| Source/target type groups | 3 (Oracle, Flat File, VSAM + PWX) | 8 groups, dozens of vendors |
| Repository versions | 1 (`187.96`) | 181–190+ across releases 9.5–10.5 |
| Worklets | 0 | routine in real estates |
| Shortcuts | 0 | routine |
| Folder-level reusable transformations | 0 | routine |
| Reusable sessions / schedulers | 0 | routine |
| Folders per export | 1 | many |
| Mapplets | 1 | routine |

A converter built to those contents would refuse a majority of real PowerCenter
repositories — and, worse, would report full coverage while doing so, because
its own success criteria were written from the same corpus.

## Decision

**Scope is defined by [`docs/construct-coverage.md`](../construct-coverage.md)**
— a declared coverage tier for every construct in the PowerCenter metamodel —
and by nothing else.

1. Requirements are expressed against constructs, not occurrences. Constitution
   [Article XI](../../.specify/memory/constitution.md#article-xi--corpus-independence).
2. Every construct carries a tier: T1 supported, T2 partial with enforced
   restrictions, T3 declared-unsupported with a manual-port contract, T4
   unknown and refused. Constitution
   [Article XII](../../.specify/memory/constitution.md#article-xii--declared-coverage).
3. Coverage is reportable for an arbitrary input **without converting it**, so
   scope is knowable before commitment.
4. Correctness is proved against a **set** of conformance corpora, not one
   estate. Synthetic corpora own construct coverage and adversarial cases; real
   corpora own realism and scale.
5. The HHS estate becomes the **reference corpus** — the primary realism check
   and the source of most catalog counter-examples — with no authority over
   scope.

## Consequences

**Positive.**

- "Can you convert my repository?" gets a computed answer in minutes, from
  `mfctl coverage`, rather than a pilot engagement.
- Absence stops being read as scope. Worklets and shortcuts are now T1 with a
  dedicated conformance corpus, rather than invisible.
- Each engagement contributes construct coverage and regression corpora, so the
  converter compounds instead of being rebuilt.
- Honest, granular limits are more saleable than a vague claim of completeness.
  T3 with a precise interface contract is a useful answer.

**Negative.**

- Substantially more work: ~16 additional constructs, version-aware parsing,
  cross-folder identity resolution, and three synthetic corpora that did not
  need to exist.
- Real estates can no longer be the test suite. Synthetic fixtures must be built
  and maintained for every construct, including ones no current customer uses.
- T3 constructs create a workflow the single-estate design had no need for:
  manual-port contracts, and a lifecycle state for objects that are partly
  hand-written.
- Coverage claims now need continuous evidence. A construct silently regressing
  from T1 is a worse failure than never claiming it.

## Alternatives rejected

**Stay single-estate; generalise later.** Cheapest now, and the trap is that the
corpus-specific assertions are load-bearing by then. Every success criterion
citing an object count would have to be rewritten, and the identity model would
have to be reopened once shortcuts appeared. Deferring this costs more than doing
it, and the v1 specs already demonstrated the failure mode.

**Claim general support without tiers.** Marketable, dishonest, and operationally
worse: a customer discovers the gap during conversion instead of during scoping.
This is exactly the silent-partial-support state Article XII prohibits.

**Support everything before shipping.** Java, External Procedure and Custom
transformations reference code that is not in the repository, so "everything" is
unreachable in principle. T3 with a manual-port contract is the correct terminal
answer for those, not a gap to close.

## Migration from v1

- Constitution to 2.0.0: Articles XI and XII added; II, III, IV, V, VI, X
  revised to speak about constructs rather than one estate.
- All `spec.md` "Corpus fidelity" (`CF-###`) sections replaced by "Conformance
  requirements" (`CR-###`) keyed to constructs, with corpus citations demoted to
  evidence.
- Success criteria restated as proportions, invariants and per-construct
  guarantees.
- New feature [009](../../specs/009-construct-coverage/spec.md) owns the
  registry, tiering, extensibility contract and conformance harness.
- `PowerCenter/` remains in the repository as the `hhs-payroll` conformance
  corpus, clearly labelled as one corpus among several.
