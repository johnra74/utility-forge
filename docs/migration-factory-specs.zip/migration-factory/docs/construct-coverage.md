# Construct Coverage

The authoritative answer to *"can this converter handle my PowerCenter
repository?"* — asked and answered **before** conversion is attempted.

This document, not any particular estate, defines the converter's scope
(Constitution [Article XI](../.specify/memory/constitution.md#article-xi--corpus-independence)).
Every construct in the PowerCenter metamodel appears here with a declared
coverage tier. A construct with no entry is unknown, and unknown means refuse.

## Coverage tiers

| Tier | Meaning | Converter behaviour |
| --- | --- | --- |
| **T1 Supported** | Implemented, with a catalog pattern, a counter-example test, and coverage in at least one conformance corpus | Converts |
| **T2 Partial** | Implemented under stated restrictions | Converts inside the restrictions; **refuses** outside them, naming the restriction |
| **T3 Declared-unsupported** | Recognised and understood; not convertible automatically | Refuses with an explanation and emits a **manual-port contract** — the interface the hand-written replacement must satisfy |
| **T4 Unknown** | Not in the registry | Hard refuse; conversion of the containing object does not proceed |

The distinction between T3 and T4 is the whole point. A Java transformation
containing arbitrary user code is *legitimately* not convertible, and saying so
with a precise interface contract is a useful answer. Silently emitting
something plausible is not, and neither is crashing.

**No tier may be inferred at run time.** The registry is data, versioned with
the converter, and `mfctl coverage` reports it for any input without converting
anything.

## Transformation types

`observed` = occurrences in the HHS reference corpus, which is one conformance
corpus among several and carries no special authority.

| Construct | Tier | Pattern | Restrictions / notes | observed |
| --- | --- | --- | --- | --- |
| Expression | T1 | [P-01](pattern-catalog.md#p-01-expression-stateless-ports), [P-02](pattern-catalog.md#p-02-expression-stateful-variable-ports) | Stateful variable ports T2: require provable ordering | 345 |
| Source Qualifier | T1 | [P-03](pattern-catalog.md#p-03-source-qualifier) | | 112 |
| Lookup Procedure (connected) | T1 | [P-04](pattern-catalog.md#p-04-lookup-connected-cached) | | 112 |
| Lookup Procedure (unconnected) | T1 | [P-20](pattern-catalog.md#p-20-lookup-unconnected) | | 0 |
| Filter | T1 | [P-06](pattern-catalog.md#p-06-filter) | | 61 |
| Normalizer (VSAM/copybook) | T2 | [P-07](pattern-catalog.md#p-07-normalizer-vsam-copybook) | Physical encoding of packed/signed fields must be confirmed against sample data | 23 |
| Normalizer (pipeline) | T1 | [P-21](pattern-catalog.md#p-21-normalizer-pipeline) | | 16 |
| Aggregator | T1 | [P-08](pattern-catalog.md#p-08-aggregator) | | 29 |
| Joiner | T1 | [P-09](pattern-catalog.md#p-09-joiner) | | 27 |
| Router | T1 | [P-10](pattern-catalog.md#p-10-router) | | 7 |
| Update Strategy | T2 | [P-11](pattern-catalog.md#p-11-update-strategy) | Requires a confirmed merge key; refuses without one | 7 |
| Sorter | T1 | [P-12](pattern-catalog.md#p-12-sorter) | | 5 |
| Sequence | T2 | [P-13](pattern-catalog.md#p-13-sequence-generator) | Shared/persistent sequences need a target-side state store | 5 |
| Mapplet + Input/Output Transformation | T1 | [P-14](pattern-catalog.md#p-14-mapplet) | | 3 |
| Union | T1 | [P-22](pattern-catalog.md#p-22-union) | | 0 |
| Rank | T1 | [P-23](pattern-catalog.md#p-23-rank) | | 0 |
| Transaction Control | T2 | [P-24](pattern-catalog.md#p-24-transaction-control) | Commit semantics map only where the target is transactional | 0 |
| SQL transformation | T2 | [P-25](pattern-catalog.md#p-25-sql-transformation) | Query mode only; script mode is T3 | 0 |
| Stored Procedure | T3 | [P-26](pattern-catalog.md#p-26-stored-procedure) | Procedure body is outside the repository | 0 |
| External Procedure | T3 | — | Native library; body not in the repository | 0 |
| Java transformation | T3 | — | Arbitrary user code; manual-port contract emitted | 0 |
| Custom transformation | T3 | — | Vendor/user plugin; behaviour not in the repository | 0 |
| XML Parser / XML Generator | T2 | [P-27](pattern-catalog.md#p-27-xml-parser-generator-and-source-qualifier) | Requires the referenced XSD; refuses without it | 0 |
| XML Source Qualifier | T2 | [P-27](pattern-catalog.md#p-27-xml-parser-generator-and-source-qualifier) | As above | 0 |
| Application Source Qualifier | T3 | — | Application-adapter semantics (SAP, PeopleSoft, Siebel) not in the repository | 0 |
| MQ Source Qualifier | T3 | — | Messaging semantics; batch equivalence is not assured | 0 |
| Web Services Consumer | T3 | — | External service call; side-effecting | 0 |
| HTTP transformation | T3 | — | External call; side-effecting | 0 |
| Data Masking | T3 | — | Masking algorithms are not fully specified in the repository | 0 |
| Unstructured Data | T3 | — | Depends on a parser definition outside the repository | 0 |

## Task and workflow constructs

| Construct | Tier | Pattern | Restrictions / notes | observed |
| --- | --- | --- | --- | --- |
| Start | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 11 |
| Session | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 108 |
| Email | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 7 |
| Command (pre/post-session) | T2 | [P-15](pattern-catalog.md#p-15-session-shell-commands) | Shell body must be classified; arbitrary scripts are T3 | 17 sessions |
| Command (standalone task) | T2 | [P-15](pattern-catalog.md#p-15-session-shell-commands) | As above | 0 |
| Decision | T1 | [P-28](pattern-catalog.md#p-28-decision-assignment-and-control-tasks) | | 0 |
| Assignment | T1 | [P-28](pattern-catalog.md#p-28-decision-assignment-and-control-tasks) | | 0 |
| Control | T1 | [P-28](pattern-catalog.md#p-28-decision-assignment-and-control-tasks) | | 0 |
| Timer | T2 | [P-28](pattern-catalog.md#p-28-decision-assignment-and-control-tasks) | Absolute timers map; relative-to-parent needs run context | 0 |
| Event-Wait / Event-Raise | T2 | [P-29](pattern-catalog.md#p-29-worklets-and-event-tasks) | File-watch events map to Auto Loader; user-defined events map to task dependencies | 0 |
| Worklet (reusable and non-reusable) | T1 | [P-29](pattern-catalog.md#p-29-worklets-and-event-tasks) | Nested worklets supported to any depth | 0 |
| Scheduler (on-demand, recurring, custom) | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 11 |
| Workflow variables and link conditions | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 1,579 vars |
| Suspend-on-error | T2 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | Suspension has no direct target equivalent; maps to a repair task | 0 |

## Repository-level constructs

These change **object identity**, so they are load-bearing for
[Article III](../.specify/memory/constitution.md#article-iii--object-identity-is-scoped-and-fully-qualified)
and for [ADR-0004](adr/0004-object-identity.md).

| Construct | Tier | Pattern | Notes | observed |
| --- | --- | --- | --- | --- |
| Mapping-scoped transformation | T1 | per construct | The common case: declared inside a mapping, resolved only there | 752 |
| Folder-level reusable transformation | T1 | [P-30](pattern-catalog.md#p-30-shortcuts-and-reusable-objects) | One definition, many instances; identity is folder-scoped | 0 |
| Reusable session | T1 | [P-30](pattern-catalog.md#p-30-shortcuts-and-reusable-objects) | Shared across workflows | 0 |
| Reusable scheduler | T1 | [P-19](pattern-catalog.md#p-19-workflow-orchestration) | | 0 |
| Local shortcut (same repository, other folder) | T1 | [P-30](pattern-catalog.md#p-30-shortcuts-and-reusable-objects) | Definition lives in another folder; identity resolves across folders | 0 |
| Global shortcut (shared folder in a global repository) | T2 | [P-30](pattern-catalog.md#p-30-shortcuts-and-reusable-objects) | Requires the shared folder in the input set; refuses otherwise | 0 |
| Shared folder | T1 | [P-30](pattern-catalog.md#p-30-shortcuts-and-reusable-objects) | | 0 |
| Multiple folders per export file | T1 | — | Parser-level; each folder is a distinct scope | 0 |
| Multiple repositories in one input set | T1 | — | Identity is repository-qualified | 2 |
| User-defined function | T1 | [P-01](pattern-catalog.md#p-01-expression-stateless-ports) | Expanded at compile time by the expression compiler (feature 002) | 0 |
| Expression macro (10.x) | T2 | [P-01](pattern-catalog.md#p-01-expression-stateless-ports) | Expanded at compile time; refuses on unbounded expansion | 0 |
| Metadata extension | T1 | — | Carried as provenance, not behaviour | 30 |
| Deployment group / label / query | — | — | Repository management, not runtime behaviour; out of scope | 0 |

## Source and target types

Handled in three groups rather than one row per vendor, because what matters is
the read/write mechanism, not the brand.

| Group | Tier | Examples | Notes | observed |
| --- | --- | --- | --- | --- |
| Relational via JDBC | T1 | Oracle, DB2 LUW, SQL Server, Sybase, Informix, Teradata, Netezza, Vertica, Greenplum, ODBC | [P-03](pattern-catalog.md#p-03-source-qualifier) — predicate pushdown; type mapping per vendor dialect table | Oracle 132 |
| Delimited and fixed-width files | T1 | Flat File | [P-03](pattern-catalog.md#p-03-source-qualifier) for reads, [P-15](pattern-catalog.md#p-15-session-shell-commands) for delivered files | 44 |
| COBOL copybook / VSAM | T2 | VSAM, sequential mainframe extracts | [P-07](pattern-catalog.md#p-07-normalizer-vsam-copybook) — packed/signed encoding must be confirmed against sample data | 20 |
| XML sources and targets | T2 | XML | [P-27](pattern-catalog.md#p-27-xml-parser-generator-and-source-qualifier) — requires the referenced XSD | 0 |
| PowerExchange non-relational | T3 | `PWX_SEQ_NRDB2`, DB2 z/OS, IMS, IDMS, Adabas, Datacom | [P-18](pattern-catalog.md#p-18-powerexchange-mainframe-targets) — listener config not in the repository; per-target decision required | 6 |
| Application adapters | T3 | SAP R/3, SAP BW, PeopleSoft, Siebel, Salesforce | Adapter semantics not in the repository | 0 |
| Messaging | T3 | JMS, MSMQ, WebSphere MQ, TIBCO, webMethods | Streaming semantics; batch equivalence not assured | 0 |
| Web services | T3 | Web Service Provider/Consumer | Side-effecting external calls | 0 |

## Repository version support

`POWERMART/@REPOSITORY_VERSION` and the `powrmart.dtd` generation differ across
PowerCenter releases. Element and attribute availability is version-dependent,
so the parser is version-aware and the registry records the range each construct
was verified against.

| Repository version | PowerCenter release | Support |
| --- | --- | --- |
| 181–186 | 9.5 – 9.6 | T2 — parsed; constructs not present in the verified fixtures refuse |
| 187 | 10.1 – 10.2 | T1 — verified (the reference corpus is `187.96`) |
| 188–190 | 10.4 – 10.5 | T2 — parsed; version-specific constructs (expression macros) T2 |
| < 181 or > 190 | earlier / later | T4 — refuse with a version message |

A version outside the verified range is a refusal, not a best effort. Extending
the range means adding a conformance corpus at that version, not relaxing the
check.

## Conformance corpora

Coverage claims are only meaningful against inputs that exercise them. The
converter ships with a set of corpora, and no construct may be marked T1 without
appearing in at least one.

| Corpus | Origin | Exercises | Role |
| --- | --- | --- | --- |
| `synthetic-core` | Hand-built, minimal | Every T1 and T2 construct, one mapping each | The coverage floor. CI gate. |
| `synthetic-identity` | Hand-built | Shortcuts, shared folders, reusable transformations and sessions, worklets nested three deep, multi-folder and multi-repository inputs | Identity resolution ([Article III](../.specify/memory/constitution.md#article-iii--object-identity-is-scoped-and-fully-qualified)) |
| `synthetic-adversarial` | Hand-built | Name collisions, empty-vs-absent attributes, cyclic dependencies, unreachable router groups, unset variable ports | The failure modes, deliberately |
| `hhs-payroll` | Real (HHS PowerCenter estate) | Deep expression logic, COBOL copybooks, stateful variable ports, shell-layer delivery, mixed-environment provenance | Realism and scale — 11 exports, 108 mappings, 752 transformations |
| `<customer>` | Real, added per engagement | Whatever that estate contains | Regression; contributes new coverage evidence |

`hhs-payroll` is the **reference corpus**: rich enough to be the primary
realism check, and the origin of most catalog counter-examples. It is not the
definition of scope. A construct absent from it is not out of scope, and a
threshold expressed in terms of its contents is a defect
([Article XI](../.specify/memory/constitution.md#article-xi--corpus-independence)).

Real corpora are added under an ingestion agreement covering data handling; a
corpus contributes structure and construct coverage, never production data.

## Reporting coverage for an arbitrary input

```sh
mfctl coverage <xml-dir>
```

```
repository versions      187.96                                  T1
folders                  4  (1 shared)                           T1
mappings                 212
transformations          1,481 across 19 types

  T1 supported           1,402   (94.7%)
  T2 partial                 61   (4.1%)  — restrictions listed below
  T3 unsupported             18   (1.2%)  — manual-port contracts emitted
  T4 unknown                  0   (0.0%)

T2 restrictions to resolve
  Update Strategy (7)         merge key unconfirmed
  Normalizer/VSAM (3)         packed-decimal encoding unconfirmed
  Global shortcut (2)         shared folder SHARED_DIM not in input set

T3 requiring manual port
  Java transformation (11)    jtx_Scoring in m_Score_Claims, ...
  Stored Procedure (7)        sp_Audit in m_Load_Audit, ...

CONVERTIBLE: 194 of 212 mappings (91.5%); 18 need manual work
```

This runs before any commitment is made. It is the deliverable of a scoping
engagement, and it is computed, not estimated.

## Adding coverage

1. Add the construct to the registry with tier T4 if it is not already there.
2. Add a fixture exercising it to `synthetic-core` (or `synthetic-identity` for
   an identity construct).
3. Write the catalog entry, including the counter-example test that fails under
   the naive translation ([Article V](../.specify/memory/constitution.md#article-v--semantics-before-syntax)).
4. Implement the emitter and register it in the dispatch table.
5. Promote the tier, and state the restrictions if T2.

Promoting a tier without steps 2 and 3 is prohibited
([Article XII](../.specify/memory/constitution.md#article-xii--declared-coverage)).
