# Migration Factory Constitution

Non-negotiable principles for the agent system that converts **any** Informatica
PowerCenter repository to Databricks. Every `spec.md`, `plan.md`, and `tasks.md`
in `specs/` is checked against these articles before work starts and again after
design.

Scope is defined by [`docs/construct-coverage.md`](../../docs/construct-coverage.md)
— the declared coverage tier of each PowerCenter construct — never by the
contents of any particular customer estate.

These are not style preferences. Each one exists because violating it produced,
or would have produced, documentation or code that was confidently wrong. The
rationale sections name the specific failure.

**Version** 2.0.0 · **Ratified** 2026-09-10 · **Amendment** requires an ADR in
`docs/adr/` plus a version bump.

*Changed in 2.0.0:* the system is a general PowerCenter converter rather than a
single-estate migration. Articles XI and XII are new. Articles II, III, IV and V
were revised to express requirements against the construct metamodel instead of
one estate's contents. See
[ADR-0006](../../docs/adr/0006-general-converter-scope.md).

---

## Article I — Deterministic core, judged edges

Anything derivable from the repository export by code MUST be computed by code.
Agents interpret, classify, name, and explain; they never restate a fact a
parser can produce.

- Object inventories, field connectors, port expressions, workflow graphs,
  record layouts, connection bindings, session commands: **parser output only**.
- Business purpose, complexity rating, pattern selection, risk assessment,
  target table design, prose: **agent output**, always traceable to parser facts.

**Gate.** For every artifact an agent writes, each factual claim MUST cite
either a field in the canonical model (§Article III) or a `file:line` in the
corpus. A claim that cites neither is a defect, not a stylistic issue.

**Rationale.** A model asked to summarise 21 MB of XML will produce a plausible
inventory that is wrong in the details that matter. A parser will not. Cost,
reproducibility, and auditability all point the same way: compute what you can,
judge only what you must.

## Article II — Fail loudly; never emit quietly-wrong output

Every generator and every agent step MUST validate its inputs and refuse to
produce output when the model does not hang together. Partial output with a
warning is prohibited.

Minimum validations before any artifact is written:

- every instance resolves to a definition, including across folders for
  shortcuts and reusable objects;
- every field connector endpoint is a real port on a real instance;
- every session references an existing mapping;
- every workflow link references an existing task, worklet or event;
- every construct encountered has a declared coverage tier (§Article XII);
- every generated Spark module compiles and its generated tests execute.

A refusal MUST distinguish **four** outcomes, because they call for different
action by the reader:

| Outcome | Meaning |
| --- | --- |
| Malformed input | The export does not conform to the PowerCenter metamodel |
| Unsupported construct (T3) | Recognised, not convertible; a manual-port contract is emitted |
| Unmet restriction (T2) | Convertible in general, but a stated precondition is absent |
| Unknown construct (T4) | Not in the registry; coverage must be extended |

**Gate.** Each feature's `plan.md` MUST name its refusal conditions, which of
the four outcomes each produces, and the non-zero exit path.

**Rationale.** The first run of the documentation generator surfaced 1,100 model
inconsistencies — mapplet ports and COBOL copybook nesting that the parser had
not yet understood. Had it warned and continued, eleven pipelines would have
been documented with silently missing lineage, and nobody would have known.

## Article III — Object identity is scoped and fully qualified

Every object MUST be addressed by a fully qualified path whose scope matches
where PowerCenter actually declares the object:

```
<repository>/<folder>/<mapping>/<object>     mapping-scoped transformation
<repository>/<folder>/<object>               folder-level reusable object,
                                             source, target, reusable session
<repository>/<folder>/<worklet>/<task>       task inside a worklet, nested to
                                             any depth
```

A **shortcut** is an object whose identity is in the referring folder and whose
definition is in another. Both MUST be recorded, and the definition MUST be
resolved from the referenced folder — never re-derived from the shortcut.

Bare names MUST NOT be used as keys, in the ledger, in filenames, in generated
module names, or in agent prompts. Scope MUST NOT be widened for convenience: a
mapping-scoped transformation MUST NOT be resolved at folder level, and a
folder-level reusable object MUST NOT be duplicated per mapping.

**Gate.** Any schema, table, or dictionary keyed on a bare object name fails
review. Any resolver that searches a wider scope than the construct's declared
scope fails review.

**Rationale.** PowerCenter permits the same name at different scopes, and name
collision is normal rather than exceptional. In the reference corpus `exp_Final`
occurs 29 times in a single folder with port counts from 2 to 677 and genuinely
different logic in each; `SQ_CPM_NEWPAY_TBL` occurs 10 times, two of them
carrying the same predicate in *different attributes*. Resolving at the wrong
scope silently attributes one object's logic to another. Shortcuts and reusable
objects make the converse error possible too — duplicating one definition into
many, so a single upstream change appears as many unrelated diffs. See
[ADR-0004](../../docs/adr/0004-object-identity.md).

## Article IV — Provenance travels with every claim

Every record in the canonical model, the ledger, and every generated artifact
MUST carry: source export file, export timestamp, repository name, derived
environment (Production or Test), and the generator or agent version that
produced it.

No artifact may describe production behaviour on the basis of a non-production
export without an explicit, visible caveat.

**Gate.** A `plan.md` that proposes cutover for an object whose only evidence is
a Test-repository export MUST list re-export from production as a prerequisite
task.

Environment MUST be established from a declared, per-engagement mapping of
repository and Integration Service names to environments. It MUST NOT be
inferred from a name prefix. Where no mapping is supplied, environment is
`Unknown`, and `Unknown` MUST NOT be treated as production.

**Rationale.** Repository exports routinely come from non-production
environments. In the reference corpus seven of eleven exports came from a test
repository on a test Integration Service, with source definitions owned by a
`_DEV` schema — and the `Prd`/`Test` prefix that reveals it is a local
convention, not a PowerCenter feature. A converter that hard-codes one
customer's naming convention will confidently mislabel the next customer's
environments.

## Article V — Semantics before syntax

A translation from a PowerCenter construct to a Spark construct MUST be
justified against documented engine semantics and MUST ship with a test that
fails under the naive translation.

Every entry in `docs/pattern-catalog.md` MUST carry: the PowerCenter semantics,
the Spark equivalent, the naive translation that looks right and is wrong, and
the counter-example test that distinguishes them. Entries are keyed to
**constructs in the metamodel**, not to occurrences in any estate.

Semantics MUST be established from Informatica's documented behaviour, and the
catalog MUST cite it. Corpus evidence illustrates a pattern and demonstrates
that it matters; it never defines the semantics, because one estate exercises
only the paths it happens to use.

**Gate.** A codegen task for a construct with no catalog entry, or a catalog
entry with no counter-example, is blocked. A construct MUST NOT be promoted to
tier T1 without both a counter-example test and coverage in a conformance
corpus (§Article XII).

**Rationale.** A Router looks like a filter chain and is not: PowerCenter routes
each row to *every* group whose condition is true, so a row can leave through
more than one branch. Translating it as if-else drops rows silently. Expression
variable ports look stateless and are not: they retain their value across rows,
which is how running totals are written in PowerCenter. Both mistakes produce
code that runs, passes a smoke test, and computes the wrong answer.

## Article VI — Parity is the definition of done

An object reaches `MIGRATED` only when the reconciliation harness passes against
legacy output at a tolerance stated in that object's migration plan. No other
signal — code review, successful run, matching row count alone — is sufficient.

Required parity dimensions, per target:

1. row count;
2. per-column null count and distinct count;
3. per-column checksum over a deterministic sort of the business key;
4. full row diff on a sampled key set, with the sample size justified.

**Gate.** `007-parity-validation` results are a hard precondition on any ledger
transition to `MIGRATED`. Overrides require a named human approver recorded in
the ledger.

**Rationale.** A converted pipeline is trusted precisely because parity was
proved, and nothing else about a machine translation earns that trust. The
consequence of getting it wrong scales with the data: in the reference corpus a
wrong penny in the payroll master propagates to five agencies in the same
cycle.

## Article VII — Gaps are first-class, never assumed away

Anything the corpus does not contain MUST be recorded as an explicit gap with a
type, an owner, and a blocking status. Agents MUST NOT invent a plausible value
for a missing input.

Gap classes intrinsic to the PowerCenter format — a repository export cannot
contain these, so every engagement has them and all MUST be modelled:

- **Parameter files.** Every `$Param_*` value — including every output
  filename — comes from a session parameter file that is not in the export.
- **External orchestration.** Ten of eleven workflows are `ONDEMAND`; whatever
  cron or operator triggers them, and in what order, is not in the export.
- **Shell-layer data movement.** Header/detail/trailer files are concatenated by
  post-session `cat` commands. Six workflows use a dummy-source mapping
  (`HI_GENERIC_SRC_TBL` → `GENERIC_TARGET_FILE`) whose only real work is in the
  shell. This movement is invisible to PowerCenter lineage.
- **Mainframe I/O.** `PWX_SEQ_NRDB2` targets are written through a
  PowerExchange listener, not SQL. The listener configuration is not exported.
- **Copybook physical encoding.** Signed and packed-decimal `PICTURE` clauses
  (`+9(3)V9(2)`, `USAGE_FLAGS=TRAILING_SIGN`) describe byte layouts whose actual
  encoding must be confirmed against a real data file, not assumed.
- **Bodies of external code.** Stored Procedure, External Procedure, Java and
  Custom transformations reference logic held outside the repository.
- **Referenced schemas.** XML sources and targets depend on an XSD the export
  does not embed.
- **Absent shared folders.** A global shortcut's definition lives in a shared
  folder that may not be in the supplied input set.
- **Environment mapping.** Which repository and Integration Service names
  correspond to which environments is a local convention (§Article IV).

**Gate.** A migration plan for an object with an unresolved blocking gap cannot
leave `PLANNED`.

## Article VIII — Human approval at irreversible boundaries

The following MUST require a recorded human approval, with approver identity and
timestamp in the ledger:

- approving an object's migration plan (`PLANNED` → `APPROVED`);
- production cutover (`VALIDATED` → `CUTOVER`);
- any backward ledger transition;
- any parity tolerance override;
- amending this constitution.

Agents MAY propose all of these. Agents MUST NOT self-approve.

## Article IX — Regenerable, never hand-patched

Generated artifacts MUST NOT be hand-edited. Fix the generator, the pattern
catalog, or the input, then regenerate. Every generated file MUST carry a header
naming the generator, its version, and the input digest.

Hand-authored files live in named, enumerated locations and are never
overwritten by a generator run.

**Gate.** CI regenerates all artifacts from the corpus and fails on any diff.

**Rationale.** The documentation for this estate is 41,000 lines. It is only
trustworthy because it is derived; the moment someone patches a page by hand,
the whole corpus becomes untrustworthy because you can no longer tell which
parts are derived.

## Article X — Readable by the team that owns the legacy system

Generated Spark code, specs, and plans MUST be reviewable by the engineers who
maintain the source PowerCenter repository today, who are typically Informatica
and relational-database specialists rather than Spark specialists.

- Generated modules MUST name their source mapping and link to its documentation
  page.
- Every non-obvious translation MUST carry a comment naming the PowerCenter
  construct it came from.
- Clever, dense, or idiomatic-but-opaque Spark is a defect when a plain
  equivalent exists.

**Rationale.** The people who can tell you whether a translation is correct are
the people who understand the original. If they cannot read the output, the only
remaining verification is parity testing, and parity testing cannot tell you that
a rule was already wrong in PowerCenter.

## Article XI — Corpus independence

No requirement, threshold, success criterion, test assertion, or default may be
expressed in terms of the contents of any single PowerCenter estate.

- Requirements are stated against **constructs in the metamodel**: "any mapping
  containing an Update Strategy transformation MUST …", never "the 7 Update
  Strategy transformations MUST …".
- Success criteria are stated as **proportions, invariants, or per-construct
  guarantees** over an arbitrary input: "100% of parsed expressions either
  compile or refuse", never "all 13,935 expressions compile".
- A specific estate MAY be cited as **evidence** that a requirement matters, and
  MUST be labelled as such.
- Conformance corpora are named in
  [`docs/construct-coverage.md`](../../docs/construct-coverage.md). The HHS
  estate is the reference corpus: the primary realism check, with no authority
  over scope.

**Gate.** A `spec.md` whose requirements or success criteria cite one estate's
object counts fails review. Reviewers MUST ask of every threshold: *would this
still be meaningful for a different customer's repository?*

**Rationale.** Version 1.0.0 of this constitution governed a single-estate
migration, and its specs were saturated with that estate's counts — 108
mappings, 30,445 connectors, 115 stateful ports. Every one of those numbers is a
latent defect in a general converter: it passes for one customer and silently
misstates the requirement for all others. Worse, absence was read as scope. The
reference corpus contains no worklets, no shortcuts, no reusable transformations,
no Union, no Rank, no Stored Procedure and one repository version — and a
converter built to its contents would refuse a majority of real PowerCenter
repositories while reporting full coverage.

## Article XII — Declared coverage

Every PowerCenter construct MUST have a declared coverage tier in
[`docs/construct-coverage.md`](../../docs/construct-coverage.md): **T1**
supported, **T2** partial with stated restrictions, **T3**
declared-unsupported, **T4** unknown. There is no undeclared middle ground.

- The converter MUST be able to report coverage for an arbitrary input
  **without converting it**, so scope is knowable before commitment.
- **T2** restrictions MUST be enforced. A construct convertible only under a
  precondition MUST refuse when that precondition is absent, naming it.
- **T3** MUST emit a **manual-port contract** — the interface the hand-written
  replacement must satisfy — not a placeholder, a stub that runs, or a
  best-effort approximation.
- **T4** MUST refuse. Encountering an unknown construct means coverage needs
  extending, and that is a visible decision.
- Promotion to **T1** requires a catalog entry with a counter-example test
  (§Article V) **and** coverage in at least one conformance corpus. Promotion
  without both is prohibited.
- Silent partial support is the prohibited state. Converting the easy paths of a
  construct and ignoring the rest is worse than refusing it, because it converts
  the reader's trust along with the code.

**Gate.** Every `plan.md` MUST state the tier of each construct in its scope. A
feature claiming to handle a construct not at T1 or T2 fails review.

**Rationale.** "Can you convert my repository?" is the first question any
customer asks, and it deserves a computed answer rather than a demonstration on
a favourable subset. Tiers make the honest answer cheap: 94% T1, 4% T2 with
these preconditions, 1% needing manual work, here are the objects.

---

## Precedence

Article XI (corpus independence) and Article XII (declared coverage) bound what
the other articles may assert: a requirement that violates either is malformed
regardless of how well it satisfies the rest.

Article II (fail loudly) and Article VI (parity) override delivery pressure.
Article I (deterministic core) overrides convenience.

Where two articles conflict, the earlier-numbered article wins, except that XI
and XII outrank all others on the question of *how a requirement is expressed*.
Every conflict MUST be recorded in the `plan.md` Complexity Tracking table.
