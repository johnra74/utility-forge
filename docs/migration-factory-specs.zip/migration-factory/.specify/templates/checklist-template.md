# Checklist: [NAME]

**Feature** `[###-feature-name]` · **Purpose** [what this gate protects]
**Run when** [e.g. before requesting plan approval; before cutover]

Each item is answerable yes/no from an artifact or a command's output. An item
that requires an opinion is not a checklist item.

## [Category, e.g. Corpus fidelity]

- [ ] **CHK001** [question] — evidence: `[artifact or command]`
- [ ] **CHK002** [question] — evidence: `[artifact or command]`

## [Category, e.g. Semantic correctness]

- [ ] **CHK010** Every PowerCenter construct in scope has a
      `docs/pattern-catalog.md` entry
- [ ] **CHK011** Every catalog entry used has a passing counter-example test

## [Category, e.g. Release readiness]

- [ ] **CHK020** Parity report attached and within stated tolerance
- [ ] **CHK021** Named human approver recorded in the ledger

## Result

| | |
| --- | --- |
| Run by | [name] |
| Date | [date] |
| Outcome | pass / fail |
| Blocking items | [list, or none] |
