# Implementation Plan: [FEATURE NAME]

**Branch** `[###-feature-name]` · **Date** [DATE] · **Spec** [spec.md](spec.md)
**Input** Feature specification at `specs/[###-feature-name]/spec.md`

## Summary

[Two or three sentences: the requirement, and the technical approach chosen.]

## Technical Context

| | |
| --- | --- |
| Language / version | [e.g. Python 3.11] |
| Primary dependencies | [e.g. Temporal SDK, PySpark 3.5, Pydantic v2] |
| Storage | [e.g. Postgres for the ledger, Delta on Unity Catalog for data] |
| Testing | [e.g. pytest, chispa for DataFrame assertions] |
| Target platform | Databricks Runtime [version], Unity Catalog |
| Project type | [deterministic tool / agent / service / generated artifact] |
| Performance target | [e.g. full-corpus reparse under 60 s] |
| Constraints | [e.g. stdlib-only for the parser; no network in codegen] |
| Scale | [stated as a capacity target, not one corpus's size — e.g. "10,000 objects; 500 MB of export XML"] |
| Constructs in scope | [list with tiers, per Article XII] |
| Conformance corpora | [which corpora exercise this feature] |

Unresolved items MUST appear as `[NEEDS CLARIFICATION: ...]` and be closed in
Phase 0.

## Constitution Check

*Gate: MUST pass before Phase 0. Re-checked after Phase 1.*

| Article | Check | Pass | Notes |
| --- | --- | --- | --- |
| I — Deterministic core | Nothing a parser could compute is left to an agent | ☐ | |
| II — Fail loudly | Refusal conditions and non-zero exit defined | ☐ | |
| III — Scoped identity | All keys fully qualified; no bare names | ☐ | |
| IV — Provenance | Every record carries source, env, version | ☐ | |
| V — Semantics first | Every pattern has a catalog entry + counter-example | ☐ | |
| VI — Parity | Parity gate wired to ledger transitions | ☐ | |
| VII — Gaps | Corpus gaps modelled, not assumed | ☐ | |
| VIII — Human approval | Irreversible boundaries require recorded approval | ☐ | |
| IX — Regenerable | Generated output never hand-edited; CI diff check | ☐ | |
| X — Readable | Output reviewable by PowerCenter SMEs | ☐ | |
| XI — Corpus independence | No requirement or threshold cites one estate's counts | ☐ | |
| XII — Declared coverage | Tier stated for every construct in scope | ☐ | |

**Post-Phase-1 re-check:** [date, result]

## Project Structure

### Artifacts produced by this plan

```
specs/[###-feature-name]/
├── plan.md              # this file
├── research.md           # Phase 0 output
├── data-model.md         # Phase 1 output
├── contracts/            # Phase 1 output — schemas, CLI and API contracts
├── quickstart.md         # Phase 1 output
└── tasks.md              # Phase 2 output
```

### Source layout

```
[concrete directory paths — remove the unused options]
```

## Phase 0 — Research

Resolve every `[NEEDS CLARIFICATION]`. For each: the question, the options, the
decision, and the evidence. Output → `research.md`.

- [ ] [question]

## Phase 1 — Design

- [ ] `data-model.md` — entities, identity, relationships, invariants
- [ ] `contracts/` — JSON Schema for records, CLI signatures, API surfaces
- [ ] `quickstart.md` — the shortest path to running this end to end
- [ ] Re-run Constitution Check

## Phase 2 — Task generation

Ordered, dependency-aware tasks with `[P]` on anything parallelisable. Output →
`tasks.md`. Tests precede implementation.

## Complexity Tracking

Any constitutional violation, with justification. An empty table is the
expected case.

| Article | Violation | Why necessary | Simpler alternative rejected because |
| --- | --- | --- | --- |

## Verification

How a human confirms this feature works end to end, by running something.

1. [command] → [expected observable result]
