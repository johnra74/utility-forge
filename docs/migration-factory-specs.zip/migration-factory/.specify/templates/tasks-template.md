# Tasks: [FEATURE NAME]

**Branch** `[###-feature-name]` · **Plan** [plan.md](plan.md)

Conventions: `[P]` = safe to run in parallel with other `[P]` tasks in the same
phase. Tests are written before the code they cover. Every task names the files
it touches.

## Phase 3.1 — Setup

- [ ] **T001** [task] — `path/to/file`
- [ ] **T002** [P] [task] — `path/to/file`

## Phase 3.2 — Tests first

*These MUST be written and MUST fail before Phase 3.3 begins.*

- [ ] **T010** [P] Contract test for [contract] — `tests/contract/test_x.py`
- [ ] **T011** [P] Counter-example test for [pattern], failing under the naive
      translation *(Article V)* — `tests/patterns/test_y.py`

## Phase 3.3 — Core implementation

- [ ] **T020** [task] — `path/to/file`

## Phase 3.4 — Validation gates

- [ ] **T030** Refusal conditions from `plan.md` implemented and tested
      *(Article II)* — `path/to/file`
- [ ] **T031** Provenance fields populated and asserted *(Article IV)*
- [ ] **T032** Coverage tier recorded for every construct touched *(Article XII)*
- [ ] **T033** Corpus-independence check: no test asserts a single estate's
      object count *(Article XI)*

## Phase 3.5 — Integration & polish

- [ ] **T040** [task]
- [ ] **T041** CI regeneration diff check *(Article IX)*

## Dependencies

```
T001 → T002 → {T010, T011} → T020 → T030 → T040
```

## Parallel execution example

```
# After T002, these are independent:
T010  T011
```

## Definition of done

- [ ] Every `spec.md` FR and CR maps to at least one task
- [ ] Every conformance corpus named in `spec.md` is exercised
- [ ] Every task's tests pass
- [ ] Constitution Check re-run and passing
- [ ] `plan.md` Verification steps executed and recorded
