# Feature Specification: [FEATURE NAME]

**Feature Branch** `[###-feature-name]`
**Created** [DATE] · **Status** Draft · **Input** [user description]

> **What belongs here:** what the system must do and why, in language a
> PowerCenter engineer and a Databricks engineer both understand.
> **What does not:** libraries, class names, schemas, or code. Those belong in
> `plan.md` and `data-model.md`.

---

## User Scenarios & Testing *(mandatory)*

Each story MUST be independently testable and deliver value on its own. Rank by
impact: **P1** = the feature is pointless without it, **P2** = materially
better with it, **P3** = valuable once P1/P2 land.

### User Story 1 — [title] (P1)

[The journey in plain language. Name the actor: migration engineer, PowerCenter
SME, release approver, auditor.]

**Why this priority:** [what is impossible without it]

**Independent test:** [how to verify this story alone, with the rest of the
feature absent]

**Acceptance scenarios**

1. **Given** [state], **When** [action], **Then** [observable outcome]
2. **Given** [state], **When** [action], **Then** [observable outcome]

### User Story 2 — [title] (P2)

[...]

---

## Requirements *(mandatory)*

### Functional

- **FR-001** The system MUST [capability]
- **FR-002** The system MUST [capability]
- **FR-003** The system MUST refuse to [action] when [condition], exiting
  non-zero *(Constitution Article II)*
- **FR-004** The system MUST record [provenance fields] on every [record]
  *(Article IV)*
- **FR-005** [NEEDS CLARIFICATION: question, with the options considered]

### Conformance requirements

Requirements stated against **constructs in the PowerCenter metamodel**, never
against one estate's contents *(Article XI)*. A specific repository may be cited
as *evidence* that the requirement matters — label it as such.

- **CR-001** Any [construct] MUST [behaviour]. *Evidence:* [corpus observation],
  or *Covered by:* [conformance corpus] when no real corpus exercises it.
- **CR-002** Every construct in scope MUST carry its declared coverage tier
  *(Article XII)*

### Coverage *(Article XII)*

| Construct in scope | Tier | Restrictions if T2 | Manual-port contract if T3 |
| --- | --- | --- | --- |
| [construct] | T1/T2/T3 | [precondition that must hold] | [interface the hand-written part satisfies] |

### Gaps this feature must surface *(Article VII)*

Gaps intrinsic to the PowerCenter export format, so every engagement has
whichever apply.

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| [what a repository export structurally cannot contain] | parameter-file / external-orchestration / environment-map / external-code-body / referenced-schema / absent-shared-folder / mainframe / copybook-encoding / provenance / business-key | yes/no | [role] |

### Key entities *(include when the feature carries data)*

- **[Entity]** — [what it represents, its identity per Article III, its
  relationships]

---

## Success Criteria *(mandatory)*

Measurable, technology-agnostic, and **corpus-independent** *(Article XI)*.
State proportions, invariants and per-construct guarantees over an arbitrary
input — never one estate's object counts.

> Good: "for any input, 100% of expressions either compile or refuse explicitly"
> Bad: "all 13,935 expressions compile"
>
> Ask of every threshold: *would this still be meaningful for a different
> customer's repository?*

- **SC-001** [invariant over any input, with zero-exception phrasing]
- **SC-002** [proportion or rate with a unit]
- **SC-003** [per-construct guarantee, asserted against a named conformance
  corpus where the expected value is known exactly]
- **SC-004** [what a human can verify by hand in under 10 minutes]

---

## Edge Cases

- [What happens when the export is a Test-repository copy?]
- [What happens when two objects share a bare name?]
- [What happens when a required input is absent rather than empty?]

## Assumptions

- [Assumption, and what breaks if it is wrong]
- [Anything assumed about the input repository that a different customer's
  repository might not satisfy]

## Dependencies

- **Upstream** [feature or corpus this needs]
- **Downstream** [features that consume this]

---

## Review & Acceptance Checklist

- [ ] No implementation detail (no libraries, schemas, or code)
- [ ] Every requirement is testable and unambiguous
- [ ] Every user story is independently testable and prioritised
- [ ] Success criteria are measurable and technology-agnostic
- [ ] Refusal conditions stated *(Article II)*
- [ ] Provenance requirements stated *(Article IV)*
- [ ] Object identity is fully qualified throughout *(Article III)*
- [ ] Corpus gaps enumerated with owners *(Article VII)*
- [ ] Human-approval boundaries identified *(Article VIII)*
- [ ] No requirement or success criterion cites one estate's object counts
      *(Article XI)*
- [ ] Coverage tier declared for every construct in scope *(Article XII)*
- [ ] All `[NEEDS CLARIFICATION]` markers resolved or explicitly deferred
