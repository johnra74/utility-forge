# Feature Specification: Expression Translation

**Feature Branch** `002-expression-translation`
**Created** 2026-09-10 · **Status** Draft
**Input** Compile PowerCenter expression language into a verified Spark
expression, deterministically, or refuse.

---

## Why this is a separate feature

Documenting lineage needs only to know *which* ports an expression references,
and token matching answers that adequately — it over-reports, which is harmless
for a lineage report. **Translating** an expression requires reproducing its
semantics, which needs a real grammar, a real AST, and a per-function contract.

PowerCenter's expression language has roughly 120 built-in functions plus
user-defined functions, expression macros, unconnected-lookup call syntax
(`:LKP.name(...)`), variable persistence (`SETVARIABLE`), and pipeline-aborting
calls (`ABORT`, `ERROR`). Scope is the language, not one estate's usage of it.

*Evidence that the surface is broad even in a narrow estate:* the reference
corpus alone uses 40+ distinct functions across 13,935 port expressions —
`ISNULL` 1,092, `IIF` 1,088, `DECODE` 822, `SUBSTR` 459, `TO_DECIMAL` 455,
`SUM` 388, `SIGN` 291 — with 115 stateful ports, 66 `SETVARIABLE` calls and 23
`ABORT` calls, and it exercises no user-defined functions, no expression macros
and no unconnected-lookup calls at all.

## User Scenarios & Testing

### User Story 1 — Compile a stateless expression (P1)

An engineer compiles a port expression and receives an equivalent Spark
expression plus the set of ports it depends on, derived from the AST rather than
from token matching.

**Why this priority:** every generated transform body comes from here.

**Independent test:** compile every expression in every conformance corpus;
assert each either compiles or refuses explicitly, with zero silent fallbacks.

**Acceptance scenarios**

1. **Given** `IIF(NOT IS_NUMBER($$MAP_PP_NUM), 0, TO_DECIMAL($$MAP_PP_NUM))`,
   **When** compiled, **Then** a Spark expression is produced and the dependency
   set names the mapping parameter, not a column.
2. **Given** a nested `DECODE(TRUE, cond1, v1, cond2, v2)`, **When** compiled,
   **Then** the result is a chained `when/otherwise` evaluated in source order.
3. **Given** an expression containing a `--` comment, **When** compiled,
   **Then** the comment is preserved in the emitted code as a provenance
   comment and does not affect semantics *(Article X)*.
4. **Given** an unsupported function, **When** compiled, **Then** compilation
   fails naming the function, and no partial expression is returned
   *(Article II)*.

### User Story 2 — Compile a stateful expression, or refuse (P1)

A self-referential local variable port compiles to a window expression when the
required ordering is provable from upstream, and refuses otherwise.

**Why this priority:** 115 instances, and the failure mode is a wrong answer with
no error and no row-count change. This is the single highest-risk pattern in the
estate.

**Independent test:** compile
`.../exp_Determine_Allotments/v_ALLOTMENT_COUNTER` and assert a window
expression partitioned on the employee key; then remove the upstream sort and
assert refusal with gap type `ordering-unproven`.

**Acceptance scenarios**

1. **Given** a self-referential accumulator and an upstream Source Qualifier with
   `Number Of Sorted Ports = 3`, **When** compiled, **Then** a window expression
   with that partition and ordering is produced.
2. **Given** the same port with no provable upstream ordering, **When** compiled,
   **Then** compilation refuses with `ordering-unproven` and does **not** emit a
   stateless expression.
3. **Given** a chain of variable ports where a later one reads an earlier one,
   **When** compiled, **Then** evaluation order matches declared port order.

### User Story 3 — Preserve datatype and null semantics (P1)

Compilation carries PowerCenter datatype, precision and scale into Spark types,
and reproduces PowerCenter's null and empty-string behaviour.

**Why this priority:** these are payroll amounts. A `decimal(18,2)` silently
compiled to `double` loses cents at scale.

**Acceptance scenarios**

1. **Given** a port of `decimal` precision 18 scale 2, **When** compiled,
   **Then** the Spark type is `DecimalType(18, 2)`, never a float type.
2. **Given** `IS_SPACES(x)` on a column read from Oracle, **When** compiled,
   **Then** the emitted expression treats a null as PowerCenter does, and the
   difference from Oracle's empty-string-is-null behaviour is recorded.
3. **Given** an arithmetic expression mixing `decimal` and `integer` ports,
   **When** compiled, **Then** the result type follows PowerCenter's promotion
   rules, and a test asserts the boundary case.

### User Story 4 — Compile the call forms that are not plain functions (P1)

The compiler handles PowerCenter's non-function call forms: unconnected lookup
invocation `:LKP.lkp_Name(args)`, user-defined function calls, and expression
macros.

**Why this priority:** an unconnected-lookup call inside an expression is not an
expression-local concern — resolving it rewrites the *pipeline shape* into a
join. A compiler that treats `:LKP.` as an unknown function blocks every mapping
using one, and one that treats it as a no-op silently nulls a column.

**Independent test:** compile an expression containing `:LKP.lkp_Rate(x)` inside
an `IIF` false-branch and assert the emitted plan includes the join plus the
conditional guard, with the lookup identified by fully qualified path.

**Acceptance scenarios**

1. **Given** `:LKP.lkp_Name(a, b)`, **When** compiled, **Then** it resolves to
   the named unconnected Lookup, returns its `LOOKUP/RETURN/OUTPUT` port, and
   emits a pipeline-shape requirement rather than a scalar expression.
2. **Given** a `:LKP.` call inside a conditional branch, **When** compiled,
   **Then** the emitted form does not evaluate the lookup for rows taking the
   other branch, and does not fan out rows.
3. **Given** a user-defined function, **When** compiled, **Then** it is expanded
   from its repository definition, recursively, with recursion depth bounded and
   an unbounded expansion refused.
4. **Given** an expression macro, **When** compiled, **Then** it is expanded at
   compile time; an expansion exceeding the configured bound refuses.

### User Story 5 — Function coverage report (P2)

The engineer runs a coverage report showing every PowerCenter function in the
corpus, its occurrence count, whether it is implemented, and its conformance
test.

**Why this priority:** it converts "will this work?" into a number that can be
computed for a prospective customer's repository before any commitment, and it
drives implementation order by observed usage across corpora rather than by
guesswork.

**Acceptance scenarios**

1. **Given** the corpus, **When** the report runs, **Then** every distinct
   function appears with a count and an implemented flag.
2. **Given** an unimplemented function, **When** any object using it is planned,
   **Then** that object carries a `pattern-missing` gap.

### User Story 6 — Round-trip differential testing (P2)

For any expression, the engineer generates input rows, evaluates the compiled
Spark expression, and compares against a reference evaluation.

**Why this priority:** a function-by-function unit test proves each primitive;
differential testing over generated inputs is what catches composition errors.

**Acceptance scenarios**

1. **Given** an expression and generated inputs covering null, empty, boundary
   and typical values, **When** both evaluators run, **Then** results match
   exactly, decimals included.
2. **Given** a mismatch, **When** reported, **Then** the failing input row and
   the differing sub-expression are named.

---

## Requirements

### Functional

- **FR-001** The system MUST parse PowerCenter expression syntax with a formal
  grammar producing an AST. Regular expressions and token matching MUST NOT be
  used for translation.
- **FR-002** The system MUST resolve identifiers to ports of the owning
  transformation, mapping parameters, or built-in constants, using the
  mapping-scoped model *(Article III)*.
- **FR-003** The system MUST evaluate ports in declared order and MUST reproduce
  PowerCenter's unset-variable default rather than emitting null.
- **FR-004** The system MUST detect self-reference in a `LOCAL VARIABLE` port
  and compile it to a window expression **only** when partition and ordering are
  derivable from upstream Source Qualifier sort ports, an explicit `ORDER BY`, or
  a Sorter. Otherwise it MUST refuse with `ordering-unproven` *(Article II, V)*.
- **FR-005** The system MUST map PowerCenter datatypes to Spark types
  preserving precision and scale, and MUST NOT substitute a floating type for a
  decimal.
- **FR-006** The system MUST implement each supported function with a
  conformance test derived from Informatica's documented behaviour, and MUST
  refuse on any function absent from the registry, naming it *(Article XII)*.
- **FR-006a** The system MUST resolve `:LKP.` unconnected-lookup calls to the
  named Lookup and emit a pipeline-shape requirement, never a scalar
  placeholder.
- **FR-006b** The system MUST expand user-defined functions and expression
  macros at compile time, with a bounded expansion depth and refusal beyond it.
- **FR-007** The system MUST handle `SETVARIABLE` per pattern
  [P-16](../../docs/pattern-catalog.md#p-16-mapping-variable-persistence-setvariable): the
  value flows through as the expression result **and** a variable-persistence
  side effect is recorded. Compiling it as a pure pass-through is prohibited.
- **FR-008** The system MUST handle `ABORT` as an explicit pipeline failure with
  the original message, not as a null-returning no-op. 23 uses in corpus.
- **FR-009** The system MUST preserve source comments as provenance comments in
  emitted code *(Article X)*.
- **FR-010** The system MUST report, per expression, the exact set of ports it
  depends on, derived from the AST, superseding the token-matching estimate in
  feature 001 without changing that feature's schema.
- **FR-011** The system MUST expose a function coverage report.
- **FR-012** The system MUST be deterministic, offline, and free of model calls
  *(Article I)*.

### Conformance requirements

Stated against the expression language *(Article XI)*.

- **CR-001** `DECODE` MUST compile to ordered evaluation in both its forms — the
  value-matching form and the `DECODE(TRUE, cond, val, …)` conditional form —
  never to a hash lookup. *Evidence:* 822 uses in the reference corpus, almost
  all conditional.
- **CR-002** Comments inside expressions MUST NOT affect semantics, and MUST be
  preserved as provenance comments. *Evidence:* reference-corpus ports carry
  commented-out alternative implementations beside live logic.
- **CR-003** A conditional construct with no default branch MUST yield
  PowerCenter's null rather than an error. *Evidence:* a reference-corpus
  accumulator whose default branch is commented out.
- **CR-004** Order-dependent functions (`FIRST`, `LAST`, and ranking within an
  Aggregator) MUST refuse without a provable ordering. *Evidence:* 139 combined
  uses in the reference corpus.
- **CR-005** Every PowerCenter datatype MUST map to a Spark type preserving
  precision and scale; no decimal may become a floating type.
- **CR-006** `SETVARIABLE` MUST compile to both its expression result and its
  persistence side effect. Compiling it as a pure pass-through is prohibited.
- **CR-007** `ABORT` and `ERROR` MUST compile to explicit pipeline failure with
  the original message.
- **CR-008** `:LKP.` calls, user-defined functions and expression macros MUST be
  supported call forms. *Covered by:* `synthetic-core` — the reference corpus
  uses none of them.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Ordering for a stateful port with no provable upstream sort | ordering-unproven | yes | PowerCenter SME |
| Any function not in the registry | pattern-missing | yes | Migration engineering |
| PowerCenter unset-variable defaults per datatype, needing confirmation against engine behaviour | semantics-unconfirmed | yes | PowerCenter SME |

### Key entities

- **ExpressionAST** — parsed tree for one port expression. Identity: the port's
  fully qualified path.
- **FunctionContract** — one PowerCenter function: arity, argument types, null
  behaviour, Spark implementation, conformance test reference.
- **CompiledExpression** — Spark expression source, result type, dependency set,
  side effects, provenance comments, and a refusal reason when compilation
  declined.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** For any input, 100% of expressions either compile or produce an
  explicit refusal naming the cause. Zero silent fallbacks, zero partial
  compilations.
- **SC-002** For any input, every stateful port is detected, and each either
  compiles to a window expression with a recorded ordering proof or refuses with
  `ordering-unproven`. Zero stateless compilations of a stateful port.
- **SC-003** Every function in the registry is either implemented with a passing
  conformance test or marked unimplemented. No function is partially
  implemented, and the coverage report reconciles exactly with the registry.
- **SC-004** Differential testing over at least 1,000 generated input rows per
  expression — covering null, empty, boundary and typical values — produces zero
  mismatches against the reference evaluator.
- **SC-005** No compiled decimal port has a floating-point Spark type, for any
  input.
- **SC-006** Compilation sustains at least 150 expressions per second
  single-threaded, offline.
- **SC-007** `synthetic-core` exercises every registry function and every
  supported call form at least once; a function with no fixture cannot be marked
  implemented.

---

## Edge Cases

- **Expression that is only a comment.** Treated as absent, not as null.
- **Identifier matching both a port and a function name.** Port wins, per
  PowerCenter scoping; a test pins this.
- **Self-referential port in a transformation with no upstream sort at all.**
  Refuse. The PowerCenter behaviour was already non-deterministic, which is a
  finding for the SME, not something to reproduce.
- **`SETVARIABLE` inside a conditional.** The side effect is conditional; the
  emitted code must preserve that. Evidence: `o_MAP_PP_END_DTE` in
  `m_LES_Verify_Header` wraps `SETVARIABLE` in `IIF(IS_DATE(...))`.
- **Nested aggregate inside a non-aggregator.** Refuse; PowerCenter permits some
  forms whose semantics differ from Spark's.
- **Recursive user-defined function.** Bounded expansion, then refuse. Silent
  truncation of the expansion is prohibited.
- **`:LKP.` call to a Lookup that does not exist.** Refuse naming the missing
  Lookup; never compile to null.

## Assumptions

- PowerCenter function semantics can be pinned from Informatica documentation
  plus corpus evidence. Where documentation is ambiguous, the ambiguity becomes a
  `semantics-unconfirmed` gap rather than a guess.

## Dependencies

- **Upstream** 001 (ports, declared order, stateful flags, upstream sort ports,
  unconnected Lookup definitions, user-defined functions); 009 (function
  registry and tiers)
- **Downstream** 006 consumes `CompiledExpression`; 004 uses the AST dependency
  set for accurate lineage.

---

## Review & Acceptance Checklist

- [x] No implementation detail beyond naming the need for a formal grammar
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)*
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] Function and call-form coverage declared *(Article XII)* — FR-006
- [x] No human-approval boundary — deterministic, no irreversible effects
- [x] All `[NEEDS CLARIFICATION]` resolved
