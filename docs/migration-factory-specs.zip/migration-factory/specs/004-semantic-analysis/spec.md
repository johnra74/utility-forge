# Feature Specification: Semantic Analysis

**Feature Branch** `004-semantic-analysis`
**Created** 2026-09-10 · **Status** Draft
**Input** For each object, produce a verified analysis record: what it does, how
hard it is, which patterns it needs, and what is missing.

---

## User Scenarios & Testing

### User Story 1 — Analyse one object into a verified record (P1)

The analyst agent receives the canonical model for one mapping — never raw XML —
and produces its business purpose, a complexity band, the set of catalog patterns
it requires, and its gaps. Every factual claim cites a model field. A record with
an unresolvable citation is rejected and retried.

**Why this priority:** the architect cannot select patterns for an object nobody
has characterised, and a plausible-but-unverified characterisation is worse than
none.

**Independent test:** analyse `m_CPM_NIH_Load_CPM_NIH_Data_File` and assert the
record names its source, its target, the four Expression transformations, and
the `User Defined Join` predicate — with every claim's citation resolving.

**Acceptance scenarios**

1. **Given** a mapping's model record, **When** analysis runs, **Then** the
   output includes purpose, complexity band, required pattern ids, and gaps.
2. **Given** an analysis citing a port that does not exist, **When** verified,
   **Then** it is rejected and retried; it is never stored with a caveat
   *(Article I)*.
3. **Given** an analysis naming a pattern absent from the catalog, **When**
   verified, **Then** it is rejected and the object is marked `BLOCKED` with
   `pattern-missing`.
4. **Given** an analysis of an object from a Test export, **When** stored,
   **Then** it carries the Test provenance caveat *(Article IV)*.

### User Story 2 — Classify complexity from measured properties (P1)

Complexity is a band derived from counted properties — port count,
transformation count, stateful port count, pattern risk, gap count — not from an
impression.

**Why this priority:** complexity drives wave sequencing, effort estimates and
review depth. An agent's unaided impression of "moderate" is not a planning
input.

**Independent test:** assert that `m_CPM_NIH_Load_CPM_NIH_Data_File` (530-port
target, 4 Expressions, no stateful ports) and
`m_CPM_Load_CPM_NEWPAY_STG_ALT_TBL` (stateful accumulators, a mapplet, a
sequence) land in different bands, and that the band is reproducible from the
counts alone.

**Acceptance scenarios**

1. **Given** two objects with identical measured properties, **When** analysed,
   **Then** they receive the same complexity band.
2. **Given** an object with any stateful port, **When** banded, **Then** it is at
   least `high`.
3. **Given** a band, **When** queried, **Then** the contributing counts are
   returned, so the band is explainable without re-running the agent.

### User Story 3 — Detect what the mapping does not say (P1)

Analysis identifies work that mapping logic alone does not reveal: shell-only
mappings, dummy-source mappings, variable-persistence chains reaching filenames,
and mainframe targets.

**Why this priority:** six workflows deliver their entire output through
post-session shell commands. An analysis that reads only the pipeline reports
those mappings as trivial, and they are the ones that break delivery.

**Acceptance scenarios**

1. **Given** `m_CPM_NIH_Concatenate_Files`, **When** analysed, **Then** it is
   reported as `shell-only` with its concatenation command, and **not** as a
   trivial mapping.
2. **Given** a mapping calling `SETVARIABLE`, **When** analysed, **Then** the
   downstream propagation chain to any filename or email is traced and named.
3. **Given** a mapping writing a `PWX_SEQ_NRDB2` target, **When** analysed,
   **Then** the mainframe gap is attached.

### User Story 4 — Group equivalent objects (P2)

Analysis identifies objects whose logic is materially identical, so they can be
migrated once and reused.

**Why this priority:** real estates contain heavy copy-paste duplication.
Migrating near-identical mappings independently multiplies review effort and
invites divergence. *Evidence:* the reference corpus has four near-identical
`Set_*_Calendar` mappings and eight near-identical `LESRPT_Load_*` mappings.

**Acceptance scenarios**

1. **Given** the corpus, **When** equivalence analysis runs, **Then** candidate
   groups are proposed with the differences between members enumerated.
2. **Given** a proposed group, **When** verified, **Then** the differences are
   computed deterministically from the model, not asserted by the agent.
3. **Given** a group, **When** an SME rejects it, **Then** the rejection is
   recorded and the group is not re-proposed.

### User Story 5 — Explain an object to a Databricks engineer (P2)

Analysis produces a plain-language explanation that a Spark engineer with no
Informatica background can act on, and that a PowerCenter SME can confirm.

**Why this priority:** Article X. The migration's real bottleneck is shared
understanding between two groups of specialists.

**Acceptance scenarios**

1. **Given** an analysis, **When** rendered, **Then** it links to the mapping's
   documentation page and names each transformation's role in sequence.
2. **Given** a non-obvious construct, **When** explained, **Then** the
   explanation names the PowerCenter semantics and the catalog pattern.

---

## Requirements

### Functional

- **FR-001** The analyst MUST consume canonical model records and MUST NOT be
  given raw XML *(Article I,
  [ADR-0005](../../docs/adr/0005-deterministic-core-agent-boundary.md))*.
- **FR-002** Every factual claim in an analysis MUST carry a citation resolving
  to a model field or a corpus `file:line`.
- **FR-003** The system MUST verify every citation deterministically before the
  analysis is stored, and MUST reject and retry on failure. Storing an
  unverified analysis is prohibited.
- **FR-004** Complexity bands MUST be computed from measured counts by a
  published, deterministic function. The agent MAY explain a band; it MUST NOT
  set one.
- **FR-005** Any object containing a stateful port, a T2 construct with an
  unmet restriction, or a T3 construct MUST receive at least band `high`.
- **FR-006** Required patterns MUST be named by catalog id, and every id MUST
  exist in `docs/pattern-catalog.md`. An unknown pattern MUST mark the object
  `BLOCKED` with `pattern-missing` *(Article V)*.
- **FR-007** The system MUST attach gaps for `shell-only` and `dummy-source`
  mappings, variable-persistence chains, mainframe targets, unconfirmed copybook
  encodings, and missing merge keys.
- **FR-008** The system MUST trace `SETVARIABLE` propagation to its terminal
  consumer — filename, email, or downstream session — and record the chain.
- **FR-009** The system MUST record Test provenance as a visible caveat on any
  analysis derived from a non-production export *(Article IV)*.
- **FR-010** Equivalence group differences MUST be computed deterministically;
  the agent MAY propose groups and MUST NOT assert equivalence.
- **FR-011** Analyses MUST be re-runnable, and a re-run against an unchanged
  model MUST produce a semantically equivalent record with the same complexity
  band and pattern set.
- **FR-012** The system MUST write to the ledger only through the orchestrator,
  never directly *(003 FR-013)*.

### Conformance requirements

- **CR-001** Every object in the input MUST be analysable regardless of width.
  Analysis MUST NOT degrade or truncate on wide targets. *Evidence:* the
  reference corpus has a 534-field target and a 501-field source.
- **CR-002** Mappings differing only in parameter values MUST be proposed as an
  equivalence group, with differences computed rather than asserted.
- **CR-003** A mapping whose only real effect is a session shell command MUST be
  reported `shell-only`, and one reading a single-row dummy source MUST be
  reported `dummy-source`. Neither may ever be reported trivial.
- **CR-004** An object containing a T3 construct MUST be analysed for everything
  around that construct, and the T3 boundary MUST be identified as the
  manual-port surface rather than causing the whole object to be skipped.
- **CR-005** Analysis MUST attach the coverage tier of every construct in the
  object, so complexity banding accounts for unconvertible parts.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Business meaning of undocumented columns in wide payroll targets | domain-knowledge | no | PowerCenter SME |
| Whether an equivalence group is genuinely safe to merge | domain-knowledge | yes per group | PowerCenter SME |
| Intent behind the inconsistent pay-period predicate placement | domain-knowledge | no | PowerCenter SME |

### Key entities

- **AnalysisRecord** — per object. Purpose, complexity band with contributing
  counts, required pattern ids, gaps, citations, provenance caveats.
- **Citation** — a claim bound to a model field path or corpus location.
- **ComplexityBand** — `low` / `medium` / `high` / `severe`, with its inputs.
- **EquivalenceGroup** — candidate objects plus their computed differences and
  SME verdict.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** Every object in the input produces a stored analysis with zero
  unresolved citations. No object is skipped, including those containing T3
  constructs.
- **SC-002** Complexity bands are reproducible: re-running on an unchanged model
  yields identical bands for every object.
- **SC-003** Every stateful port, unmet T2 restriction and T3 construct in the
  input appears in an analysis banded `high` or above; a query returns zero
  exceptions.
- **SC-004** Every pattern id referenced across all analyses exists in the
  catalog; zero dangling references.
- **SC-005** Every `shell-only` and `dummy-source` mapping in the input is
  flagged; none is reported trivial. Asserted exactly against `synthetic-core`,
  where the expected set is known.
- **SC-006** Every `SETVARIABLE` chain terminating in a filename, email or
  downstream session is traced end to end.
- **SC-007** For each corpus, a domain reviewer confirms a 10-object sample as
  accurate, with corrections recorded as feedback and fed into prompt
  regression tests.

---

## Edge Cases

- **Object with no transformations.** Reported as pass-through or shell-only;
  never "nothing to do".
- **Object whose logic is already wrong in PowerCenter.** Recorded as a finding;
  migration reproduces the behaviour so parity is meaningful, and the finding
  becomes a separate post-cutover change.
- **Analysis the SME rejects.** Recorded as feedback against the object; the
  correction is applied and the disagreement retained.
- **Agent produces a confident analysis with no citations.** Rejected by
  verification. There is no path that stores it.

## Assumptions

- Business purpose is inferable from names, descriptions, and the derived
  documentation for most objects. Where it is not, the analysis says so rather
  than inventing one, and raises a `domain-knowledge` gap.

## Dependencies

- **Upstream** 001 (model, flags, gaps), 002 (AST dependency sets), 003 (ledger),
  `docs/pattern-catalog.md`
- **Downstream** 005 consumes analyses; 006 consumes pattern selections.

---

## Review & Acceptance Checklist

- [x] No implementation detail
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)* — FR-003, FR-006
- [x] Provenance requirements stated *(Article IV)* — FR-009
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] Coverage tiers feed complexity banding *(Article XII)* — FR-005, CR-005
- [x] Human-approval boundaries identified *(Article VIII)* — equivalence-group
      merges require SME verdict
- [x] All `[NEEDS CLARIFICATION]` resolved
