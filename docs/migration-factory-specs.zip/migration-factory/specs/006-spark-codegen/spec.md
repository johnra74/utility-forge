# Feature Specification: Spark Code Generation

**Feature Branch** `006-spark-codegen`
**Created** 2026-09-10 · **Status** Draft
**Input** Emit PySpark modules, pytest suites and Databricks job definitions from
an approved migration plan.

---

## User Scenarios & Testing

### User Story 1 — Generate a module for one mapping (P1)

From an approved plan, the generator emits one PySpark module: a function per
transformation instance in pipeline order, with expression bodies compiled from
the AST, each function naming and linking to its source object.

**Why this priority:** this is the deliverable. Everything before it is
preparation.

**Independent test:** generate `m_CPM_NIH_Load_CPM_NIH_Data_File`, assert the
module imports and compiles, contains a function per transformation, and produces
all 534 target columns.

**Acceptance scenarios**

1. **Given** an approved plan, **When** generation runs, **Then** a module is
   emitted whose functions correspond one-to-one with the mapping's
   transformations, in pipeline order.
2. **Given** a generated module, **When** imported, **Then** it compiles with no
   syntax or name errors, or generation is treated as failed *(Article II)*.
3. **Given** a transformation, **When** its function is read, **Then** a comment
   names the source object path and the catalog pattern applied
   *(Article X)*.
4. **Given** a plan whose approval digest no longer matches, **When** generation
   is attempted, **Then** it is refused as approval-stale.

### User Story 2 — Generate the parity test suite alongside (P1)

Each module ships a pytest suite: per-transformation tests from the pattern
counter-examples, and a module-level test asserting the target schema.

**Why this priority:** Article V requires a counter-example per pattern, and a
generated module with no test is unverifiable output.

**Acceptance scenarios**

1. **Given** a module using pattern P-10, **When** tests are generated, **Then**
   a test asserts a row satisfying two router groups reaches both outputs.
2. **Given** a module with a stateful port, **When** tests are generated,
   **Then** a test asserts the accumulator sequence, and fails under a stateless
   implementation.
3. **Given** a generated suite, **When** run, **Then** it executes against a
   local Spark session with no Databricks dependency.
4. **Given** a target schema, **When** tested, **Then** column names, order,
   types, precision and scale are asserted exactly.

### User Story 3 — Refuse rather than approximate (P1)

Generation refuses when it cannot produce a faithful translation, marking the
object blocked with a reason. It never emits a placeholder, a `TODO`, or a
best-effort approximation.

**Why this priority:** every high-risk pattern in this estate fails by computing
a wrong answer silently. A refusal is recoverable; a plausible approximation that
reaches production is not.

**Independent test:** attempt generation for a stateful port with no provable
ordering; assert refusal, no file written, and `ordering-unproven` on the object.

**Acceptance scenarios**

1. **Given** a stateful port whose ordering is unprovable, **When** generation
   runs, **Then** it refuses and writes nothing.
2. **Given** an unimplemented expression function, **When** generation runs,
   **Then** it refuses naming the function.
3. **Given** a transformation whose pattern has a failing counter-example test,
   **When** generation runs, **Then** it refuses.
4. **Given** any refusal, **When** the output directory is inspected, **Then** no
   partial module exists.

### User Story 4 — Generate the job DAG and the non-mapping steps (P1)

Generation emits Databricks Workflows job definitions reproducing the workflow
DAG, including tasks that replace session shell commands, parameter resolution,
and variable propagation.

**Why this priority:** six workflows deliver output entirely through shell
commands. Mapping modules alone deliver nothing.

**Acceptance scenarios**

1. **Given** a workflow with seven task instances and their links, **When**
   generated, **Then** the job has corresponding tasks with matching
   dependencies.
2. **Given** a post-session `cat` concatenation, **When** generated, **Then** a
   task produces the same bytes in the same order, asserted by a test.
3. **Given** a `SETVARIABLE` chain, **When** generated, **Then** the value
   propagates through task values and reaches the output filename, asserted end
   to end.
4. **Given** an SFTP delivery script, **When** generated, **Then** a separate
   retryable task performs the delivery with credentials from a secret scope,
   and no credential appears in generated code.

### User Story 5 — Emit a manual-port contract for a T3 construct (P1)

For a declared-unsupported construct, generation emits everything around it
normally plus a contract: the function signature, types, call semantics, and a
contract test that fails until a human implements it.

**Why this priority:** it converts an unconvertible construct from a blocker
into a bounded, reviewable task, without ever emitting a guess.

**Independent test:** generate a mapping containing a Stored Procedure; assert
the surrounding pipeline is complete, the contract carries correct signature and
types, and the contract test fails while unimplemented.

**Acceptance scenarios**

1. **Given** a T3 construct, **When** generated, **Then** a contract with
   signature, types and call semantics is emitted, and the rest of the pipeline
   is generated normally.
2. **Given** an emitted contract, **When** its test runs unimplemented, **Then**
   it fails; **when** implemented to the signature, **Then** it passes.
3. **Given** a T3 construct, **When** generated, **Then** no pass-through, no
   null-returning stub, and no inferred implementation is emitted.
4. **Given** a hand-written implementation, **When** regeneration runs, **Then**
   it is preserved and not overwritten *(Article IX applies to generated files
   only)*.

### User Story 6 — Readable by the incumbent team (P2)

Generated code is reviewable by Informatica and Oracle specialists: module
docstrings state purpose and provenance, functions are named after their source
objects, and non-obvious translations carry explanatory comments.

**Why this priority:** Article X. The only people who can confirm a translation
is correct are the people who understand the original.

**Acceptance scenarios**

1. **Given** a module, **When** its docstring is read, **Then** it names the
   source mapping, its documentation page, the model digest and the generator
   version.
2. **Given** a window expression replacing a stateful port, **When** read,
   **Then** a comment shows the original PowerCenter expression.
3. **Given** a PowerCenter source comment, **When** the corresponding code is
   read, **Then** the comment is preserved.
4. **Given** a sample of 10 modules, **When** reviewed by a PowerCenter SME,
   **Then** they can trace each function to its source transformation unaided.

### User Story 7 — Regenerate idempotently (P2)

Regenerating from an unchanged plan and model produces byte-identical output.

**Acceptance scenarios**

1. **Given** an unchanged plan and model, **When** generation runs twice,
   **Then** output is byte-identical.
2. **Given** a hand-edited generated file, **When** CI runs, **Then** the diff
   fails the build *(Article IX)*.

---

## Requirements

### Functional

- **FR-001** Expression bodies MUST come from the 002 compiler. The codegen agent
  MUST NOT author transformation logic *(Article I,
  [ADR-0005](../../docs/adr/0005-deterministic-core-agent-boundary.md))*.
- **FR-002** The agent MAY author module docstrings, function and variable names,
  and provenance comments.
- **FR-003** Every emitted module MUST import and compile, or generation MUST be
  treated as failed with nothing written *(Article II)*.
- **FR-004** Generation MUST refuse — never approximate — on an unprovable
  ordering, an unimplemented function, a missing pattern, or a failing
  counter-example test. No placeholders or `TODO`s may be emitted.
- **FR-005** A generated pytest suite MUST accompany every module, including
  every counter-example test for the patterns used *(Article V)*.
- **FR-005a** A T3 construct MUST generate a manual-port contract — signature,
  types, call semantics — plus a contract test that fails while unimplemented,
  and MUST NOT generate a stub, pass-through or inferred implementation
  *(Article XII)*.
- **FR-005b** Regeneration MUST preserve hand-written manual-port
  implementations while regenerating everything around them.
- **FR-006** Generated tests MUST run against a local Spark session with no
  Databricks dependency.
- **FR-007** Target schema tests MUST assert column names, order, types,
  precision and scale exactly.
- **FR-008** Databricks Workflows job definitions MUST reproduce the workflow
  DAG, its dependencies, and its notification behaviour.
- **FR-009** Session shell commands MUST be emitted as explicit tasks, with byte-
  order-asserted tests for concatenations *(P-15)*.
- **FR-010** Variable propagation MUST be emitted end to end, from resolution
  through to any filename or email that consumes it *(P-16)*.
- **FR-011** No credential, hostname or account name may appear in generated
  code; delivery targets MUST come from a secret scope or configuration.
- **FR-012** Every generated file MUST carry a header naming the generator
  version, the model digest, the plan digest, and the source object path
  *(Article IV, IX)*.
- **FR-013** Generation MUST be idempotent: unchanged inputs produce
  byte-identical output.
- **FR-014** Generated code MUST NOT be hand-edited; CI MUST fail on any diff
  *(Article IX)*.

### Conformance requirements

Per construct, for any input *(Article XI)*. Each is asserted by the
corresponding pattern's counter-example test, which fails under the naive
translation.

- **CR-001** Every stateful port generates a window expression or refuses. Zero
  stateless emissions *(P-02)*.
- **CR-002** Every Router generates independent filtered outputs, never an
  if/elif chain *(P-10)*.
- **CR-003** Every Update Strategy target generates `MERGE INTO`, never
  overwrite or append *(P-11)*.
- **CR-004** Every Joiner maps master/detail outer joins correctly, with a test
  per join type *(P-09)*.
- **CR-005** Normalizers dispatch on `ISVSAM_NORMALIZER`: VSAM generates
  offset-based fixed-width reads with `posexplode` for the GCID, pipeline
  generates column-group `posexplode` with a 1-based GCID. Neither receives the
  other's treatment *(P-07, P-21)*.
- **CR-006** Every connected Lookup generates a left-outer join, never inner;
  every unconnected Lookup rewrites the pipeline shape rather than emitting a
  scalar *(P-04, P-20)*.
- **CR-007** Every Sequence Generator generates persistent sequence state, never
  `monotonically_increasing_id` *(P-13)*.
- **CR-008** Every Union generates `unionByName`, never positional `union`
  *(P-22)*.
- **CR-009** Every Rank generates `row_number`, never `rank`/`dense_rank`
  *(P-23)*.
- **CR-010** Every Decision task generates a task-level condition, never a data
  filter *(P-28)*.
- **CR-011** Every worklet generates a nested job or task group preserving
  variable scope, never a flattened inline copy *(P-29)*.
- **CR-012** Every reusable object and shortcut generates exactly one definition
  with n importing consumers, never n inlined copies, and instance-level
  overrides appear at the call site *(P-30)*.
- **CR-013** Every T3 construct generates a manual-port contract and no
  implementation *(P-26)*.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Databricks workspace, cluster policy and secret scopes | platform | yes | Platform engineering |
| Delivery mechanism replacing the repository's file-transfer scripts | integration | yes | Platform engineering |
| Byte format expected by downstream consumers of fixed-width deliverables | integration | yes | Receiving systems' owners |
| Who implements each manual port, and to what deadline | governance | yes | Migration lead |

### Key entities

- **GeneratedModule** — one PySpark module per mapping. Carries generator
  version, model digest, plan digest, source path.
- **GeneratedTestSuite** — pytest module: counter-example, schema and
  transformation tests.
- **JobDefinition** — Databricks Workflows JSON for one workflow.
- **GenerationRefusal** — object path, reason code, detail. Produces no code.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** Every object with an approved plan produces exactly one of: a
  compiling module with a passing test suite, a manual-port contract with a
  failing-until-implemented contract test, or an explicit refusal. No fourth
  outcome, and no silent partial module.
- **SC-002** 100% of generated modules import and compile, for any input.
- **SC-003** Every generated test suite passes locally with no Databricks
  connection.
- **SC-004** Zero stateless emissions for any stateful port, and zero inferred
  implementations for any T3 construct.
- **SC-005** Zero `TODO`, `FIXME`, `pass  #` or placeholder tokens in generated
  code, verified by a grep gate in CI.
- **SC-006** Zero credentials, hostnames or account names in generated code,
  verified by a secret-scan gate.
- **SC-007** Regeneration produces byte-identical output; CI diff is clean.
- **SC-008** A PowerCenter SME reviewing a 10-module sample can trace every
  function to its source transformation without assistance.
- **SC-009** Every construct at T1 or T2 in the registry has at least one
  generated-and-passing fixture in `synthetic-core`; a construct with none
  cannot hold that tier.

---

## Edge Cases

- **Mapping with no pipeline effect.** Generates the shell-replacement task and
  a test that the output file is produced; never an empty module that passes.
- **Two mappings in an equivalence group.** One shared module with parameters;
  each member's ledger row references it, and the differences are asserted by
  tests.
- **Target with 534 columns.** Generated in full. If the emitted module is
  unwieldy, structure is a generator concern; dropping columns is not an option.
- **Pattern requires a parameter the plan omits** (e.g. a window spec for P-02).
  Refuse; do not infer.
- **Refusal partway through a wave.** Objects that generated successfully are
  retained; the refused object blocks only itself and its dependents.

## Assumptions

- Databricks Runtime provides the Delta features the patterns need — `MERGE`,
  identity columns, task values. Version-pinned in `plan.md`; a downgrade
  invalidates several patterns.

## Dependencies

- **Upstream** 002 (compiled expressions), 005 (approved plans), 003 (ledger),
  `docs/pattern-catalog.md`
- **Downstream** 007 validates the generated code's output.

---

## Review & Acceptance Checklist

- [x] No implementation detail beyond the platform decided in ADR-0001/0003
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)* — FR-003, FR-004
- [x] Provenance requirements stated *(Article IV)* — FR-012
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] T3 manual-port contracts specified; no stubs or guesses *(Article XII)* —
      FR-005a
- [x] Human-approval boundaries identified *(Article VIII)* — none here;
      generation follows an already-approved plan
- [x] All `[NEEDS CLARIFICATION]` resolved
