# Implementation Plan: Spark Code Generation

**Branch** `006-spark-codegen` · **Date** 2026-09-10 · **Spec** [spec.md](spec.md)

## Summary

A template-driven emitter that turns an approved migration plan plus compiled
expression ASTs into a PySpark module, a pytest suite and a Databricks Workflows
job definition. The emitter is deterministic and does the mechanical work; the
codegen agent contributes only names, docstrings and provenance comments. Any
input the emitter cannot translate faithfully produces a refusal and no file.

## Technical Context

| | |
| --- | --- |
| Language / version | Python 3.11 (generator); generated code targets Python 3.11 / PySpark 3.5 |
| Primary dependencies | Jinja2 (templates), `black` (deterministic formatting), `libcst` (AST assertions on output), pytest, `chispa` (DataFrame assertions) |
| Storage | Delta on Unity Catalog (generated code's target); generated artifacts on disk, digest-addressed |
| Testing | pytest against a local `SparkSession`; no Databricks connection required |
| Target platform | Databricks Runtime 15.4 LTS, Unity Catalog enabled |
| Project type | Deterministic emitter + narrow agent contribution |
| Performance target | Full-corpus generation under 10 minutes; single object under 20 s excluding agent latency |
| Constraints | No network in the emitter. No credential may reach generated code. Output must be byte-identical on regeneration. |
| Scale | Capacity target 10,000 objects; targets of at least 1,000 columns; 30 catalog patterns |
| Constructs in scope | Every T1 and T2 construct in the registry; T3 constructs produce a manual-port contract |
| Conformance corpora | `synthetic-core` (every T1/T2 construct), `synthetic-adversarial`, `hhs-payroll` |

## Constitution Check

*Gate: passed before Phase 0. Re-checked after Phase 1.*

| Article | Check | Pass | Notes |
| --- | --- | --- | --- |
| I — Deterministic core | Expression bodies come from 002; the agent contributes no logic | ✅ | Enforced by T032: a `libcst` pass asserts every expression body's provenance is a compiled AST id |
| II — Fail loudly | Four refusal classes; atomic write means no partial modules | ✅ | T030, T031 |
| III — Scoped identity | Module and function names derive from fully qualified paths | ✅ | Collision test T013 |
| IV — Provenance | Every file header carries generator, model digest, plan digest, source path | ✅ | FR-012 |
| V — Semantics first | Generation refuses on any pattern whose counter-example test fails | ✅ | T029 runs the catalog suite as a precondition |
| VI — Parity | Generated schema tests are a precondition on `TESTED`; 007 owns data parity | ✅ | |
| VII — Gaps | Missing pattern parameters refuse rather than infer | ✅ | T030 |
| VIII — Human approval | None; generation follows an approved plan and refuses if approval is stale | ✅ | |
| IX — Regenerable | Deterministic formatting; CI diff gate; hand-written manual ports preserved | ✅ | T041, T042, FR-005b |
| X — Readable | Agent-authored docstrings and provenance comments; SME review gate | ✅ | T043, SC-008 |
| XI — Corpus independence | Every CR is per-construct; SCs are invariants over any input | ✅ | Counter-example tests are construct fixtures, not corpus slices |
| XII — Declared coverage | Dispatch refuses on T4; T3 emits a contract, never a stub | ✅ | T029, T030, FR-005a |

**Post-Phase-1 re-check:** passed. The one point of tension is Article I versus
Article X — readable output needs authored naming, which is agent work. Resolved
by scope: the agent may name and explain, never compute. T032 enforces the line
mechanically rather than by convention.

## Project Structure

### Artifacts produced by this plan

```
specs/006-spark-codegen/
├── plan.md
├── research.md
├── data-model.md
├── contracts/
│   ├── generated-module.md        # required shape of an emitted module
│   └── job-definition.schema.json
├── quickstart.md
└── tasks.md
```

### Source layout

```
migration-factory/core/emit/
├── __init__.py
├── dispatch.py            # pattern id -> emitter; unknown id refuses
├── ir/                    # platform-neutral intermediate representation
├── backends/
│   └── databricks/        # the one implemented backend (ADR-0007)
│       ├── module.py      # module assembly in pipeline order
│       ├── tests.py       # pytest suite emission
│       ├── jobs.py        # Databricks Workflows JSON
│       ├── schema.py      # PowerCenter -> Delta type mapping
│       └── templates/     # Jinja2
├── contract.py            # T3 manual-port contract emission
├── format.py              # deterministic formatting
└── refuse.py              # GenerationRefusal, atomic-write guard

migration-factory/patterns/               # pattern plugins, one per construct
│                                         # each = catalog entry + counter-example
│                                         #        test + emitter (ADR-0007)
migration-factory/generated/              # output; never hand-edited except
                                          # manual-port implementations
```

## Phase 0 — Research

- [ ] **R1** Confirm DBR 15.4 LTS supports every Delta feature the patterns need:
      `MERGE` with multiple `WHEN MATCHED` clauses, identity columns, task
      values. A gap invalidates P-11 or P-13.
- [ ] **R2** Determine the deterministic formatting configuration that keeps
      output byte-identical across `black` versions, and pin it.
- [ ] **R3** Decide the module shape for a 534-column target: a generated column
      list constant, or an explicit projection. Readability (Article X) versus
      file size.
- [ ] **R4** Establish how the emitter proves a window ordering for P-02 from
      upstream Source Qualifier sort ports, and what evidence it records.
- [ ] **R5** Fix the fixed-width writer approach for byte-exact deliverables,
      including trailing-sign and implied-decimal encoding on output.
- [ ] **R6** Confirm the secret-scope mechanism for file-transfer destinations
      and how the emitter references it without embedding hostnames.
- [ ] **R7** Fix the IR boundary: what a pattern emitter produces, and what the
      backend consumes. This is what keeps pattern semantics testable
      independently of PySpark idiom.
- [ ] **R8** Manual-port contract shape for each T3 construct kind — connected,
      unconnected and pre/post-session Stored Procedure differ, and so do Java
      and adapter transformations.
- [ ] **R9** How a hand-written manual-port implementation survives
      regeneration without weakening the Article IX no-hand-edit rule for
      generated files.

Output → `research.md`.

## Phase 1 — Design

- [ ] `data-model.md` — GeneratedModule, GeneratedTestSuite, JobDefinition,
      GenerationRefusal
- [ ] `contracts/generated-module.md` — required header, function-per-
      transformation rule, comment rules
- [ ] `contracts/job-definition.schema.json`
- [ ] `quickstart.md`
- [ ] Constitution Check re-run

## Phase 2 — Task generation

See [tasks.md](tasks.md).

## Complexity Tracking

| Article | Violation | Why necessary | Simpler alternative rejected because |
| --- | --- | --- | --- |
| — | none | | |

Two recorded tensions, neither a violation:

Article I (deterministic core) versus Article X (readability): good naming is
judgment, so the agent must contribute it. Resolved by scope — the agent names
and explains, never computes — enforced by a `libcst` check (T032) rather than
by trusting the prompt.

Article IX (never hand-patched) versus the T3 manual-port path, which is
hand-written by design. Resolved by partitioning the output: generated files are
never hand-edited and CI diffs them; manual-port implementations live in
separately named files that the generator creates once and never overwrites.

## Verification

1. `mfctl generate --object 'Test_Repo_Srvc/CPM/m_CPM_NIH_Load_CPM_NIH_Data_File'`
   → module, test suite and job JSON emitted; module imports; tests pass.
2. `pytest generated/.../test_m_cpm_nih_load_cpm_nih_data_file.py` → passes
   locally with no Databricks connection.
3. `mfctl generate --object '.../m_CPM_Load_CPM_NEWPAY_STG_ALT_TBL'` → the
   stateful accumulator emits a `row_number()` window with the upstream sort
   recorded, **or** refuses with `ordering-unproven` and writes nothing.
4. `mfctl generate --object '.../m_LES_Load_LES_EMP_DETAIL_TBL'` → three
   independent router outputs; the generated P-10 counter-example test passes and
   fails when the emitter is patched to if/elif.
5. `mfctl generate --object '.../m_Pseudossn_Update_Timekeeper_Number'` → a
   `MERGE INTO` on the planned merge key; the P-11 test proves unselected rows
   survive.
5a. `mfctl generate --wave synthetic-core` → every T1/T2 construct generates a
   compiling module with a passing suite; every T3 construct generates a
   contract whose test fails while unimplemented and no stub *(SC-001, SC-009)*.
5b. `mfctl generate` for a construct at T4 → refused, naming the construct.
6. `grep -rnE 'TODO|FIXME|pass  #|NotImplemented' generated/` → no matches
   *(SC-005)*.
7. `mfctl generate --all && mfctl generate --all --out b && diff -r generated b`
   → identical *(SC-007)*.
8. Secret scan over `generated/` → no credential, hostname or account name
   *(SC-006)*.
9. Attempt generation against a plan whose approval digest is stale → refused.
10. Implement a manual port, regenerate → the implementation survives and
    everything around it is regenerated *(FR-005b)*.
