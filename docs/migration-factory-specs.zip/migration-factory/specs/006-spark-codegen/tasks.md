# Tasks: Spark Code Generation

**Branch** `006-spark-codegen` · **Plan** [plan.md](plan.md)

`[P]` = parallelisable within its phase. Every pattern emitter is written after
its counter-example test exists and fails.

## Phase 3.1 — Setup

- [ ] **T001** Emitter package skeleton, `mfctl generate` entry point —
      `core/emit/`
- [ ] **T002** [P] Deterministic formatting harness, pinned per R2 —
      `core/emit/format.py`
- [ ] **T003** [P] Atomic-write guard: emit to temp, verify, rename; any refusal
      leaves nothing *(Article II)* — `core/emit/refuse.py`
- [ ] **T004** [P] Local `SparkSession` fixture for generated tests —
      `tests/spark/conftest.py`

## Phase 3.2 — Tests first

*Counter-example tests for every pattern used. Each MUST fail under the naive
translation before its emitter exists *(Article V)*.*

- [ ] **T010** [P] P-01 port declaration order — `tests/patterns/test_p01.py`
- [ ] **T011** [P] P-02 stateful accumulator: six rows, two keys, expected
      `1,2,3,1,2,1`; fails under a stateless emitter — `tests/patterns/test_p02.py`
- [ ] **T012** [P] P-03 predicate from all three Source Qualifier attributes —
      `tests/patterns/test_p03.py`
- [ ] **T013** [P] P-04 lookup miss survives; multi-match does not fan out —
      `tests/patterns/test_p04.py`
- [ ] **T014** [P] P-05 SQL override with a non-equi condition —
      `tests/patterns/test_p05.py`
- [ ] **T015** [P] P-06 null filter condition does not drop from both branches —
      `tests/patterns/test_p06.py`
- [ ] **T016** [P] P-07 copybook decode: `+9(3)V9(2)` positive, negative, zero;
      `posexplode` preserves GCID — `tests/patterns/test_p07.py`
- [ ] **T017** [P] P-08 aggregator with no group-by yields one row —
      `tests/patterns/test_p08.py`
- [ ] **T018** [P] P-09 all four master/detail outer join types —
      `tests/patterns/test_p09.py`
- [ ] **T019** [P] P-10 a row satisfying two router groups reaches both outputs —
      `tests/patterns/test_p10.py`
- [ ] **T020** [P] P-11 merge preserves rows the update did not select —
      `tests/patterns/test_p11.py`
- [ ] **T021** [P] P-12 distinct on sort keys only —
      `tests/patterns/test_p12.py`
- [ ] **T022** [P] P-13 sequence does not reissue across two runs —
      `tests/patterns/test_p13.py`
- [ ] **T023** [P] P-14 mapplet ports resolve via Input/Output Transformations —
      `tests/patterns/test_p14.py`
- [ ] **T024** [P] P-15 concatenation byte order: header precedes detail —
      `tests/patterns/test_p15.py`
- [ ] **T025** [P] P-16 variable propagation reaches the output filename —
      `tests/patterns/test_p16.py`
- [ ] **T025a** [P] P-20 unconnected lookup rewrites pipeline shape; no fan-out
      and no evaluation on the untaken branch — `tests/patterns/test_p20.py`
- [ ] **T025b** [P] P-21 pipeline normalizer: 1-based GCID, per-input-row
      generated key, and **not** the VSAM path — `tests/patterns/test_p21.py`
- [ ] **T025c** [P] P-22 union by name with reordered ports and duplicates
      preserved — `tests/patterns/test_p22.py`
- [ ] **T025d** [P] P-23 rank returns exactly N per group across a boundary tie —
      `tests/patterns/test_p23.py`
- [ ] **T025e** [P] P-24 transaction control: commit boundaries become
      partitions; rolled-back batch leaves no rows —
      `tests/patterns/test_p24.py`
- [ ] **T025f** [P] P-25 SQL transformation refuses a per-row dynamic query and
      validates the set-based rewrite — `tests/patterns/test_p25.py`
- [ ] **T025g** [P] P-26 manual-port contract: correct signature and types, test
      fails unimplemented, no stub or guess emitted —
      `tests/patterns/test_p26.py`
- [ ] **T025h** [P] P-27 XML with an optional element absent from the sample
      still appears in the schema — `tests/patterns/test_p27.py`
- [ ] **T025i** [P] P-28 decision skips a branch rather than running it empty;
      job status distinguishes the two — `tests/patterns/test_p28.py`
- [ ] **T025j** [P] P-29 worklet variable scope isolated across two invocations,
      nested three deep — `tests/patterns/test_p29.py`
- [ ] **T025k** [P] P-30 one definition, n importing consumers, override at the
      call site; absent shared folder refuses — `tests/patterns/test_p30.py`
- [ ] **T026** [P] Refusal tests: unprovable ordering, unimplemented function,
      T4 construct, missing pattern parameter, stale approval — each asserts
      **no file written** *(Article II)* — `tests/contract/test_refusal.py`
- [ ] **T026a** [P] Placeholder-absence test: no generated output contains a
      stub, `TODO`, `NotImplemented` or pass-through for any T3 construct; the
      only `NotImplementedError` permitted is inside an emitted manual-port
      contract *(Article XII)* — `tests/contract/test_no_stubs.py`
- [ ] **T027** [P] Boundary-enforcement test: patch the agent to emit an
      expression body and assert the `libcst` check rejects it *(Article I)* —
      `tests/contract/test_agent_boundary.py`

## Phase 3.3 — Emitters

- [ ] **T028** Pattern dispatch table; an unknown id refuses —
      `core/emit/dispatch.py`
- [ ] **T029** Catalog precondition: run every counter-example test for the
      patterns an object needs, and refuse if any fails *(Article V)* —
      `core/emit/dispatch.py`
- [ ] **T030** Refusal classes and reason codes; every refusal writes a
      `GenerationRefusal` and no code — `core/emit/refuse.py`
- [ ] **T031** PowerCenter → Delta type mapping; decimal precision and scale
      preserved, floating substitution rejected — `core/emit/schema.py`
- [ ] **T032** Agent-boundary check: `libcst` pass asserting every expression
      body traces to a compiled AST id *(Article I)* — `core/emit/module.py`
- [ ] **T033** [P] Emitters P-01, P-03, P-06, P-08, P-12 (low-risk) —
      `core/emit/patterns/`
- [ ] **T034** [P] Emitter P-02: window translation with ordering proof;
      refuses without one — `core/emit/patterns/p02_stateful.py`
- [ ] **T035** [P] Emitters P-04, P-05: left-outer joins, SQL override,
      non-equi conditions — `core/emit/patterns/p04_lookup.py`
- [ ] **T036** [P] Emitter P-07: offset-based fixed-width read, record-type
      discrimination, `posexplode`, `PICTURE` decoding —
      `core/emit/patterns/p07_normalizer.py`
- [ ] **T037** [P] Emitter P-09: master/detail outer join mapping —
      `core/emit/patterns/p09_joiner.py`
- [ ] **T038** [P] Emitter P-10: independent outputs; if/elif is unreachable by
      construction — `core/emit/patterns/p10_router.py`
- [ ] **T039** [P] Emitter P-11: `MERGE INTO` from the planned merge key —
      `core/emit/patterns/p11_update_strategy.py`
- [ ] **T040** [P] Emitter P-13: persistent sequence state —
      `core/emit/patterns/p13_sequence.py`
- [ ] **T041** [P] Emitters P-15, P-16: shell-replacement tasks, variable
      propagation via task values — `patterns/p15_shell/`, `patterns/p16_variables/`
- [ ] **T041a** [P] Emitters P-20, P-21, P-22, P-23 — `patterns/`
- [ ] **T041b** [P] Emitters P-24, P-25, P-27 (T2, with restrictions enforced) —
      `patterns/`
- [ ] **T041c** [P] Emitters P-28, P-29, P-30 (workflow and identity
      constructs) — `patterns/`
- [ ] **T041d** T3 contract emitter: one contract shape per T3 construct kind;
      never a stub *(FR-005a)* — `core/emit/contract.py`

## Phase 3.4 — Assembly and gates

- [ ] **T042** Module assembly in pipeline order, with file header carrying
      generator version, model digest, plan digest, source path *(Article IV)* —
      `core/emit/module.py`
- [ ] **T043** Agent contribution: docstrings, names, provenance comments;
      output constrained to those slots *(Article X)* — `agents/codegen/`
- [ ] **T044** Test suite emission: counter-examples, target schema, per-
      transformation assertions — `core/emit/tests.py`
- [ ] **T045** Databricks Workflows job emission from the workflow DAG,
      including shell-replacement and delivery tasks — `core/emit/jobs.py`
- [ ] **T046** Placeholder gate: fail on `TODO`, `FIXME`, `pass  #`,
      `NotImplemented` in output *(SC-005)* — `core/emit/module.py`
- [ ] **T047** Secret gate: fail on any credential, hostname or account name in
      output *(SC-006, FR-011)* — `core/emit/module.py`
- [ ] **T048** Approval-staleness check before any emission —
      `core/emit/dispatch.py`

## Phase 3.5 — Integration and polish

- [ ] **T049** `mfctl generate --object | --wave | --all` with refusal reporting
      and non-zero exit — `core/cli.py`
- [ ] **T050** Idempotence test: two full generations are byte-identical
      *(SC-007)* — `tests/corpus/test_generation_idempotent.py`
- [ ] **T051** CI diff gate on `generated/` *(Article IX)* —
      `.github/workflows/ci.yml`
- [ ] **T052** [P] Corpus coverage report: per object, generated or refused with
      reason. No third outcome *(SC-001)*
- [ ] **T053** [P] SME review pack: 10 modules spanning complexity bands, with
      the review questions *(SC-008)*
- [ ] **T054** [P] `quickstart.md` walked by someone who has not seen the code

## Dependencies

```
T001 ──> T002,T003,T004
             │
             v
      T010..T027  (all [P] — every counter-example and contract test)
             │
             v
   T028 ──> T029 ──> T030 ──> T031 ──> T032
             │
   ┌─────────┼──────────┬─────────┬─────────┐
   v         v          v         v         v
 T033      T034       T035      T036 ...  T041     (all [P])
             │
             v
   T042 ──> T043 ──> T044 ──> T045
             │
   T046 ──> T047 ──> T048
             │
   T049 ──> T050 ──> T051 ──> T052,T053,T054
```

`T029` before every emitter is the Article V gate: an emitter cannot run for a
pattern whose counter-example is failing. `T032` before the emitters is the
Article I gate.

## Parallel execution example

```
# after T004 — the full test suite
T010 T011 T012 T013 T014 T015 T016 T017 T018 T019 T020 T021 T022 T023 T024 T025 \
T025a T025b T025c T025d T025e T025f T025g T025h T025i T025j T025k T026 T026a T027

# after T032 — every pattern emitter
T033 T034 T035 T036 T037 T038 T039 T040 T041 T041a T041b T041c T041d
```

## Definition of done

- [ ] Every FR-001..FR-014 maps to at least one task
- [ ] Every CR-001..CR-013 has a counter-example test that fails under the naive
      translation
- [ ] Every T1/T2 construct in the registry generates a passing fixture in
      `synthetic-core`; every T3 construct emits a contract
- [ ] Every pattern used has a passing counter-example test that fails under the
      naive translation
- [ ] Every refusal test confirms no partial output
- [ ] Placeholder and secret gates pass on the full corpus
- [ ] Regeneration diff is clean
- [ ] Constitution Check re-run and passing
- [ ] `plan.md` Verification steps 1–10 executed and recorded
