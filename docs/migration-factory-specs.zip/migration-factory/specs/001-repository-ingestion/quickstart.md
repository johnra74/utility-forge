# Quickstart: Repository Ingestion

The shortest path from a directory of PowerCenter exports to a queryable model.
Assumes the repository is checked out and Python 3.11 is available.

## 1. Install

```sh
cd migration-factory
python3 -m venv .venv && . .venv/bin/activate
pip install -e .
```

No network is needed at runtime. If `pip install` reaches the network, that is
build-time only; `core.*` must not import anything that can make a request, and
`tests/contract/test_no_network.py` enforces it.

## 2. Check coverage before ingesting anything

Always the first move on an unfamiliar repository — it answers "can we convert
this?" without converting anything:

```sh
mfctl coverage corpora/hhs-payroll/XML
```

If that reports T4 unknown constructs, stop and extend coverage (feature 009);
ingesting first just wastes the round trip.

## 3. Ingest

```sh
mfctl ingest corpora/hhs-payroll/XML --out build/model
```

Output on the reference corpus — your counts will differ, the shape will not:

```
11 exports, 108 mappings, 1 mapplet, 752 transformations, 30,445 connectors
14 construct types, all with declared tiers
model digest sha256:a3f1…
6 gap types, 0 resolved
```

If you see `VALIDATION FAILED — no artifacts written`, the model does not hang
together and nothing was written. That is working as designed (Article II): read
the named objects and fix the parser or the input.

## 4. Confirm the edge count by hand

The one number you can check without trusting the tool:

```sh
echo $(( $(wc -l < build/model/edges.csv) - 1 ))
grep -oh '<CONNECTOR' corpora/hhs-payroll/XML/* | wc -l
```

Both must print the same number — `30445` for this corpus. This is the one
figure a reader can verify without trusting the tool, which is why the CLI
emits `edges.csv` alongside the Parquet.

## 5. Look at an object

Always by fully qualified path — a bare name is a usage error, not a search:

```sh
mfctl model get 'Test_Repo_Srvc/CPM/m_CPM_NIH_Load_CPM_NIH_Data_File/SQ_CPM_NEWPAY_TBL'
```

Now look at its near-namesake in a different mapping:

```sh
mfctl model get 'Test_Repo_Srvc/CPM/m_CPM_NIH_Build_Message/SQ_CPM_NEWPAY_TBL'
```

Same predicate, but the first reports `from: User Defined Join` and the second
`from: Source Filter`. That is the whole argument for Article III and CR-002 in
two commands.

## 6. Resolve a shortcut or a reusable object

```sh
mfctl ingest corpora/synthetic-identity --out build/id
mfctl model resolve 'REPO/ORDERS/m_Load/rt_Standardise_Address'
```

```
instance        REPO/ORDERS/m_Load/rt_Standardise_Address
definition      REPO/SHARED_UTIL/rt_Standardise_Address   (folder-level reusable)
consumers       7 mappings across 3 folders
overrides       IN_COUNTRY default: 'US' (instance-level)
```

One definition, seven consumers. Inlining a copy per consumer would work and
would convert a maintained shared object into seven divergent ones — see
[P-30](../../docs/pattern-catalog.md#p-30-shortcuts-and-reusable-objects).
The reference corpus contains no shortcuts or reusable objects at all, which is
exactly why `synthetic-identity` exists.

## 7. Find the traps before they find you

```sh
mfctl model flags --stateful       # every one needs pattern P-02
mfctl model flags --sets-variables # every one needs pattern P-16
mfctl model flags --shell-only     # mappings whose real work is a shell command
```

On the reference corpus that is 115, 66 and 7 respectively; on yours it is
whatever the repository contains.

A stateful port translated as a stateless expression compiles, runs, and computes
the wrong answer without changing any row count. These lists are the reason
ingestion detects them rather than leaving it to the codegen agent to notice.

## 8. Trace a column

```sh
mfctl lineage \
  'Test_Repo_Srvc/CPM/m_CPM_NIH_Build_Message/CPM_NIH_MESSAGE_FILE.MESSAGE' \
  --resolved
```

```
agg_Count_CPM_NIH.o_CPM_NIH_TOTAL    aggregate-over-rows   expression-inferred
lkp_Pay_Period_Total.COUNT_TOTAL     lookup-sql-result     expression-inferred
```

Neither origin is a source column, and that is correct: one is `COUNT(*)`, the
other comes from a lookup's SQL override. `--exact` shows only repository
connectors, with nothing inferred.

## 9. See what the repository does not contain

```sh
mfctl gaps --blocking
```

These are properties of the PowerCenter export format, so every repository has
whichever apply. On the reference corpus, note that every output filename is a
`$Param_*` value resolved from a parameter file the export does not contain — so
no object can be planned for cutover until PowerCenter administration supplies
them. Article VII exists so this appears here rather than as an invented filename
in generated code.

## 10. Prove it is reproducible

```sh
mfctl ingest corpora/hhs-payroll/XML --out build/model2
mfctl diff build/model build/model2 --exit-on-diff && echo "identical"
```

## What to read next

- [data-model.md](data-model.md) — entities, identity scopes and invariants
- [contracts/cli.md](contracts/cli.md) — full CLI surface and exit codes
- [../../docs/construct-coverage.md](../../docs/construct-coverage.md) — what the
  coverage tiers from step 2 mean
- [../../docs/pattern-catalog.md](../../docs/pattern-catalog.md) — what the flags
  from step 7 mean for translation
