# Data Model: Repository Ingestion

Canonical model entities, their identity, and their invariants. Identity follows
Constitution Article III throughout: no entity is keyed on a bare name.

## Identity

Scope follows PowerCenter's declaration scope *(Article III)*.

```
export_id          := <export filename>
folder_path        := <repository>/<folder>
mapping_path       := <repository>/<folder>/<mapping>
object_path        := <repository>/<folder>/<mapping>/<object>      mapping-scoped
folder_object_path := <repository>/<folder>/<object>                folder-scoped:
                        sources, targets, reusable transformations,
                        reusable sessions, reusable schedulers, mapplets
worklet_task_path  := <repository>/<folder>/<worklet>[/<worklet>…]/<task>
port_path          := <object_path|folder_object_path>.<port>
```

An instance carrying a numeric suffix (`PAY_PERIOD1`) keeps that suffix in its
identity; the de-suffixed name appears only in `DependencyEdge.object_name`.

**Exports are not one-to-one with folders in either direction.** One export may
hold several folders; several exports may be partial exports of one folder.
Identity keys on repository and folder, never on the export filename.

### Shortcut and reusable-instance resolution

| Field | Type | Notes |
| --- | --- | --- |
| `ObjectRef.instance_path` | string | identity in the referring folder |
| `ObjectRef.definition_path` | string | identity where the object is declared |
| `ObjectRef.ref_kind` | enum | `direct`, `local-shortcut`, `global-shortcut`, `reusable-instance` |
| `ObjectRef.overrides` | map | instance-level overrides; empty for `direct` |

*Invariants:* a definition is stored **once** regardless of how many instances
reference it; a `global-shortcut` whose defining folder is absent from the input
set raises an `absent-shared-folder` gap and MUST NOT be resolved by inference
from the shortcut's port signature; a shortcut chain that cycles is refused.

## Provenance

Every entity carries a `Provenance` block *(Article IV)*.

| Field | Type | Notes |
| --- | --- | --- |
| `export_file` | string | e.g. `CPM_NIH` |
| `export_timestamp` | datetime | `POWERMART/@CREATION_DATE` |
| `repository` | string | e.g. `Test_Repo_Srvc` |
| `environment` | enum | `Production` \| `Test` \| `Unknown` — from the declared environment map, never inferred from a name prefix *(Article IV)* |
| `repository_version` | string | `POWERMART/@REPOSITORY_VERSION` |
| `ingester_version` | string | semver of the ingester |
| `source_digest` | string | SHA-256 of the export file |

`environment = Unknown` is a hard error for any downstream cutover plan, never
silently treated as production. It is the correct value whenever the engagement's
environment map has no entry for a repository — nothing in the export identifies
an environment.

## Entities

### Export

| Field | Type | Notes |
| --- | --- | --- |
| `export_id` | string | PK |
| `folder` | string | |
| `folder_owner` | string | |
| `folder_description` | string | |
| `provenance` | Provenance | |

*Invariant:* exactly one `FOLDER` per export in this corpus; more than one is
supported but each becomes its own `folder_path`.

### Mapping

| Field | Type | Notes |
| --- | --- | --- |
| `mapping_path` | string | PK |
| `is_mapplet` | bool | |
| `is_valid` | bool | `MAPPING/@ISVALID` |
| `description` | string | |
| `variables` | list[MappingVariable] | |
| `target_load_order` | list[string] | instance names, ordered |
| `flags` | set[enum] | `shell-only`, `dummy-source`, `stateful-ports` |
| `provenance` | Provenance | |

*Invariant:* a mapping's transformations are resolvable **only** from that
mapping. Folder-level lookup is prohibited.

### Transformation

| Field | Type | Notes |
| --- | --- | --- |
| `object_path` | string | PK |
| `type` | enum | resolved against the construct registry; T4 unknown → refuse (FR-012). *Reference corpus exercises 14 of ~30.* |
| `coverage_tier` | enum | `T1` / `T2` / `T3` / `T4`, from the registry *(Article XII)* |
| `unmet_restrictions` | list[string] | populated for T2 constructs whose preconditions are absent |
| `attributes` | map[string, string] | `TABLEATTRIBUTE` verbatim, blanks dropped but absence distinguished from empty |
| `attributes_present` | set[string] | names seen, including empty-valued — needed for CF-002 |
| `is_vsam_normalizer` | bool | |
| `router_groups` | list[RouterGroup] | ordered by `@ORDER` |
| `ports` | list[Port] | declared order preserved |
| `provenance` | Provenance | |

*Invariants:*
- `attributes` and `attributes_present` differ exactly where an attribute exists
  with an empty value. An empty `Source Filter` must be distinguishable from no
  `Source Filter`.
- Port order is the repository's declared order, which is semantically
  significant for variable ports (P-01).

### Port

| Field | Type | Notes |
| --- | --- | --- |
| `port_path` | string | PK |
| `name` | string | |
| `ordinal` | int | declared position |
| `porttype` | enum | `INPUT`, `OUTPUT`, `INPUT/OUTPUT`, `LOCAL VARIABLE`, `LOOKUP`, `LOOKUP/OUTPUT`, `LOOKUP/RETURN/OUTPUT`, `INPUT/OUTPUT/MASTER`, `INPUT/MASTER`, `GENERATED KEY/OUTPUT`, `GENERATED COLUMN ID/OUTPUT` |
| `datatype` / `precision` / `scale` | string / int / int | |
| `expression` | string | verbatim, including comments |
| `expression_type` | enum | `GENERAL`, `GROUPBY`, none |
| `is_sort_key` / `sort_direction` | bool / enum | |
| `is_stateful` | bool | true when a `LOCAL VARIABLE` port's expression references itself, so it retains value across rows (P-02). *Reference corpus: 115.* |
| `is_passthrough` | bool | expression equals the port name |
| `sets_variables` | list[string] | `$$` variables written via `SETVARIABLE`, which persist beyond the session (P-16). *Reference corpus: 66 calls.* |

*Invariant:* `is_stateful` implies the port needs P-02 treatment; the emitter
must refuse a stateless translation.

### Connector

Exact repository edge. **Nothing here is inferred.**

| Field | Type |
| --- | --- |
| `mapping_path` | string |
| `from_port_path` / `to_port_path` | string |
| `from_instance_type` / `to_instance_type` | enum |

*Invariant:* the count of Connector rows equals the count of `CONNECTOR`
elements in the input. This is SC-002 and is checked in CI.

### ResolvedOrigin

Transitive resolution. **Inference lives here and only here.**

| Field | Type | Notes |
| --- | --- | --- |
| `mapping_path` | string | |
| `target_port_path` | string | |
| `origin_port_path` | string | |
| `origin_reason` | enum | `source-column`, `literal`, `mapping-parameter`, `aggregate-over-rows`, `lookup-sql-result`, `sequence`, `unresolved` |
| `method` | enum | `connector-only`, `expression-inferred` |

*Invariant:* `method = expression-inferred` marks edges derived from expression
analysis. In this feature that analysis is token matching, which over-reports;
002 replaces it with an AST without changing this schema.

### RecordLayout / LayoutField

| Field | Type | Notes |
| --- | --- | --- |
| `folder_object_path` | string | owning source |
| `layout_name` | string | top-level `GRPITEM` |
| `record_length` | int | |
| `redefines` | string | |
| `fields` | list[LayoutField] | leaves, in offset order |

`LayoutField`: `name`, `offset`, `length`, `physical_offset`,
`physical_length`, `datatype`, `picture`, `usage`, `usage_flags`, `occurs`,
`level`, `nullable`.

*Invariant:* `picture` containing `V` or a sign character, or `usage_flags`
containing `TRAILING_SIGN`, sets a `copybook-encoding` gap on the owning object
*(P-07, Article VII)*.

### SessionComponent

| Field | Type | Notes |
| --- | --- | --- |
| `session_path` | string | `<folder_path>/<session>` |
| `stage` | enum | `Pre-session command`, `Post-session success command`, `Failure Email`, `Pre-session variable assignment`, `Post-session success variable assignment`, `Post-session failure variable assignment` |
| `commands` | list[string] | verbatim, ordered by `EXECORDER` |
| `variable_assignments` | list[(string, string)] | target, source |
| `invokes_scripts` | list[string] | script basenames resolved from command text |

*Invariant:* a session whose mapping has no pipeline effect and which carries a
command sets `shell-only` on the mapping *(FR-009, P-15)*.

### Gap

| Field | Type | Notes |
| --- | --- | --- |
| `gap_id` | string | PK |
| `type` | enum | `parameter-file`, `external-orchestration`, `environment-map`, `external-code-body`, `referenced-schema`, `absent-shared-folder`, `mainframe`, `copybook-encoding`, `provenance`, `business-key`, `pattern-missing`, `ordering-unproven` |
| `detail` | string | e.g. the `$Param_` token |
| `blocking` | bool | |
| `owner_role` | string | |
| `blocks` | list[string] | object paths |
| `status` | enum | `unresolved`, `resolved` — resolution requires evidence, recorded in the ledger (003) |

### DependencyEdge

Cross-folder producer/consumer relation, for wave sequencing.

| Field | Type | Notes |
| --- | --- | --- |
| `object_name` | string | de-suffixed table/file name |
| `access` | enum | `read`, `write`, `lookup` |
| `workflow` | string | |
| `mapping_path` | string | |
| `is_shared_utility` | bool | true when written by ≥3 workflows — excluded from wave ordering |

## Model version

| Field | Type | Notes |
| --- | --- | --- |
| `model_digest` | string | SHA-256 over the canonical serialisation |
| `created_at` | datetime | |
| `ingester_version` | string | |
| `export_digests` | map[export_id, string] | |

*Invariant:* identical inputs and ingester version produce an identical
`model_digest` *(Article IX)*.

## Entity relationships

```mermaid
erDiagram
    Export ||--o{ Folder : contains
    Folder ||--o{ Mapping : contains
    Folder ||--o{ Worklet : contains
    Worklet ||--o{ Worklet : nests
    ObjectRef }o--|| Transformation : "resolves to definition"
    Mapping ||--o{ ObjectRef : references
    Export ||--o{ Mapping : contains
    Export ||--o{ RecordLayout : declares
    Export ||--o{ SessionComponent : declares
    Mapping ||--o{ Transformation : "owns (scoped)"
    Mapping ||--o{ Connector : contains
    Mapping ||--o{ ResolvedOrigin : yields
    Transformation ||--o{ Port : declares
    Transformation ||--o{ RouterGroup : declares
    RecordLayout ||--o{ LayoutField : contains
    Gap }o--o{ Mapping : blocks
    Mapping ||--o{ DependencyEdge : produces
```
