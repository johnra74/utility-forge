# Implementation Plan: Repository Ingestion

**Branch** `001-repository-ingestion` · **Date** 2026-09-10 · **Spec** [spec.md](spec.md)

## Summary

Graduate the `PowerCenter/tools/` documentation prototype into
`migration-factory/core/`: a stdlib-only Python package that parses any
PowerCenter `POWERMART` export set into a versioned, digest-addressed canonical
model with provenance, refuses to emit on any inconsistency, and exposes both a
CLI and a library.

Extends the prototype in two directions. **Depth** — record-layout physical
detail, session-command extraction, stateful-port detection, and a typed gap
report, none of which documentation needed. **Breadth** — scope-accurate
identity across shortcuts, folder-level reusable objects and nested worklets;
version-aware parsing; multi-folder and multi-repository inputs; and a coverage
tier on every construct. The prototype handled one estate's shape; this handles
the metamodel.

## Technical Context

| | |
| --- | --- |
| Language / version | Python 3.11 |
| Primary dependencies | stdlib only for parsing; Pydantic v2 for the emitted model contract; `pytest` |
| Storage | Content-addressed model artifacts on disk (Parquet + JSON manifest); no database |
| Testing | pytest, with the eleven-export corpus as a golden fixture |
| Target platform | Any POSIX host; must run with no network access |
| Project type | Deterministic tool — no model calls *(Article I)* |
| Performance target | ≥ 400 KB export XML per second single-threaded; ≥ 10× faster on unchanged input via the digest cache |
| Constraints | No network. No model calls. Parsing must not depend on the unshipped `powrmart.dtd`. Must be version-aware. |
| Scale | Capacity target 10,000 objects / 500 MB of export XML. The reference corpus (21 MB, 108 mappings, 752 transformations, 30,445 connectors) is one test input. |
| Constructs in scope | Every construct in `docs/construct-coverage.md`, at whatever tier the registry declares. Ingestion models T3 constructs too — refusal is a conversion-time decision. |
| Conformance corpora | `synthetic-core`, `synthetic-identity`, `synthetic-adversarial`, `hhs-payroll` |

No unresolved `[NEEDS CLARIFICATION]` items: the prototype has already
established the format's behaviour empirically.

## Constitution Check

*Gate: passed before Phase 0. Re-checked after Phase 1 — see below.*

| Article | Check | Pass | Notes |
| --- | --- | --- | --- |
| I — Deterministic core | Zero model calls; this feature is entirely core | ✅ | Enforced by an import-level test that no agent or HTTP library is reachable |
| II — Fail loudly | FR-008 defines five refusal checks and a non-zero exit | ✅ | Prototype precedent: refused on 1,100 inconsistencies before emitting |
| III — Scoped identity | FR-002, FR-003, FR-003a/b; no bare-name keys; scope matches declaration scope | ✅ | Schema test on key patterns, plus `synthetic-identity` assertions for shortcuts, reusables and nested worklets |
| IV — Provenance | FR-004 on every record | ✅ | |
| V — Semantics first | Not applicable — ingestion translates nothing | ✅ | Flags (`stateful`, `shell-only`) feed the catalog rather than applying it |
| VI — Parity | Not applicable — no data movement | ✅ | |
| VII — Gaps | FR-010 emits the typed gap report | ✅ | Six gap classes, all blocking |
| VIII — Human approval | No irreversible effects | ✅ | |
| IX — Regenerable | Digest-addressed output; CI regenerates and diffs | ✅ | T041 |
| X — Readable | Model field names mirror PowerCenter vocabulary | ✅ | `porttype`, `Lookup condition` etc. kept verbatim rather than renamed |
| XI — Corpus independence | Every SC is an invariant over an arbitrary input | ✅ | T004a asserts no test pins a single estate's object count |
| XII — Declared coverage | FR-012 records a tier per construct; T4 refuses | ✅ | Registry from 009; unknown-construct test T019b |

**Post-Phase-1 re-check:** passed. `data-model.md` introduced no bare-name keys
and no inferred fields; the `origin_reason` enum keeps inference visibly
separated from exact edges; identity now carries three scope forms plus shortcut
resolution.

## Project Structure

### Artifacts produced by this plan

```
specs/001-repository-ingestion/
├── plan.md
├── data-model.md
├── contracts/
│   ├── canonical-model.schema.json
│   └── cli.md
├── quickstart.md
└── tasks.md
```

### Source layout

```
migration-factory/core/
├── parse/
│   ├── __init__.py
│   ├── model.py            # dataclasses: Export, Mapping, Transformation, Port, ...
│   ├── reader.py           # POWERMART XML -> model
│   ├── layouts.py          # nested SOURCEFIELD -> RecordLayout with offsets/PICTURE
│   ├── sessions.py         # SESSIONCOMPONENT -> commands, emails, var assignments
│   ├── flags.py            # stateful-port and shell-only detection
│   └── registry.py         # known-construct registry; unknown -> refuse (FR-012)
├── lineage/
│   ├── edges.py            # exact CONNECTOR edges, no inference
│   ├── resolve.py          # transitive origin resolution + origin_reason
│   └── deps.py             # cross-folder producer/consumer graph
├── gaps/
│   └── report.py           # typed gap report (FR-010)
├── validate/
│   └── checks.py           # the five refusal checks (FR-008)
├── emit/
│   └── artifacts.py        # Parquet + manifest, content digest, version diff
└── cli.py                  # `mfctl ingest`, `mfctl model`, `mfctl gaps`, `mfctl diff`

migration-factory/tests/
├── corpus/                 # golden assertions against the 11-export corpus
├── unit/
└── contract/
```

## Phase 0 — Research

Format behaviour was established empirically while building the documentation
generator. Recorded as settled findings rather than open questions:

- [x] Attribute values span lines — text matching finds nothing; XML parser
      required.
- [x] ISO-8859-1 with an unresolvable external DTD — `ElementTree` ignores it;
      a validating parser fails.
- [x] In the reference corpus all 752 transformations are mapping-scoped and
      none is folder-level reusable — but that is a property of that estate, not
      of PowerCenter. Both scopes must be supported, and `synthetic-identity`
      exercises the folder-level case.
- [x] COBOL sources nest `SOURCEFIELD`: top-level `GRPITEM` per record layout,
      each `REDEFINES` the first, `ELEMITEM` leaves carrying `PICTURETEXT` and
      offsets.
- [x] Session commands and variable assignments live in `SESSIONCOMPONENT`
      inside each `SESSION`, not in the folder `TASK` list. Variable assignments
      are `VALUEPAIR`s on the component; shell commands are `VALUEPAIR`s on the
      component's inner `TASK`.
- [x] `CONNECTOR` records only inter-instance edges. Intra-transformation
      dependencies live in port expressions.
- [x] Router `GROUP` elements carry an `ORDER` attribute that must be preserved.

Open items for Phase 0:

- [ ] **R1** Element and attribute availability per repository version across
      181–190, and the verified range per construct. Needs sample exports at
      versions other than `187.96`, which is a blocking gap.
- [ ] **R2** Shortcut resolution semantics: how a local shortcut, a global
      shortcut and a shared folder are represented, and what an instance may
      override on a reusable transformation.
- [ ] **R3** Worklet variable scoping and re-initialisation per invocation.

Deferred to 002, not blocking here:

- [ ] Intra-transformation dependency extraction is token-matching in the
      prototype. It over-reports, which is acceptable for lineage and
      **unacceptable for translation**. 002 replaces it with a real AST; this
      feature's `origin_reason` field is designed so the substitution is a
      drop-in.

## Phase 1 — Design

- [x] `data-model.md` — entities, identity, invariants
- [x] `contracts/canonical-model.schema.json` — record schema
- [x] `contracts/cli.md` — CLI surface and exit codes
- [x] `quickstart.md`
- [x] Constitution Check re-run

## Phase 2 — Task generation

See [tasks.md](tasks.md).

## Complexity Tracking

| Article | Violation | Why necessary | Simpler alternative rejected because |
| --- | --- | --- | --- |
| — | none | | |

One judgment call worth recording, though not a violation: the prototype's
token-matching intra-transformation lineage is retained in this feature and
superseded in 002. It is kept because lineage documentation is useful before the
expression compiler exists, and because `origin_reason` makes the inference
visible rather than passing it off as exact. Article I is not breached — the
heuristic is deterministic code, not model judgment.

## Verification

1. `mfctl ingest corpora/hhs-payroll/XML --out build/model` → element census
   matching the input exactly, exit 0. Repeat for each conformance corpus.
2. `wc -l build/model/edges.csv` minus header equals
   `grep -oh '<CONNECTOR' ../PowerCenter/XML/* | wc -l` → 30,445.
3. `mfctl model get 'Test_Repo_Srvc/CPM/m_CPM_NIH_Load_CPM_NIH_Data_File/SQ_CPM_NEWPAY_TBL'`
   → predicate present, sourced from `User Defined Join`.
4. `mfctl model get '.../m_CPM_NIH_Build_Message/SQ_CPM_NEWPAY_TBL'` → the same
   predicate, sourced from `Source Filter`. Confirms CR-002 and Article III.
5. `mfctl ingest corpora/synthetic-identity --out build/id` then
   `mfctl model get` on a reusable transformation → one definition, three
   instance references; on a local shortcut → definition resolved from its home
   folder. Confirms CR-007 and CR-008.
6. `mfctl model flags --stateful` on `synthetic-core` → exactly the fixture's
   known count.
7. `mfctl gaps` → every gap class present in the input, every `$Param_*`
   unresolved.
8. Corrupt one `CONNECTOR` `TOFIELD` in a copy of an export, re-run ingest →
   no output written, offending path named, exit 3.
9. Inject an invented transformation type → exit 4, naming the construct.
10. Set `REPOSITORY_VERSION` outside the verified range → refusal with a version
    message.
11. `mfctl ingest` twice on an unchanged input → identical model digest.
