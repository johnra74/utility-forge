# Feature Specification: Repository Ingestion

**Feature Branch** `001-repository-ingestion`
**Created** 2026-09-10 · **Status** Draft
**Input** Turn any PowerCenter repository export set into a canonical,
queryable, provenance-carrying model that every downstream feature reads instead
of XML.

---

## User Scenarios & Testing

### User Story 1 — Parse an export into a canonical model (P1)

A migration engineer points the ingester at a directory of PowerCenter
repository exports. It produces one canonical model containing every folder,
workflow, session, mapping, transformation, port, connector, source, target,
record layout, connection and session command, with each record carrying the
export it came from and whether that export is a production copy.

**Why this priority:** every other feature in the factory reads this model. With
no model there is no analysis, no plan, no codegen, no parity.

**Independent test:** run the ingester over each conformance corpus and assert
that every object in the input appears in the model, that the emitted connector
count equals the `CONNECTOR` element count in the input, and that there are zero
validation failures.

**Acceptance scenarios**

1. **Given** any conformance corpus, **When** ingestion runs, **Then** every
   folder, mapping, transformation, port and connector in the input appears in
   the model exactly once and the process exits zero.
2. **Given** a declared environment mapping and an export from a repository it
   names as non-production, **When** ingestion runs, **Then** every record from
   that export carries that environment; **and given** no mapping entry for a
   repository, **Then** its records carry `environment = Unknown`.
3. **Given** two transformations named `exp_Final` in different mappings,
   **When** both are queried, **Then** each returns its own ports and its own
   attributes, addressed by its fully qualified path.
4. **Given** a mapping instance whose definition is absent, **When** ingestion
   runs, **Then** nothing is written, the offending path is reported, and the
   process exits non-zero.
5. **Given** a repository version outside the verified range, **When** ingestion
   runs, **Then** it refuses with a version message rather than parsing on a
   best-effort basis.

### User Story 2 — Resolve field-level lineage (P1)

The engineer asks where a target column's value comes from. The model answers
with the repository's own connector edges, and separately with a transitively
resolved origin that also accounts for dependencies *inside* transformations.

**Why this priority:** lineage is the input to pattern selection, to impact
analysis, and to the Unity Catalog lineage diff that makes parity automatable.

**Independent test:** query the resolved origin of
`.../m_CPM_NIH_Load_CPM_NIH_Data_File/nihtest_NIH_PAYROLL_MASTER.BASE_PAY` and
confirm it terminates at either a source column or a port with no upstream
column, with the reason recorded.

**Acceptance scenarios**

1. **Given** a target port fed through four chained Expressions, **When** its
   origin is resolved, **Then** the result names source columns, not intermediate
   ports.
2. **Given** a port whose value is `COUNT(*)`, **When** its origin is resolved,
   **Then** it is reported as having no source column, with reason
   `aggregate-over-rows`.
3. **Given** the exact connector edges, **When** they are exported, **Then** the
   row count equals the number of `CONNECTOR` elements in the input, and no edge
   is inferred.

### User Story 3 — Extract the layers PowerCenter lineage hides (P1)

Ingestion extracts fixed-width record layouts with byte offsets and `PICTURE`
clauses, every pre/post-session shell command, and every mapping-variable
assignment, as first-class model records.

**Why this priority:** the corpus performs real data movement outside mappings.
Six workflows deliver their output entirely through post-session `cat` and SFTP
commands. A migration that reads only mappings generates jobs that run green and
deliver nothing.

**Independent test:** assert that `m_CPM_NIH_Concatenate_Files` is flagged
`shell-only`, and that its post-session command text is retrievable from the
model.

**Acceptance scenarios**

1. **Given** `YTD_FILE`, **When** its layouts are queried, **Then** three record
   layouts are returned, each with leaf fields carrying offset, length, `PICTURE`
   and redefines target.
2. **Given** a session with a post-session success command, **When** queried,
   **Then** the command text and its stage are returned verbatim.
3. **Given** a mapping whose only real effect is a shell command, **When**
   ingested, **Then** it carries the `shell-only` flag.

### User Story 4 — Resolve identity across folders and worklets (P1)

The engineer ingests a repository containing shortcuts, folder-level reusable
transformations, reusable sessions, and worklets nested several deep. Each
object resolves at the scope PowerCenter declares it, with shortcut definitions
resolved from the referenced folder and reusable definitions stored once.

**Why this priority:** these constructs are routine in real PowerCenter estates
and they change what identity *means*. Getting them wrong produces both classes
of error — attributing one object's logic to another, and fragmenting one shared
definition into many copies.

**Independent test:** ingest `synthetic-identity` and assert that a reusable
transformation instantiated in three mappings yields one definition and three
instance references, and that a local shortcut's definition resolves from its
home folder.

**Acceptance scenarios**

1. **Given** a folder-level reusable transformation instantiated in three
   mappings, **When** ingested, **Then** one definition exists and three
   instances reference it; the definition is not duplicated.
2. **Given** a reusable transformation instance carrying port-level overrides,
   **When** ingested, **Then** the overrides are recorded on the instance and
   the definition is unchanged.
3. **Given** a local shortcut, **When** its definition is requested, **Then** it
   resolves from the referenced folder, and both identities are recorded.
4. **Given** a global shortcut whose shared folder is absent from the input set,
   **When** ingested, **Then** a blocking gap is raised and the definition is
   **not** inferred from the shortcut's port signature.
5. **Given** a worklet nested three deep, **When** ingested, **Then** each task
   carries a worklet-scoped path and each worklet's variable scope is preserved.
6. **Given** an export containing several folders, **When** ingested, **Then**
   each folder is a distinct scope; **and given** several exports of the same
   folder, **Then** they contribute to one folder scope.

### User Story 5 — Enumerate gaps (P2)

Ingestion emits the list of things a PowerCenter export structurally cannot
contain: every `$Param_*` reference with no definition, every on-demand workflow
with no schedule, every construct whose body lives outside the repository, every
referenced-but-absent XSD or shared folder, and every signed or packed `PICTURE`
clause whose encoding is unconfirmed.

**Why this priority:** Article VII forbids assuming these away. Making them a
generated list rather than tribal knowledge is what stops an agent inventing a
filename.

**Independent test:** run the gap report over any corpus and confirm every
`$Param_*` token in the input appears exactly once, typed and unresolved.

**Acceptance scenarios**

1. **Given** any input, **When** the gap report runs, **Then** every distinct
   `$Param_*` token appears with type `parameter-file` and status `unresolved`.
2. **Given** any workflow whose scheduler is on-demand, **When** the gap report
   runs, **Then** it appears with type `external-orchestration`.
3. **Given** a Stored Procedure, Java, External Procedure or Custom
   transformation, **When** the gap report runs, **Then** it appears with type
   `external-code-body`.
4. **Given** an XML source referencing an XSD, **When** the gap report runs,
   **Then** the XSD appears with type `referenced-schema`.

### User Story 6 — Re-ingest a refreshed export (P2)

A production re-export of a folder previously only available as a Test copy is
dropped in. Ingestion produces a new model version, and the diff against the
previous version is reported per object.

**Why this priority:** export sets routinely mix environments and arrive
incrementally, so re-ingestion and diffing is a routine operation rather than an
edge case. In the reference corpus seven of eleven exports are non-production
copies needing later replacement.

**Independent test:** ingest the corpus twice with one export replaced; confirm
the diff names only objects in that folder.

**Acceptance scenarios**

1. **Given** two model versions, **When** diffed, **Then** added, removed and
   changed objects are listed by fully qualified path.
2. **Given** an unchanged export, **When** re-ingested, **Then** the model digest
   is identical.

---

## Requirements

### Functional

- **FR-001** The system MUST parse PowerCenter `POWERMART` XML exports using an
  XML parser, never text matching, and MUST tolerate the unresolvable external
  DTD reference and ISO-8859-1 encoding.
- **FR-002** The system MUST address every object by a fully qualified path
  whose scope matches PowerCenter's declaration scope — mapping-scoped,
  folder-scoped or worklet-scoped — and MUST NOT use a bare name as a key
  *(Article III)*.
- **FR-003** The system MUST resolve a mapping-scoped transformation only within
  its owning mapping, and MUST store a folder-level reusable object once with
  instance references rather than duplicating it per consumer.
- **FR-003a** The system MUST record both identities of a shortcut — the
  referring folder and the defining folder — and MUST resolve the definition from
  the referenced folder. It MUST raise a blocking gap, not infer a definition,
  when the defining folder is absent from the input set.
- **FR-003b** The system MUST preserve worklet nesting to arbitrary depth and
  the variable scope at each level.
- **FR-004** The system MUST record, per record: source export filename, export
  timestamp, repository name, repository version, environment, and ingester
  version *(Article IV)*. Environment MUST come from a declared per-engagement
  mapping of repository and Integration Service names, MUST NOT be inferred from
  a name prefix, and MUST be `Unknown` where no mapping entry exists.
- **FR-005** The system MUST parse nested `SOURCEFIELD` hierarchies into record
  layouts, preserving group structure, byte offset, length, `PICTURE` text,
  `REDEFINES` target and usage flags.
- **FR-006** The system MUST extract session components — pre/post-session
  commands, failure email tasks, and variable assignments — as model records
  distinct from the folder's workflow-level tasks.
- **FR-007** The system MUST emit exact field-connector edges with no inference,
  and separately emit transitively resolved origins with each origin labelled
  `source-column` or a reason for having none.
- **FR-008** The system MUST validate the model before emitting anything, and
  MUST refuse to write output and exit non-zero on any failure *(Article II)*.
  Minimum checks: instance→definition resolution; connector endpoints are real
  ports on real instances; session→mapping resolution; workflow link→task
  resolution; mapplet port exposure via Input/Output Transformations.
- **FR-009** The system MUST flag a mapping `shell-only` when its pipeline has no
  effect other than session shell commands.
- **FR-010** The system MUST emit a typed gap report *(Article VII)*.
- **FR-011** The system MUST produce a stable content digest per model version
  and support diffing two versions by fully qualified path.
- **FR-012** The system MUST resolve every construct it encounters against the
  construct registry and MUST record its coverage tier. An unknown construct
  (T4) MUST cause refusal rather than partial ingestion *(Article XII)*.
- **FR-012a** The system MUST be repository-version aware, MUST record
  `REPOSITORY_VERSION`, and MUST refuse a version outside the verified range
  rather than parsing on a best-effort basis.
- **FR-012b** The system MUST support several folders in one export file and
  several exports contributing to one folder scope, in either combination.
- **FR-013** The system MUST expose the model as a CLI and as an importable
  library, with no network access and no model calls *(Article I,
  [ADR-0005](../../docs/adr/0005-deterministic-core-agent-boundary.md))*.

### Conformance requirements

Stated against constructs *(Article XI)*. Corpus citations are evidence that the
requirement matters, not the requirement itself.

- **CR-001** Name collisions at any scope MUST be preserved as distinct objects.
  *Evidence:* in the reference corpus `exp_Final` occurs 29 times in one folder
  with port counts from 2 to 677 and different logic in each.
- **CR-002** Source Qualifier predicates MUST be collected from `Sql Query`,
  `Source Filter` **and** `User Defined Join`, and an empty attribute MUST be
  distinguishable from an absent one. *Evidence:* two sibling mappings in the
  reference corpus carry the same predicate in different attributes.
- **CR-003** A `LOCAL VARIABLE` port whose expression references itself MUST be
  flagged stateful. *Evidence:* 115 instances in the reference corpus, including
  a group-sequence accumulator driving a de-normalising pivot.
- **CR-004** `SETVARIABLE` calls MUST be extracted as variable-persistence
  records. *Evidence:* 66 calls in the reference corpus whose values reach
  delivered filenames.
- **CR-005** Router groups MUST retain repository order and default-group
  marking. *Evidence:* a reference-corpus router whose first group is literally
  `TRUE`, so every row multicasts.
- **CR-006** Mapplet instance ports MUST resolve through the mapplet's
  Input/Output Transformations. *Evidence:* the single mapplet in the reference
  corpus produced 15 validation failures before this was handled.
- **CR-007** A folder-level reusable transformation MUST yield one definition and
  n instance references, with instance-level overrides recorded on the instance.
  *Covered by:* `synthetic-identity` — no real corpus on hand exercises it.
- **CR-008** A shortcut MUST resolve its definition from the referenced folder,
  and MUST refuse when that folder is absent. *Covered by:*
  `synthetic-identity`.
- **CR-009** Worklet nesting and per-worklet variable scope MUST be preserved to
  arbitrary depth. *Covered by:* `synthetic-identity`.
- **CR-010** Both Normalizer kinds MUST be distinguished by
  `ISVSAM_NORMALIZER`, since they need unrelated translations. *Evidence:* the
  reference corpus is 23 VSAM to 16 pipeline, so dispatching on transformation
  type alone is wrong 41% of the time there.
- **CR-011** Every construct MUST carry its registry coverage tier on the model
  record *(Article XII)*.

### Gaps this feature must surface

These are properties of the PowerCenter export format, so every engagement has
whichever of them apply to its repository.

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Session parameter files: every `$Param_*`, typically including output filenames | parameter-file | yes | PowerCenter administration |
| Trigger order for on-demand workflows | external-orchestration | yes | Operations |
| Mapping of repository / Integration Service names to environments | environment-map | yes | PowerCenter administration |
| Bodies of Stored Procedure, External Procedure, Java, Custom transformations | external-code-body | yes | Application owner |
| XSDs referenced by XML sources and targets | referenced-schema | yes | Data provider |
| Shared folders referenced by global shortcuts but absent from the input set | absent-shared-folder | yes | PowerCenter administration |
| PowerExchange listener configuration for non-relational targets | mainframe | yes | Mainframe operations |
| Physical encoding of signed/packed `PICTURE` clauses | copybook-encoding | yes | Data provider |
| Production re-export where the supplied export is non-production | provenance | yes | PowerCenter administration |
| Merge keys for Update Strategy targets | business-key | yes | PowerCenter SME |

### Key entities

- **Export** — one XML file. Identity: filename. Carries repository, folder,
  environment, export timestamp.
- **Mapping** — identity `<repository>/<folder>/<mapping>`.
- **Transformation** — identity `<repository>/<folder>/<mapping>/<object>`. Type,
  attributes, ports, router groups, stateful-port flag.
- **Port** — identity: transformation path + port name. Datatype, precision,
  scale, port type, expression, expression type, sort key flag.
- **Connector** — an exact repository edge: from port → to port within a mapping.
- **RecordLayout** — a top-level `GRPITEM` group of a fixed-width source, with
  leaf fields carrying offset, length, `PICTURE`, redefines target.
- **SessionComponent** — a pre/post-session command, failure email, or variable
  assignment, bound to its session.
- **Gap** — something absent from the corpus. Type, blocking status, owner,
  the objects it blocks.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*. Every one is
asserted against every conformance corpus, not against a single estate.

- **SC-001** **Completeness.** For any input, every folder, mapping,
  transformation, port, connector, source, target, task and session in the export
  appears in the model exactly once. Measured by a round-trip element census:
  model record counts equal input element counts per type, with zero
  discrepancies.
- **SC-002** **Connector fidelity.** Emitted exact-edge rows equal the count of
  `CONNECTOR` elements in the input. Verifiable by hand with `grep -c`, which is
  the one number a reader can check without trusting the tool.
- **SC-003** **Zero silent loss.** For any input, ingestion either produces a
  model passing every validation check or writes nothing and exits non-zero.
  There is no third outcome, and no input produces a model with warnings.
- **SC-004** **Refusal integrity.** Introducing any of the validation-check
  violations into any corpus causes no output to be written and a non-zero exit
  naming the object. Asserted once per check.
- **SC-005** **Flag completeness.** Every stateful variable port, `SETVARIABLE`
  call, shell-only mapping and dummy-source mapping present in the input is
  retrievable by fully qualified path. Asserted by construction against
  `synthetic-core`, where the expected count is known exactly, and by
  regression-pinned counts on real corpora.
- **SC-006** **Gap completeness.** Every `$Param_*` token, on-demand workflow,
  external code body, referenced schema and absent shared folder in the input
  appears in the gap report exactly once, none marked resolved.
- **SC-007** **Identity correctness.** For `synthetic-identity`: a reusable
  transformation instantiated n times yields one definition and n instance
  references; shortcut definitions resolve from the referenced folder; worklet
  nesting and variable scope survive to the fixture's maximum depth.
- **SC-008** **Determinism.** Two ingestions of identical inputs with the same
  ingester version produce an identical model digest.
- **SC-009** **Throughput.** Ingestion sustains at least 400 KB of export XML
  per second single-threaded with no network access, and re-ingestion of an
  unchanged input is at least 10× faster via the digest cache.
- **SC-010** **Hand-checkable.** A reviewer can pick any mapping, query the
  model, and confirm ports, attributes and connectors against the raw XML in
  under 10 minutes.

---

## Edge Cases

- **Non-production export.** Ingested normally, carrying the environment the
  declared mapping gives it. Downstream features refuse to plan cutover on it;
  that is not ingestion's job.
- **Repository not in the environment mapping.** `environment = Unknown`, which
  is never treated as production.
- **Bare-name collision at any scope.** Preserved as distinct objects; never
  merged.
- **Instance with a numeric suffix** (`PAY_PERIOD1`). Kept as the instance
  identity; normalisation to the underlying table happens only in dependency
  analysis.
- **Empty vs absent attribute.** Distinguished. An empty `Source Filter` is not
  the same as no `Source Filter`, and CR-002 depends on the difference.
- **Unknown construct (T4).** Refused per FR-012, not partially ingested.
- **T3 construct.** Ingested and recorded with its tier; refusal is a
  conversion-time decision, not an ingestion-time one. Ingestion must model
  constructs it cannot convert, or coverage reporting is impossible.
- **Circular shortcut chain.** Detected and refused rather than followed.
- **Same folder in several exports.** Merged into one folder scope; a conflicting
  definition of the same object across exports is a refusal, not a
  last-writer-wins merge.
- **Export with no folders.** Valid but empty; ingested as zero objects rather
  than treated as malformed.

## Assumptions

- Exports are complete for the folders they contain. If an export is truncated,
  FR-008 validation catches it as unresolved references rather than silently
  producing a smaller model.
- Environment is knowable only from a declared mapping supplied per engagement.
  Nothing in the export identifies an environment, and naming conventions are
  local. Where the mapping is missing, `Unknown` is the honest answer.
- The `powrmart.dtd` metamodel is stable within a repository-version range.
  Cross-version differences are handled by version-aware parsing and a verified
  range, not by tolerant parsing.

## Dependencies

- **Upstream** the conformance corpora in `corpora/`; the construct registry
  from [009](../009-construct-coverage/spec.md); the `PowerCenter/tools/`
  prototype, which this feature graduates and hardens.
- **Downstream** every other feature. 002 consumes port expressions; 003 keys
  ledger rows on these identities; 004–008 read the model exclusively; 009
  computes coverage from it.

---

## Review & Acceptance Checklist

- [x] No implementation detail
- [x] Every requirement testable and unambiguous
- [x] Every user story independently testable and prioritised
- [x] Success criteria measurable and technology-agnostic
- [x] Refusal conditions stated *(Article II)*
- [x] Provenance requirements stated *(Article IV)*
- [x] Object identity fully qualified throughout *(Article III)*
- [x] Corpus gaps enumerated with owners *(Article VII)*
- [x] No requirement or success criterion cites one estate's object counts
      *(Article XI)*
- [x] Coverage tiers recorded per construct *(Article XII)* — FR-012
- [x] Human-approval boundaries identified — none in this feature; it is
      deterministic and produces no irreversible effects
- [x] All `[NEEDS CLARIFICATION]` markers resolved
