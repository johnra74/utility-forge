# Contract: `mfctl` ingestion CLI

Deterministic. No network. No model calls. Same inputs and version produce
byte-identical output.

## Exit codes

| Code | Meaning |
| --- | --- |
| 0 | Success; all artifacts written |
| 2 | Usage error |
| 3 | **Validation failure — no artifacts written** *(Article II)* |
| 4 | Unknown PowerCenter construct encountered — tier T4 *(FR-012)* |
| 5 | Input unreadable or not a POWERMART export |
| 6 | Repository version outside the verified range *(FR-012a)* |

Codes 3 and 4 guarantee that no output file has been created or modified.

## `mfctl ingest <xml-dir> --out <model-dir>`

Parses every file in `<xml-dir>` and writes a canonical model.

```
--out PATH            model output directory (required)
--fail-on-unknown     default true; false downgrades code 4 to a report
--cache PATH          digest cache; unchanged exports are not reparsed
--json                machine-readable summary on stdout
```

Output:

```
<model-dir>/
├── manifest.json          # ModelVersion: digest, ingester version, export digests
├── exports.parquet
├── mappings.parquet
├── transformations.parquet
├── ports.parquet
├── connectors.parquet     # exact edges; row count == CONNECTOR element count
├── origins.parquet        # ResolvedOrigin, with method and origin_reason
├── layouts.parquet
├── session_components.parquet
├── dependency_edges.parquet
├── gaps.parquet
└── edges.csv              # human-checkable mirror of connectors.parquet
```

Stdout on success — shape of the output, illustrated on the `hhs-payroll`
reference corpus:

```
11 exports, 108 mappings, 1 mapplet, 752 transformations, 30,445 connectors
14 construct types, all with declared tiers
model digest sha256:<hex>
6 gap types, 0 resolved
```

Stdout on validation failure (exit 3):

```
VALIDATION FAILED — no artifacts written
  Test_Repo_Srvc/CPM/m_CPM_Load_CPM_NEWPAY_STG_ALT_TBL/mplt_Convert_Num_To_Prec7
    connector TO 'mplt_Convert_Num_To_Prec7.IN_NUM_FIELD_1' is not a port of that instance
  ... 14 more in this mapping
1100 inconsistencies across 2 mappings
```

## `mfctl model get <path>`

Retrieves one object by fully qualified path. A bare name is a usage error
(exit 2), never a lookup *(Article III)*.

```
mfctl model get 'Test_Repo_Srvc/CPM/m_CPM_NIH_Load_CPM_NIH_Data_File/SQ_CPM_NEWPAY_TBL'
```

```
type            Source Qualifier
predicate       from: User Defined Join
                CPM_NEWPAY_TBL.PP_END_YEAR = TO_NUMBER('$$MAP_PP_END_YEAR')
                AND CPM_NEWPAY_TBL.PP_NUM = TO_NUMBER('$$MAP_PP_NUM')
                AND CPM_NEWPAY_TBL.MP_POOL_DES = ' '
                AND CPM_NEWPAY_TBL.BUSINESS_UNIT = 'NIH00'
sorted ports    3
ports           463
environment     Test        <-- not production evidence
```

## `mfctl model flags [--stateful|--shell-only|--dummy-source|--sets-variables]`

Lists object paths carrying a flag. Counts are whatever the input contains — on
the `hhs-payroll` reference corpus, `--stateful` returns 115 rows and
`--sets-variables` returns 66.

## `mfctl lineage <target-port-path> [--exact|--resolved]`

`--exact` walks only repository connectors. `--resolved` returns origins with
`origin_reason` and `method`.

```
mfctl lineage 'Test_Repo_Srvc/CPM/m_CPM_NIH_Build_Message/CPM_NIH_MESSAGE_FILE.MESSAGE' --resolved
```

```
agg_Count_CPM_NIH.o_CPM_NIH_TOTAL    aggregate-over-rows   expression-inferred
lkp_Pay_Period_Total.COUNT_TOTAL     lookup-sql-result     expression-inferred
```

## `mfctl gaps [--type T] [--blocking]`

The typed gap report *(FR-010)*.

## `mfctl model resolve <path>`

Resolves an object to its **definition**, following a shortcut into its defining
folder or an instance to its folder-level reusable definition. Reports both
identities and any instance-level overrides. Refuses when a global shortcut's
shared folder is absent from the input set *(FR-003a)*.

```
mfctl model resolve 'REPO/ORDERS/m_Load/rt_Standardise_Address'
```

```
instance        REPO/ORDERS/m_Load/rt_Standardise_Address
definition      REPO/SHARED_UTIL/rt_Standardise_Address   (folder-level reusable)
consumers       7 mappings across 3 folders
overrides       IN_COUNTRY default: 'US' (instance-level)
```

## `mfctl diff <model-dir-a> <model-dir-b>`

Per-object diff by fully qualified path. Exit 0 whether or not differences
exist; `--exit-on-diff` returns 1 when they do, for the CI regeneration check
*(Article IX)*.

## Library surface

```python
from migration_factory.core.parse import ingest
from migration_factory.core.validate import validate

model = ingest("PowerCenter/XML")          # raises ValidationError, never returns partial
obj   = model.get("Test_Repo_Srvc/CPM/m_CPM_NIH_Build_Message/exp_Build_Message")
```

`ingest()` raises rather than returning a partially valid model. There is no
`strict=False`.
