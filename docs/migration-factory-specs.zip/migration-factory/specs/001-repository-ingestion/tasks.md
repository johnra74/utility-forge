# Tasks: Repository Ingestion

**Branch** `001-repository-ingestion` · **Plan** [plan.md](plan.md)

`[P]` = parallelisable within its phase. Tests precede the code they cover.
The `PowerCenter/tools/` prototype is the starting point for T020–T023; the rest
is new.

## Phase 3.1 — Setup

- [ ] **T001** Package skeleton, `pyproject.toml`, `mfctl` entry point —
      `migration-factory/core/`, `pyproject.toml`
- [ ] **T002** [P] Conformance corpus registry and fixtures: pin every corpus by
      SHA-256 so a change is a deliberate act; build `synthetic-core`,
      `synthetic-identity` and `synthetic-adversarial` — `tests/corpus/conftest.py`,
      `corpora/`
- [ ] **T003** [P] Import-guard test: assert no HTTP or model-SDK module is
      reachable from `core.*` *(Article I)* — `tests/contract/test_no_network.py`
- [ ] **T004** [P] Identity-pattern test: every key in every emitted record
      matches one of the three qualified-path patterns in
      `contracts/canonical-model.schema.json` *(Article III)* —
      `tests/contract/test_identity.py`
- [ ] **T004a** [P] Corpus-independence check: no test asserts an object count
      against a real corpus except in the explicitly named regression-pin module
      *(Article XI)* — `tests/contract/test_corpus_independence.py`

## Phase 3.2 — Tests first

*These MUST be written and MUST fail before Phase 3.3.*

- [ ] **T010** [P] Round-trip census, corpus-independent: for **every** corpus,
      model record counts per type equal input element counts per type, zero
      discrepancies *(SC-001)* — `tests/corpus/test_census.py`
- [ ] **T010a** [P] Regression pins: exact counts for each real corpus, in one
      clearly named module so they are visibly regression pins and not
      requirements *(Article XI)* — `tests/corpus/test_regression_pins.py`
- [ ] **T011** [P] Connector parity: emitted edge count equals `CONNECTOR`
      element count *(SC-002)* — `tests/corpus/test_connector_parity.py`
- [ ] **T012** [P] Name-collision test: 29 distinct `exp_Final` objects in
      `Test_Repo_Srvc/CPM`, port counts spanning 2 to 677, each resolving to its
      own definition *(CR-001)* — `tests/corpus/test_name_collisions.py`
- [ ] **T013** [P] Predicate placement: both `SQ_CPM_NEWPAY_TBL` definitions
      compile to the same predicate, one from `User Defined Join` and one from
      `Source Filter` *(CR-002)* — `tests/corpus/test_predicate_placement.py`
- [ ] **T014** [P] Empty-vs-absent attribute: an empty `Source Filter` is
      distinguishable from an absent one — `tests/unit/test_attributes.py`
- [ ] **T015** [P] Stateful ports: exact expected set detected in
      `synthetic-core`, where it is known by construction; regression-pinned on
      real corpora *(CR-003)* — `tests/corpus/test_stateful_ports.py`
- [ ] **T016** [P] `SETVARIABLE` extraction: exact expected set in
      `synthetic-core`; asserts a full persistence chain end to end *(CR-004)* —
      `tests/corpus/test_setvariable.py`
- [ ] **T017** [P] Router group order and default marking preserved for
      `rtr_GOOD_BAD_RECORDS` *(CR-005)* — `tests/corpus/test_router_groups.py`
- [ ] **T018** [P] Mapplet port exposure via Input/Output Transformations
      *(CR-006)* — `tests/corpus/test_mapplet_ports.py`
- [ ] **T019** [P] Copybook layouts: `YTD_FILE` yields three layouts; leaf
      offsets, `PICTURE` and redefines match the export —
      `tests/corpus/test_layouts.py`
- [ ] **T019a** [P] Refusal tests: five corrupted-export fixtures, one per
      FR-008 check, each asserting exit 3 **and that no output file was created**
      *(Article II)* — `tests/contract/test_refusal.py`
- [ ] **T019b** [P] Unknown-construct test: a synthetic export with an invented
      transformation type exits 4 *(FR-012)* —
      `tests/contract/test_unknown_construct.py`
- [ ] **T019c** [P] Determinism test: two ingests of an unchanged input produce
      an identical `model_digest` *(Article IX)* —
      `tests/corpus/test_determinism.py`
- [ ] **T019d** [P] Identity tests against `synthetic-identity`: reusable
      transformation yields one definition and n instances with overrides on the
      instance; local shortcut resolves from its defining folder; absent shared
      folder refuses; worklet nesting and variable scope survive to fixture depth
      *(CR-007, CR-008, CR-009)* — `tests/corpus/test_identity_constructs.py`
- [ ] **T019e** [P] Multi-folder and multi-repository inputs: one export with
      several folders, and several exports of one folder, both resolve to correct
      scopes; a conflicting definition across exports refuses *(FR-012b)* —
      `tests/corpus/test_multi_scope.py`
- [ ] **T019f** [P] Version tests: a version inside the verified range parses;
      outside it refuses with exit 6 *(FR-012a)* —
      `tests/contract/test_versions.py`
- [ ] **T019g** [P] Normalizer dispatch: VSAM and pipeline Normalizers are
      distinguished by `ISVSAM_NORMALIZER` *(CR-010)* —
      `tests/corpus/test_normalizer_kinds.py`

## Phase 3.3 — Core implementation

- [ ] **T020** Model dataclasses matching the contract schema —
      `core/parse/model.py`
- [ ] **T021** `POWERMART` reader: folders, mappings, mapping-scoped
      transformations, ports in declared order, connectors, sessions, workflows.
      Carries `attributes_present` alongside `attributes` —
      `core/parse/reader.py`
- [ ] **T022** Construct-registry lookup from 009; record `coverage_tier` and
      `unmet_restrictions` on every construct; T4 unknown → exit 4
      *(FR-012, Article XII)* — `core/parse/registry.py`
- [ ] **T022a** Version-aware parsing: record `REPOSITORY_VERSION`, gate element
      and attribute expectations on it, refuse outside the verified range with
      exit 6 *(FR-012a)* — `core/parse/versions.py`
- [ ] **T023** Provenance derivation, taking `environment` from the declared
      environment map and defaulting to `Unknown` where no entry exists — never
      inferred from a name prefix *(Article IV)* — `core/parse/model.py`
- [ ] **T023a** Scope-accurate identity: three path forms; folder-level reusable
      objects stored once with instance references; `ObjectRef` resolution for
      direct, local-shortcut, global-shortcut and reusable-instance kinds;
      shortcut cycle detection; absent shared folder raises a gap
      *(FR-003, FR-003a)* — `core/parse/identity.py`
- [ ] **T023b** Worklet parsing: arbitrary nesting depth, per-worklet variable
      scope, worklet-scoped task paths *(FR-003b)* — `core/parse/worklets.py`
- [ ] **T023c** Multi-folder and multi-repository input handling *(FR-012b)* —
      `core/parse/reader.py`
- [ ] **T024** [P] Recursive `SOURCEFIELD` → `RecordLayout` with offsets,
      `PICTURE`, usage flags, redefines — `core/parse/layouts.py`
- [ ] **T025** [P] `SESSIONCOMPONENT` extraction: commands, emails, variable
      assignments, script invocation resolution — `core/parse/sessions.py`
- [ ] **T026** [P] Flag detection: `is_stateful` (self-referential local
      variable), `is_passthrough`, `sets_variables`, mapping `shell-only` and
      `dummy-source` — `core/parse/flags.py`
- [ ] **T027** Exact connector edges, no inference — `core/lineage/edges.py`
- [ ] **T028** Transitive origin resolution with `origin_reason` and `method`;
      cycle-safe — `core/lineage/resolve.py`
- [ ] **T029** Cross-folder dependency edges with shared-utility detection
      (≥3 writers) — `core/lineage/deps.py`

## Phase 3.4 — Validation gates

- [ ] **T030** The five FR-008 checks, collecting **all** failures before
      exiting rather than stopping at the first *(Article II)* —
      `core/validate/checks.py`
- [ ] **T031** Atomic emit: write to a temp directory, `fsync`, then rename, so a
      failure leaves no partial model — `core/emit/artifacts.py`
- [ ] **T032** Content digest and `manifest.json`; digest cache for unchanged
      exports — `core/emit/artifacts.py`
- [ ] **T033** Typed gap report covering all twelve gap types;
      `copybook-encoding` raised from `PICTURE`/`usage_flags` inspection,
      `external-code-body` from T3 constructs, `referenced-schema` from XML
      sources, `absent-shared-folder` from unresolved global shortcuts,
      `environment-map` from unmapped repositories *(FR-010, Article VII)* —
      `core/gaps/report.py`
- [ ] **T034** Schema conformance test of emitted records against
      `contracts/canonical-model.schema.json` —
      `tests/contract/test_schema_conformance.py`

## Phase 3.5 — CLI, integration, polish

- [ ] **T040** `mfctl ingest | model get | model flags | lineage | gaps | diff`
      with the documented exit codes — `core/cli.py`
- [ ] **T041** CI regeneration check: reingest and `mfctl diff --exit-on-diff`
      against the committed model digest *(Article IX)* — `.github/workflows/ci.yml`
- [ ] **T042** [P] Performance test: ≥ 400 KB/s single-threaded, ≥ 10× speedup
      on cached re-ingest *(SC-009)* — `tests/corpus/test_performance.py`
- [ ] **T043** [P] `quickstart.md` walked end to end by someone who has not seen
      the code *(SC-007)*
- [ ] **T044** Retire `PowerCenter/tools/` in favour of `core/`, or make it a
      thin shim, and regenerate `PowerCenter/docs/` from `core` to prove
      equivalence — no diff expected

## Dependencies

```
T001 ──> T002,T003,T004,T004a ──> T010..T019g  (all tests, all [P])
                                      │
                                      v
              T020 ──> T021 ──> T022 ──> T022a ──> T023
                                      │
                    ┌─────────────────┼──────────────────┐
                    v                 v                  v
              T023a,T023b,T023c   T024,T025,T026    (all [P])
                                      │
                          T027 ──> T028 ──> T029
                                      │
                    T030 ──> T031 ──> T032 ──> T033 ──> T034
                                      │
                          T040 ──> T041 ──> T042,T043 ──> T044
```

`T030` before `T031` is deliberate: the validator must exist before anything can
be written, so there is never a code path that emits without validating.

## Parallel execution example

```
# after T004a, the whole test suite is independent
T010 T010a T011 T012 T013 T014 T015 T016 T017 T018 T019 T019a T019b T019c \
T019d T019e T019f T019g

# after T023
T023a T023b T023c T024 T025 T026
```

## Definition of done

- [ ] Every FR maps to at least one task
- [ ] Every CR-001..CR-011 has a test against a named conformance corpus
- [ ] Every T1/T2 construct in scope is exercised by `synthetic-core`
- [ ] All tests pass; refusal tests confirm no partial output
- [ ] Constitution Check re-run and passing
- [ ] `plan.md` Verification steps 1–11 executed and output recorded
- [ ] T044 regeneration produces no diff against committed `PowerCenter/docs/`
