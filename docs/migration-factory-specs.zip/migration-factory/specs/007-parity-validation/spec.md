# Feature Specification: Parity Validation

**Feature Branch** `007-parity-validation`
**Created** 2026-09-10 · **Status** Draft
**Input** Prove the generated Spark solution produces the same output as
PowerCenter, at a stated tolerance, for every migrated object.

---

## User Scenarios & Testing

### User Story 1 — Reconcile one target across four dimensions (P1)

The harness compares a generated target against its legacy counterpart on row
count, per-column null and distinct counts, per-column checksums over a
deterministic sort, and a full row diff on a sampled key set. It reports pass or
fail per dimension against the object's approved tolerance.

**Why this priority:** Article VI makes this the definition of done. Nothing
reaches `VALIDATED` without it.

**Independent test:** run against a target with a deliberately corrupted column
and assert the checksum dimension fails while row count passes — the failure mode
that count-only checking misses.

**Acceptance scenarios**

1. **Given** identical legacy and generated output, **When** reconciled, **Then**
   all four dimensions pass and the report records the tolerance applied.
2. **Given** one column differing in one row, **When** reconciled, **Then** the
   checksum dimension fails naming the column, even though row count matches.
3. **Given** a decimal column differing in the second decimal place, **When**
   reconciled, **Then** it fails under exact tolerance.
4. **Given** a failure, **When** reported, **Then** the failing keys and columns
   are named, not just a count.

### User Story 2 — Catch the failures row counts hide (P1)

The harness detects the specific silent-failure modes this estate's patterns
produce: a dead router branch, a stateless accumulator, an inner-joined lookup,
an overwritten merge target.

**Why this priority:** most high-risk patterns fail without changing the primary
target's row count. A harness that only checks the primary target passes all of
them.

**Independent test:** for each of the four failure modes, inject it, run the
harness, and assert the specific dimension that catches it.

**Acceptance scenarios**

1. **Given** a router translated as if/elif so the error branch is dead, **When**
   reconciled, **Then** the secondary target's row count fails while the primary
   passes.
2. **Given** a stateless accumulator, **When** reconciled, **Then** the
   accumulator column's distinct count and checksum fail.
3. **Given** an inner-joined lookup, **When** reconciled, **Then** the primary
   row count fails.
4. **Given** an overwrite where a merge was required, **When** reconciled,
   **Then** rows present in legacy and absent from generated are reported.
5. **Given** any object, **When** reconciled, **Then** **every** target it
   writes is checked, not only the primary.

### User Story 3 — Validate delivered files, not just tables (P1)

For file targets, the harness compares delivered bytes: record count, record
length, field-level values decoded per the copybook, and header/detail/trailer
ordering.

**Why this priority:** the agency deliverables are files, some fixed-width and
mainframe-bound. A Delta table matching proves nothing about what NIH receives.

**Acceptance scenarios**

1. **Given** a fixed-width deliverable, **When** compared, **Then** record count
   and record length are asserted, and each field is decoded and compared per
   the copybook layout.
2. **Given** a concatenated header/detail file, **When** compared, **Then**
   section order is asserted.
3. **Given** a trailer carrying a record count, **When** compared, **Then** the
   trailer count is asserted against the detail count, reproducing the check the
   receiving agency performs.
4. **Given** a delivered filename, **When** compared, **Then** the resolved
   filename matches the legacy convention exactly *(P-16, P-17)*.

### User Story 4 — Diff lineage, not only data (P2)

The harness compares Unity Catalog column-level lineage against the lineage
extracted from PowerCenter, reporting columns whose upstream set differs.

**Why this priority:** data parity on one pay period can pass while a rule is
wrong for a case that period does not exercise. Lineage divergence catches
structural error that sampled data cannot.

**Acceptance scenarios**

1. **Given** a migrated object, **When** lineage is diffed, **Then** columns
   whose upstream sets differ from `source-to-target.csv` are reported.
2. **Given** an intentional difference, **When** recorded with a justification,
   **Then** it is suppressed in later runs with the justification attached.

### User Story 5 — Support a dual-run window (P2)

Both systems run in parallel for an agreed number of cycles, with reconciliation
each cycle and a trend report.

**Why this priority:** these are biweekly payroll cycles. Correctness on one
cycle is not correctness across year-end, retroactive adjustments, or leap pay
periods.

**Acceptance scenarios**

1. **Given** a dual-run window, **When** each cycle completes, **Then** a report
   is produced and appended to the object's history.
2. **Given** a cycle failing after earlier passes, **When** reported, **Then**
   what changed since the last passing cycle is identified.
3. **Given** a completed window with all cycles passing, **When** cutover is
   requested, **Then** the window evidence is attached to the approval.

### User Story 6 — Explain a mismatch (P2)

The validation analyst agent diagnoses each mismatch, proposes a root cause, and
must reproduce the observed difference for the diagnosis to be accepted.

**Acceptance scenarios**

1. **Given** a mismatch, **When** diagnosed, **Then** the proposal names the
   transformation and pattern implicated.
2. **Given** a diagnosis, **When** verified, **Then** it is accepted only if it
   reproduces the observed diff; otherwise it is rejected and retried
   *(Article I)*.

---

## Requirements

### Functional

- **FR-001** The harness MUST compare on all four dimensions: row count,
  per-column null and distinct counts, per-column checksum over a deterministic
  sort of the business key, and a full row diff on a sampled key set
  *(Article VI)*.
- **FR-002** The harness MUST check **every** target an object writes, including
  error and counter tables.
- **FR-003** Sample size for the row diff MUST be recorded with its justification;
  a default MUST be stated in the plan, not chosen at run time.
- **FR-004** Decimal comparison MUST be exact unless a tolerance is approved;
  floating-point comparison of decimal columns is prohibited.
- **FR-005** For file targets, the harness MUST compare record count, record
  length, copybook-decoded field values, section ordering, trailer counts, and
  the resolved filename.
- **FR-006** The harness MUST diff Unity Catalog column-level lineage against the
  PowerCenter-derived lineage and report divergences.
- **FR-007** Results MUST be reported per dimension with pass/fail against the
  approved tolerance, and MUST name failing keys and columns.
- **FR-008** A parity report MUST be a precondition on `TESTED` → `VALIDATED`,
  enforced by the ledger *(003 FR-005)*.
- **FR-009** The harness MUST support a dual-run window with per-cycle reports
  and a trend view.
- **FR-010** An agent diagnosis MUST be accepted only if it reproduces the
  observed diff.
- **FR-011** The harness MUST be deterministic and re-runnable; the same inputs
  MUST produce the same report.
- **FR-012** The harness MUST NOT modify either system's data.

### Conformance requirements

Each maps to a silent-failure mode of a specific construct *(Article XI)*.

- **CR-001** The harness MUST detect a dead Router branch by checking secondary
  targets. *Evidence:* a reference-corpus router sends error rows to both the
  primary target and an error table.
- **CR-002** The harness MUST validate trailer record counts where a mapping
  produces one. *Evidence:* a reference-corpus aggregator builds a count trailer
  the receiving system reconciles against.
- **CR-003** The harness MUST validate resolved output filenames, not only file
  contents. *Evidence:* reference-corpus filenames are assembled from persisted
  mapping variables.
- **CR-004** The harness MUST decode signed and implied-decimal `PICTURE` fields
  rather than comparing raw bytes. *Evidence:* `+9(3)V9(2)` with
  `TRAILING_SIGN` in the reference corpus.
- **CR-005** The harness MUST detect a stateless translation of a stateful port
  via the accumulator column's distinct count and checksum *(P-02)*.
- **CR-006** The harness MUST detect a positional Union by comparing per-column
  values, since schema and row count are unchanged *(P-22)*.
- **CR-007** The harness MUST detect a `rank`-for-`row_number` substitution via
  per-group row counts *(P-23)*.
- **CR-008** The harness MUST detect a skipped-versus-empty task by comparing
  job status, not only output rows *(P-28)*.
- **CR-009** The harness MUST detect lost Transaction Control commit boundaries
  by comparing output partition or file counts *(P-24)*.
- **CR-010** For an object in `MANUAL_PORT`, the harness MUST validate the
  object as a whole; a passing contract test is necessary and not sufficient.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Read access to the legacy databases and delivered files for comparison | access | yes | PowerCenter administration |
| Business key per target, for deterministic sort and sampling | business-key | yes | PowerCenter SME |
| Dual-run window length per feed | governance | yes | Migration lead |
| Reference legacy output for constructs the corpus cannot produce on demand | access | no | PowerCenter administration |
| Whether a legacy behaviour is a bug to reproduce or fix | domain-knowledge | yes per case | PowerCenter SME |

### Key entities

- **ParityReport** — per object per run. Dimension results, tolerance applied,
  failing keys, provenance.
- **DimensionResult** — dimension, pass/fail, observed vs expected, detail.
- **FileParityResult** — record counts, lengths, decoded field diffs, ordering,
  trailer check, filename check.
- **LineageDiff** — per column, legacy upstream set vs Unity Catalog set.
- **DualRunCycle** — one cycle's report within a window.
- **Diagnosis** — proposed root cause with its reproduction evidence.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** For every silent-failure mode in CR-001..CR-009, injecting it
  causes the harness to fail on the expected dimension. Zero false passes across
  the whole mode set.
- **SC-002** Every target of every migrated object is checked, including error,
  audit and counter tables; a coverage query returns zero unchecked targets.
- **SC-003** Zero decimal comparisons performed in floating point.
- **SC-004** Every file deliverable is validated on all six file dimensions.
- **SC-005** No object reaches `VALIDATED` without a passing report at its
  approved tolerance; zero exceptions.
- **SC-006** Re-running a reconciliation on unchanged inputs produces an
  identical report.
- **SC-007** Every accepted diagnosis reproduces its observed diff.
- **SC-008** Every object in `MANUAL_PORT` is validated as a whole, not solely
  by its contract test; a query returns zero exceptions.

---

## Edge Cases

- **Legacy output unavailable for a past cycle.** The object cannot be validated;
  it stays at `TESTED` with an `access` gap. It is not passed on partial
  evidence.
- **Legacy behaviour non-deterministic** (`Use Any Value` multi-match). Exact
  parity is impossible; the tie-break decided at plan time is what is validated,
  and the non-determinism is recorded on the report.
- **Both systems wrong in the same way.** Parity passes. This is intended —
  parity proves equivalence, not correctness — and the harness states it, so a
  passing report is never read as a correctness certificate.
- **Row present in both with a different key.** Reported as key mismatch, not as
  insert plus delete.
- **Empty legacy target for the cycle.** Passes only if the generated target is
  also empty, and the report flags the comparison as vacuous.

## Assumptions

- A business key exists per target sufficient for deterministic sorting and
  sampling. Where it does not, that is a blocking gap, not a reason to compare
  unsorted.

## Dependencies

- **Upstream** 001 (copybook layouts, target definitions, lineage), 005
  (tolerance, business key), 006 (generated code), 003 (ledger)
- **Downstream** 003 gates `VALIDATED` and `CUTOVER` on these reports.

---

## Review & Acceptance Checklist

- [x] No implementation detail
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)* — FR-010, and no partial passes
- [x] Provenance requirements stated *(Article IV)*
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] Manual-port objects validated as wholes *(Article XII)* — CR-010
- [x] Human-approval boundaries identified *(Article VIII)* — tolerance
      overrides, dual-run sign-off
- [x] All `[NEEDS CLARIFICATION]` resolved
