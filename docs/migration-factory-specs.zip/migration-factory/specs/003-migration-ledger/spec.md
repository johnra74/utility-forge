# Feature Specification: Migration Ledger

**Feature Branch** `003-migration-ledger`
**Created** 2026-09-10 · **Status** Draft
**Input** The system of record for migration state, provenance, approvals and
gaps, for every object in the estate.

---

## User Scenarios & Testing

### User Story 1 — Track every object through the lifecycle (P1)

Every migratable object in the repository — each mapping and each workflow — has
a ledger row recording its current state, how it got there, and what evidence
justified each transition.

**Why this priority:** without it there is no answer to "where are we", no gate
enforcement, and no audit trail. Every other feature writes here.

**Independent test:** seed from any canonical model, assert one row per mapping
and per workflow in `DISCOVERED`, then drive one object to `APPROVED` and read
back its full transition history.

**Acceptance scenarios**

1. **Given** a canonical model, **When** the ledger is seeded, **Then** one row
   exists per mapping and per workflow, keyed by fully qualified path
   *(Article III)*.
2. **Given** an object in `ANALYSED`, **When** a transition to `PLANNED` is
   recorded, **Then** the event carries actor, timestamp, evidence pointer and
   artifact digest.
3. **Given** any object, **When** its history is queried, **Then** every
   transition since discovery is returned in order, with nothing deleted.
4. **Given** an attempt to transition along an edge the state machine does not
   define, **When** submitted, **Then** it is rejected and the current state is
   unchanged.

### User Story 2 — Enforce gates rather than record them (P1)

The ledger refuses transitions whose preconditions are unmet: no `APPROVED`
without a human approval, no `VALIDATED` without a passing parity report, no
movement out of `BLOCKED` while a blocking gap is unresolved.

**Why this priority:** a ledger that only records is a report. Constitution
Articles VI and VIII are only real if something enforces them, and enforcement
has to live where the state does.

**Independent test:** attempt each forbidden transition programmatically and
assert rejection with the article cited.

**Acceptance scenarios**

1. **Given** an object in `PLANNED` with no human approval, **When** an agent
   attempts `APPROVED`, **Then** it is rejected citing Article VIII.
2. **Given** an object in `TESTED` with a failing parity report, **When**
   `VALIDATED` is attempted, **Then** it is rejected citing Article VI.
3. **Given** an object with an unresolved blocking gap, **When** `PLANNED` is
   attempted, **Then** it is rejected citing Article VII.
4. **Given** a parity tolerance override, **When** recorded, **Then** a named
   human approver is required and the override is visible on the object forever.

### User Story 3 — Record approvals durably (P1)

A human approves a migration plan or a cutover. The approval is recorded with
identity, timestamp, the exact artifact digest approved, and any conditions.

**Why this priority:** in a government migration the approval record *is* the
deliverable when someone asks who authorised a change to a payroll feed.

**Acceptance scenarios**

1. **Given** an approval request, **When** a human approves, **Then** the
   recorded digest matches the artifact reviewed, so a later edit is detectable.
2. **Given** an approved plan that is subsequently regenerated with a different
   digest, **When** the object attempts `GENERATED`, **Then** it is rejected as
   approval-stale.
3. **Given** any approval, **When** queried, **Then** approver, timestamp and
   conditions are returned. Agents can never appear as approvers.

### User Story 4 — Manage gaps to closure (P2)

Gaps discovered by ingestion or by an agent are tracked with owner and blocking
status, and resolving one requires attaching evidence.

**Acceptance scenarios**

1. **Given** a gap of type `parameter-file`, **When** resolved, **Then**
   evidence is required and the objects it blocked become eligible to proceed.
2. **Given** a gap resolved without evidence, **When** submitted, **Then** it is
   rejected.
3. **Given** a resolved gap, **When** the corpus is re-ingested and the gap
   recurs, **Then** it reopens rather than being silently re-created.

### User Story 5 — Report progress and residual risk (P2)

Coverage and burndown by wave, workflow and environment, plus the list of
objects whose only evidence is a Test-repository export.

**Why this priority:** seven of eleven exports are Test copies. A burndown that
counts those as done overstates progress in a way that only surfaces at cutover.

**Acceptance scenarios**

1. **Given** the ledger, **When** the report runs, **Then** counts by state and
   by wave are returned, with Test-provenance objects listed separately.
2. **Given** an object at `CUTOVER` whose evidence is a Test export, **When**
   the report runs, **Then** it is flagged as a provenance exception.

### User Story 6 — Reconstruct history for audit (P3)

An auditor asks why an object was migrated a particular way. The ledger returns
the full chain: model digest, analysis, plan, approver, generated artifact
digest, parity report, cutover approval.

**Acceptance scenarios**

1. **Given** any object at any state, **When** its audit trail is requested,
   **Then** every artifact digest and every actor in its history is returned.
2. **Given** a corpus re-ingestion that changed the object, **When** the trail is
   requested, **Then** both model versions appear with the transitions made
   under each.

---

## Requirements

### Functional

- **FR-001** The ledger MUST hold one row per migratable object, keyed by fully
  qualified path *(Article III)*.
- **FR-002** The ledger MUST implement the thirteen-state machine —
  `DISCOVERED`, `SCOPED`, `OUT_OF_SCOPE`, `ANALYSED`, `BLOCKED`, `PLANNED`,
  `APPROVED`, `GENERATED`, `MANUAL_PORT`, `TESTED`, `VALIDATED`, `CUTOVER`,
  `DECOMMISSIONED` — and MUST reject any transition not defined by it.
- **FR-002a** The ledger MUST refuse `DISCOVERED` → `SCOPED` while any construct
  in the object has no declared coverage tier, and MUST place an object
  containing a T4 construct in `OUT_OF_SCOPE` *(Article XII)*.
- **FR-002b** The ledger MUST track an object in `MANUAL_PORT` — partly
  generated, partly hand-written against an emitted contract — and MUST require
  it to reach parity like any other object *(Article VI)*.
- **FR-003** Transitions MUST be append-only events carrying actor, actor type
  (human or agent), timestamp, evidence pointer, and artifact digest. History
  MUST NOT be mutable or deletable.
- **FR-004** The ledger MUST refuse `PLANNED` → `APPROVED` and `VALIDATED` →
  `CUTOVER` without a human approval *(Article VIII)*, and MUST reject any
  approval whose actor type is agent.
- **FR-005** The ledger MUST refuse `TESTED` → `VALIDATED` without a parity
  report meeting the object's stated tolerance *(Article VI)*.
- **FR-006** The ledger MUST refuse to move an object out of `BLOCKED`, or into
  `PLANNED`, while a blocking gap remains unresolved *(Article VII)*.
- **FR-007** Backward transitions MUST require human approval and MUST preserve
  all prior history.
- **FR-008** The ledger MUST record the model digest in force for each
  transition, so a re-ingestion that changes an object is detectable
  *(Article IV)*.
- **FR-009** The ledger MUST reject a transition whose approved artifact digest
  no longer matches the current artifact (approval staleness).
- **FR-010** The ledger MUST track gaps with type, owner, blocking status and
  blocked objects, and MUST require evidence to resolve one.
- **FR-011** The ledger MUST record parity tolerance overrides with a named human
  approver, and MUST surface them permanently on the object.
- **FR-012** The ledger MUST expose coverage and burndown by wave, workflow and
  environment, reporting Test-provenance objects separately.
- **FR-013** The ledger MUST be readable and writable by the orchestrator (008)
  through an API, and MUST NOT be written by agents directly — every write passes
  a precondition check.

### Conformance requirements

- **CR-001** Seeding MUST produce exactly one row per mapping and one per
  workflow in the input. Mapplets, reusable transformations and worklets are
  tracked as dependencies of their consumers, not as independently migratable
  objects. *Evidence:* the reference corpus seeds 119 rows from 108 mappings and
  11 workflows.
- **CR-002** Objects whose environment is not production MUST be excluded from
  any "ready for cutover" count until a production export replaces them, and
  `environment = Unknown` MUST be treated as not-production. *Evidence:* seven
  of eleven reference-corpus exports are non-production.
- **CR-003** Every gap class emitted by 001 MUST be seedable with its
  blocked-object set, without the ledger enumerating gap types itself — the type
  list belongs to 001.
- **CR-004** An object containing a T3 construct MUST be routable to
  `MANUAL_PORT` and MUST NOT be markable complete on generated code alone.
- **CR-005** State and gap semantics MUST be independent of repository size; the
  ledger MUST hold at least 10,000 objects without a change of design.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Identity source for human approvers (SSO, directory) | integration | yes | Platform engineering |
| Records-retention policy for ledger history in the customer's jurisdiction | governance | yes | Records management |
| Authoritative wave assignment, pending the external orchestration gap | external-orchestration | no | Operations |
| Whether a T3 manual port is in scope for the engagement or handed back | governance | yes | Migration lead |

### Key entities

- **LedgerObject** — one migratable object. Identity: fully qualified path.
  Current state, wave, environment, tolerance, flags.
- **Transition** — append-only state change event.
- **Approval** — human decision on a specific artifact digest.
- **GapRecord** — the ledger's mutable view of a gap, with resolution evidence.
- **ParityReport** — reference to a 007 result, with pass/fail per dimension.
- **ArtifactRef** — digest plus location for an analysis, plan, generated module
  or parity report.

---

## Success Criteria

Stated as invariants *(Article XI)*.

- **SC-001** Seeding from any canonical model yields exactly one object per
  mapping and per workflow, all in `DISCOVERED`, with zero omissions and zero
  duplicates.
- **SC-002** Every forbidden transition in a table of 20 negative cases is
  rejected, each citing the article it enforces.
- **SC-003** No object reaches `APPROVED` or `CUTOVER` without a human approval
  row; verified by a query returning zero exceptions.
- **SC-004** No object reaches `VALIDATED` without a passing parity report;
  verified by a query returning zero exceptions.
- **SC-005** For any object, the full audit trail is retrievable in one query and
  contains every artifact digest in its history.
- **SC-006** Burndown reports non-production-provenance objects separately, and
  a `CUTOVER` object with non-production provenance is flagged.
- **SC-008** No object leaves `DISCOVERED` while any construct in it lacks a
  declared tier; a query returns zero exceptions.
- **SC-009** No object reaches `VALIDATED` from `MANUAL_PORT` without both the
  contract test and the parity report passing.
- **SC-010** The ledger sustains 10,000 objects with audit-trail retrieval for
  any single object in under one second.
- **SC-007** History is provably append-only: an attempt to update or delete a
  transition row fails at the storage layer, not only in application code.

---

## Edge Cases

- **Object disappears from a re-export.** Retained with a `withdrawn` marker and
  its history; never deleted.
- **Object appears in both a Test and a Production export.** One row; provenance
  records both, and the production export takes precedence for cutover
  eligibility.
- **Gap resolved, then reopened by re-ingestion.** Reopens the same gap record
  with both resolution attempts visible.
- **Approver leaves the organisation.** Approval remains valid and attributed;
  identity records are not rewritten.
- **Two agents transition the same object concurrently.** Optimistic concurrency
  on the expected current state; the loser is rejected, not merged.

## Assumptions

- Human identity comes from an external directory. Until that integration
  exists, approvals are recorded against a named account and the gap stays open —
  the ledger does not invent an approver.

## Dependencies

- **Upstream** 001 (seeding, gaps, dependency graph for waves)
- **Downstream** 004–008 all read and request writes; 008 owns every write.

---

## Review & Acceptance Checklist

- [x] No implementation detail
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)*
- [x] Provenance requirements stated *(Article IV)*
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] Coverage gating wired into the state machine *(Article XII)* — FR-002a
- [x] Human-approval boundaries identified *(Article VIII)* — FR-004, FR-007,
      FR-011
- [x] All `[NEEDS CLARIFICATION]` resolved
