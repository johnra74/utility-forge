# Feature Specification: Migration Planning

**Feature Branch** `005-migration-planning`
**Created** 2026-09-10 · **Status** Draft
**Input** Turn a verified analysis into an approvable migration plan: target
design, pattern selection, wave assignment, parity tolerance.

---

## User Scenarios & Testing

### User Story 1 — Produce an approvable plan for one object (P1)

The architect agent takes an object's analysis and produces a plan naming the
target Delta tables and their layout, the catalog pattern chosen for each
transformation, the merge key where one is needed, the parity tolerance, and the
prerequisites. A human approves or rejects the plan as a whole.

**Why this priority:** the plan is what a human approves, and approval is the
gate that everything downstream depends on.

**Independent test:** plan `m_Pseudossn_Update_Timekeeper_Number` and assert the
plan names a `MERGE INTO` on a stated merge key, pattern
[P-11](../../docs/pattern-catalog.md#p-11-update-strategy), and refuses to
proceed while the merge key is unconfirmed.

**Acceptance scenarios**

1. **Given** a verified analysis, **When** planning runs, **Then** the plan names
   a pattern id for every transformation in the object.
2. **Given** an Update Strategy transformation with no confirmed merge key,
   **When** planning runs, **Then** the plan records a `business-key` gap and the
   object cannot reach `APPROVED` *(Article VII)*.
3. **Given** a plan referencing a table that does not exist in the target
   design, **When** verified, **Then** it is rejected.
4. **Given** an approved plan that is later regenerated differently, **When**
   codegen is attempted, **Then** it is rejected as approval-stale
   *(003 FR-009)*.

### User Story 2 — Derive wave assignment from the dependency graph (P1)

Wave assignment is computed from the producer/consumer graph, not chosen. The
architect may explain or contest an assignment; it cannot invent one.

**Why this priority:** ordering errors mean reading half-built tables. The
dependency graph already computed from the corpus is the authority.

**Independent test:** assert `wf_Pay_Calendar` precedes all ten others,
`wf_CPM` precedes the four agency extracts, and `wf_Pseudossn` precedes CPM, LES
and FDA.

**Acceptance scenarios**

1. **Given** the dependency graph, **When** waves are computed, **Then** every
   consumer is in a strictly later wave than its producer.
2. **Given** shared-utility objects written by three or more workflows
   (`ERROR_TBL`, `COUNTER_TBL`, the generic dummy pair), **When** waves are
   computed, **Then** they do not constrain ordering.
3. **Given** an agent proposal that violates the graph, **When** verified,
   **Then** it is rejected naming the violated edge.
4. **Given** the external-orchestration gap is unresolved, **When** waves are
   reported, **Then** they are labelled a lower bound on constraints, not a
   schedule.

### User Story 3 — Design the target tables (P1)

The plan specifies each target's Delta table: catalog and schema placement,
column names and types derived from the PowerCenter target definition,
partitioning, and whether it is managed or external.

**Why this priority:** types are where silent damage happens. A `decimal(18,2)`
payroll amount landing as a double is a correctness defect that no row count
detects.

**Acceptance scenarios**

1. **Given** a target with decimal columns, **When** designed, **Then** every one
   maps to `DecimalType` with the original precision and scale.
2. **Given** a 534-column target, **When** designed, **Then** all 534 columns
   appear with types, and none is dropped or renamed silently.
3. **Given** a partitioning proposal, **When** verified, **Then** the partition
   columns exist in the target and the rationale is recorded.

### User Story 4 — Propose parity tolerance with justification (P2)

The plan proposes a tolerance per parity dimension, with a reason. A human
approves it. The default is exact equality.

**Why this priority:** Article VI makes parity the definition of done, so the
tolerance is a substantive decision, not a configuration detail.

**Acceptance scenarios**

1. **Given** a target with no floating-point columns, **When** tolerance is
   proposed, **Then** it is exact equality on all dimensions.
2. **Given** a proposed non-exact tolerance, **When** submitted, **Then** it
   requires a justification and a named human approver *(003 FR-011)*.
3. **Given** a target whose PowerCenter behaviour is non-deterministic — a
   `Use Any Value` lookup with a possible multi-match — **When** tolerance is
   proposed, **Then** the non-determinism is named and a tie-break is required
   before approval.

### User Story 5 — Plan the layers mappings do not contain (P1)

The plan covers session shell steps, parameter replacement, variable
propagation, and mainframe delivery as explicit target-side steps.

**Why this priority:** a plan that covers only mapping logic generates a job that
runs green and delivers nothing.

**Acceptance scenarios**

1. **Given** a shell-only mapping, **When** planned, **Then** the plan specifies
   the target-side task replacing the shell command, not a no-op transform.
2. **Given** a `$Param_*` reference, **When** planned, **Then** the plan names
   its replacement mechanism and the parameter remains blocking until supplied.
3. **Given** a `PWX_SEQ_NRDB2` target, **When** planned, **Then** the plan
   requires a per-target ADR and cannot reach `APPROVED` without one.

### User Story 6 — Plan a manual port for a T3 construct (P1)

For an object containing a declared-unsupported construct, the plan specifies
what is generated, what must be hand-written, and the contract between them.

**Why this priority:** Stored Procedure, Java, External Procedure, Custom and
adapter transformations reference logic the repository does not contain. Refusing
the whole object wastes the 90% that is convertible; guessing the missing 10% is
worse than either.

**Independent test:** plan a mapping containing a Stored Procedure and assert the
plan names the generated pipeline, the manual-port boundary, the required
function signature and types, and the contract test that will hold it.

**Acceptance scenarios**

1. **Given** a mapping with a T3 construct, **When** planned, **Then** the plan
   partitions the object into generated and hand-written parts with an explicit
   interface between them.
2. **Given** a T3 construct, **When** planned, **Then** the plan MUST NOT
   propose an inferred implementation, however plausible.
3. **Given** a manual-port plan, **When** approved, **Then** the object is
   routed to `MANUAL_PORT` and must still reach parity.
4. **Given** an object whose T3 share exceeds a configured threshold, **When**
   planned, **Then** the plan recommends hand-migration of the whole object and
   says why.

### User Story 7 — Emit a Spec Kit feature per wave (P3)

Each wave produces its own `specs/###-wave-N-.../` artifacts, so the migration
itself is driven by the same spec-driven workflow as the factory.

**Acceptance scenarios**

1. **Given** an approved wave, **When** artifacts are emitted, **Then** a
   `spec.md`, `plan.md` and `tasks.md` exist naming the objects in that wave.
2. **Given** the emitted `plan.md`, **When** the Constitution Check is run,
   **Then** every article has a verdict.

---

## Requirements

### Functional

- **FR-001** Every transformation in a plan MUST be assigned a catalog pattern id
  that exists in `docs/pattern-catalog.md`, and whose counter-example test
  passes *(Article V)*.
- **FR-002** Wave assignment MUST be computed from the dependency graph; agent
  proposals violating it MUST be rejected naming the violated edge.
- **FR-003** Shared-utility objects (≥3 writing workflows) MUST NOT constrain
  wave ordering.
- **FR-004** Target column types MUST preserve PowerCenter precision and scale;
  substituting a floating type for a decimal MUST be rejected.
- **FR-005** No column may be dropped or renamed without an explicit, recorded
  decision.
- **FR-006** A plan MUST specify a merge key for every Update Strategy target,
  and MUST record a blocking `business-key` gap until the key is SME-confirmed.
- **FR-006a** A plan for an object containing a T3 construct MUST partition it
  into generated and hand-written parts and MUST specify the interface contract.
  It MUST NOT propose an inferred implementation *(Article XII)*.
- **FR-006b** A plan MUST NOT be produced for an object in `OUT_OF_SCOPE`;
  coverage must be extended first.
- **FR-007** Parity tolerance MUST default to exact equality; any relaxation
  MUST carry a justification and require human approval.
- **FR-008** A plan MUST cover session shell steps, `$Param_*` replacement,
  variable propagation, and mainframe delivery as explicit target-side steps.
- **FR-009** A plan MUST NOT reach `APPROVED` while any blocking gap on its
  object is unresolved *(Article VII)*.
- **FR-010** A plan for an object whose only evidence is a Test export MUST list
  production re-export as a prerequisite *(Article IV)*.
- **FR-011** Plans MUST be digest-addressed so approval staleness is detectable.
- **FR-012** The system MUST emit Spec Kit artifacts per wave, populated from
  `.specify/templates/`.
- **FR-013** Human approval MUST be requested for the plan as a whole; partial
  approval is not supported *(Article VIII)*.

### Conformance requirements

- **CR-001** Wave 0 MUST exist and MUST contain exactly those cross-cutting
  prerequisites the coverage report shows the repository needs. Universal
  members are the target layout and the parity harness; conditional members —
  copybook decoding, an XSD registry, a sequence-state store, parameter
  replacement — are included only where the corresponding construct is present.
- **CR-002** Wave order MUST satisfy every dependency edge, for any dependency
  graph. *Evidence:* in the reference corpus this places `wf_Pay_Calendar`
  first and `wf_CPM`, `wf_Pseudossn` before their consumers.
- **CR-003** Every Update Strategy target MUST carry a blocking `business-key`
  gap until its merge key is SME-confirmed.
- **CR-004** Every T3 construct MUST produce a manual-port plan with an explicit
  interface contract; every T2 construct with an unmet restriction MUST block.
- **CR-005** Every PowerExchange non-relational target MUST require a per-target
  decision recorded as an ADR.
- **CR-006** Planning MUST handle a repository with no cross-workflow
  dependencies (a single wave) and one that is fully chained (n waves) without
  special-casing either.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Unity Catalog catalog/schema/grant layout | governance | yes | Data governance |
| Merge keys for every Update Strategy target | business-key | yes | PowerCenter SME |
| Per-target decision for each PowerExchange non-relational target | mainframe | yes | Mainframe operations |
| Ownership of each manual port: converter team or customer | governance | yes | Migration lead |
| Tie-break for `Use Any Value` lookups that can multi-match | semantics-unconfirmed | yes | PowerCenter SME |
| Dual-run window length per feed before decommissioning | governance | yes | Migration lead |

### Key entities

- **MigrationPlan** — per object, digest-addressed. Target design, pattern
  assignments, merge key, tolerance, prerequisites, wave.
- **TargetTableDesign** — Delta table: placement, columns with types,
  partitioning, managed/external.
- **PatternAssignment** — transformation path → catalog pattern id, with the
  parameters that pattern needs (e.g. window spec for P-02).
- **WaveAssignment** — computed wave with the graph edges that determined it.
- **ToleranceSpec** — per parity dimension, with justification and approver.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** Every object not in `OUT_OF_SCOPE` has a plan naming a pattern for
  every transformation, with zero dangling pattern ids.
- **SC-002** Wave assignment satisfies every dependency edge; a verification
  query returns zero violations, for any dependency graph.
- **SC-003** Every decimal column in every target design is `DecimalType` with
  the original precision and scale; zero floating substitutions, for any input.
- **SC-004** Column counts and column names in target designs match the
  PowerCenter target definitions exactly for every target; zero silent drops or
  renames.
- **SC-005** No plan reaches `APPROVED` with an unresolved blocking gap or an
  unmet T2 restriction; zero exceptions.
- **SC-006** Every non-exact tolerance has a justification and a named approver.
- **SC-007** Each wave has emitted Spec Kit artifacts with a completed
  Constitution Check.
- **SC-008** Every T3 construct in the input has a manual-port plan with a
  complete interface contract; zero inferred implementations.

---

## Edge Cases

- **Cyclic dependency between workflows.** Reported, with an SME decision on
  ordering required; never broken arbitrarily. *Evidence:* the reference corpus
  contains one such cycle via a shared cycle-control table.
- **Object in an equivalence group.** Planned once for the group, with member
  differences recorded; each member's ledger row references the shared plan.
- **Pattern exists but its counter-example test is failing.** Planning is
  blocked for that pattern *(Article V)*.
- **Target with no key columns at all.** Merge is impossible; the plan must
  propose a key and it becomes a blocking gap.
- **Plan rejected by the approver.** Rejection and reason are recorded; the
  object returns to `ANALYSED`, history retained.

## Assumptions

- The dependency graph derived from the corpus is a correct lower bound on
  ordering constraints. It may be incomplete, because ten of eleven workflows are
  externally triggered — hence FR-002 computes from it while the
  external-orchestration gap stays open.

## Dependencies

- **Upstream** 001 (dependency graph, target definitions), 004 (analyses), 003
  (ledger), `docs/pattern-catalog.md`, `.specify/templates/`
- **Downstream** 006 generates from approved plans; 007 uses the tolerance.

---

## Review & Acceptance Checklist

- [x] No implementation detail
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)* — FR-002, FR-004, FR-009
- [x] Provenance requirements stated *(Article IV)* — FR-010
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] T3 manual-port planning specified *(Article XII)* — FR-006a
- [x] Human-approval boundaries identified *(Article VIII)* — FR-007, FR-013
- [x] All `[NEEDS CLARIFICATION]` resolved
