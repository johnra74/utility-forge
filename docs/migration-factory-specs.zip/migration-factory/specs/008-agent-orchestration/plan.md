# Implementation Plan: Agent Orchestration

**Branch** `008-agent-orchestration` · **Date** 2026-09-10 · **Spec** [spec.md](spec.md)

## Summary

Temporal owns the per-object and per-wave lifecycle; LangGraph owns the
reasoning loop inside a single agent step. Every agent output passes a
deterministic verifier before any ledger write, which is the mechanism that
makes Constitution Article I enforceable rather than aspirational. Human
approvals are Temporal signals, so they survive restarts and can wait
indefinitely.

## Technical Context

| | |
| --- | --- |
| Language / version | Python 3.11 |
| Primary dependencies | `temporalio` SDK, `langgraph`, `anthropic` SDK, Pydantic v2 |
| Storage | Temporal's own persistence for execution history; Postgres for the ledger (003); artifacts digest-addressed on object storage |
| Testing | `temporalio.testing` time-skipping test environment; recorded agent outputs as fixtures |
| Target platform | Temporal cluster (self-hosted or Cloud) + Python workers |
| Project type | Long-running service |
| Performance target | A wave of 17 objects within the concurrency limit; per-object latency dominated by model and Databricks calls, not orchestration |
| Constraints | Workflow code MUST be deterministic — every model call, platform call and generator run lives in an activity. No direct ledger writes from agents. |
| Scale | Capacity target 10,000 objects across an arbitrary number of waves, ~6 agent steps per object |
| Constructs in scope | Orchestration is construct-agnostic; it routes on coverage tier, not on construct |
| Conformance corpora | All; the coverage step runs before any agent step |

## Constitution Check

*Gate: passed before Phase 0. Re-checked after Phase 1.*

| Article | Check | Pass | Notes |
| --- | --- | --- | --- |
| I — Deterministic core | Agents receive model records only; every output verified before use | ✅ | The verifier is this feature's core contribution; T020–T024 |
| II — Fail loudly | Retry exhaustion blocks the object; no step proceeds on unverified output | ✅ | T025 |
| III — Scoped identity | Workflow id is the fully qualified object path plus attempt | ✅ | Gives one-execution-per-object for free |
| IV — Provenance | Every transition records actor, actor type, model digest, artifact digest | ✅ | T030 |
| V — Semantics first | Pattern verification delegated to 006's catalog precondition | ✅ | |
| VI — Parity | `VALIDATED` gate delegated to the ledger; orchestrator supplies the report | ✅ | |
| VII — Gaps | Blocked objects halt themselves and their dependents | ✅ | T027 |
| VIII — Human approval | Approvals are durable signals; actor type agent is rejected | ✅ | T028, T029 |
| IX — Regenerable | Replay returns recorded outputs; deterministic steps reproduce | ✅ | T032 |
| X — Readable | Not directly applicable; inherited from 006 | ✅ | |
| XI — Corpus independence | SCs are invariants over any input; capacity stated as a target | ✅ | CR-005 |
| XII — Declared coverage | Coverage computed before any agent spend; T4 routes to OUT_OF_SCOPE | ✅ | FR-001a, T020a |

**Post-Phase-1 re-check:** passed. One design consequence worth recording: the
reasoning loop is deliberately *inside* one activity (FR-013), which trades some
step-level observability for an audit history that stays legible. Loop iterations
are logged within the activity rather than becoming separate history events.

## Project Structure

### Artifacts produced by this plan

```
specs/008-agent-orchestration/
├── plan.md
├── research.md
├── data-model.md
├── contracts/
│   ├── verification-rules.md      # the rule set per agent output type
│   └── signals.md                 # approval and control signal contracts
├── quickstart.md
└── tasks.md
```

### Source layout

```
migration-factory/orchestration/
├── workflows/
│   ├── object.py         # ObjectMigrationWorkflow — the thirteen-state lifecycle
│   ├── wave.py           # WaveWorkflow — child executions, concurrency limit
│   └── foundation.py     # Wave 0 — cross-cutting prerequisites, different shape
├── activities/
│   ├── core.py           # parse, compile, emit, parity — deterministic
│   ├── agents.py         # one activity per agent step, containing its graph
│   ├── verify.py         # deterministic verification of agent output
│   ├── ledger.py         # the only path that writes the ledger
│   └── platform.py       # Databricks job submission and polling
├── signals.py            # approval, rejection, pause, resume, budget override
├── budget.py             # per-object and per-wave cost accounting
└── worker.py

migration-factory/agents/
├── analyst/              # 004 — graph, prompts, output schema
├── architect/            # 005
├── codegen/              # 006 — naming and prose only
├── validator/            # 007 — diagnosis
└── reviewer/             # constitution verdicts
```

## Phase 0 — Research

- [ ] **R1** Verification rule set per output type. What is mechanically
      checkable for an analysis, a plan, a diagnosis? This is the crux of the
      feature — a weak rule set makes Article I decorative.
- [ ] **R2** Retry policy per step, and the escalation path on exhaustion.
      Distinguish a wrong agent from a wrong verifier: repeated rejection of
      valid output must surface the verifier's findings, since the fix may be
      there.
- [ ] **R3** Approval identity integration and role mapping. Blocking gap until
      resolved; the ledger must not invent an approver.
- [ ] **R4** Cost accounting: token attribution per step, and where the budget
      check sits so a pause leaves resumable state.
- [ ] **R5** Replay strategy for agent activities — recorded output as fixture
      versus a deterministic cache — and what "identical replay" means for a
      non-deterministic model call.
- [ ] **R6** Wave 0's workflow shape. Its four prerequisites are not per-object
      work and do not fit `ObjectMigrationWorkflow`.
- [ ] **R7** Handling a corpus re-ingestion mid-wave: pin in-flight objects to
      their starting model digest, and how affected objects are flagged.
- [ ] **R8** Where the coverage step sits, and how an object re-enters at
      `SCOPED` after coverage is extended without losing its earlier history.
- [ ] **R9** Orchestration of the `MANUAL_PORT` path, whose completion depends on
      a human writing code — a second indefinite wait alongside approvals.

Output → `research.md`.

## Phase 1 — Design

- [ ] `data-model.md` — ObjectWorkflow, AgentStep, VerificationResult,
      ApprovalRequest, CostRecord
- [ ] `contracts/verification-rules.md` — the checkable rule per output type,
      with the article each enforces
- [ ] `contracts/signals.md` — signal payloads and idempotency
- [ ] `quickstart.md` — drive one object end to end locally
- [ ] Constitution Check re-run

## Phase 2 — Task generation

Ordered tasks; see the outline below pending `/speckit.tasks`.

```
T001..T004   worker skeleton, test environment, local Temporal
T010..T015   workflow tests: restart at each step, 72h approval, replay
T020         coverage step before any agent step           <-- Article XII gate
T020a        T4 objects consume zero agent budget
T021..T025   verification rules per output type            <-- Article I core
T026..T030   retry, blocking, approval signals, agent-approval rejection
T031..T034   ledger activity as the sole write path, provenance, replay
T035..T037   MANUAL_PORT path: contract emitted, human wait, parity still required
T040..T044   wave workflow, concurrency, dependency enforcement
T050..T053   Wave 0 workflow, budget accounting, cost reporting
```

## Complexity Tracking

| Article | Violation | Why necessary | Simpler alternative rejected because |
| --- | --- | --- | --- |
| — | none | | |

Recorded cost, not a violation: two orchestration engines is heavy for a small
repository. Justified in
[ADR-0002](../../docs/adr/0002-durable-orchestration.md) — the binding
requirement is auditability rather than throughput, and the lighter
developer-session runtime cannot hold a three-day approval, an open-ended
manual-port wait, or produce a replay.

## Verification

1. Start `ObjectMigrationWorkflow` for
   `Prd_Repo_Srvc/Pay_Calendar/m_Pay_Calendar_Set_Pay_Calendar`; approve both
   gates → reaches `VALIDATED` with a complete ledger history.
2. Kill the worker at each of the six steps and restart → the workflow resumes
   from that step with no state lost *(SC-001)*.
3. Send an approval signal 72 simulated hours after the request in the
   time-skipping environment → workflow continues *(SC-002)*.
4. Submit an analysis citing a nonexistent port → rejected, retried, never
   written to the ledger *(SC-003)*.
5. Submit an approval with actor type agent → rejected *(SC-004)*.
6. Replay a completed object → deterministic steps reproduce identically; no
   model is re-invoked *(SC-005)*.
7. Start Wave 3 with `wf_CPM` incomplete → refused, naming the incomplete
   objects.
8. Start a wave with a concurrency limit of 4 → at most 4 run concurrently;
   block one object and confirm only its dependents stall *(SC-006)*.
8a. Submit an input containing a T4 construct → the containing object reaches
   `OUT_OF_SCOPE`, no agent step runs for it, and the rest of the input proceeds
   *(SC-008)*.
9. Exceed a per-object budget → pauses with resumable state *(SC-007)*.
