# Feature Specification: Agent Orchestration

**Feature Branch** `008-agent-orchestration`
**Created** 2026-09-10 · **Status** Draft
**Input** Drive every object through the lifecycle durably, with human approval
gates, retries, verification of every agent output, and full replay for audit.

---

## User Scenarios & Testing

### User Story 1 — Drive one object end to end (P1)

An engineer starts a migration for one object. The orchestrator runs analysis,
planning, generation, testing and reconciliation in order, pausing at each human
gate, and records every transition in the ledger.

**Why this priority:** without it the features are a toolbox, not a factory, and
nothing coordinates the ten-state lifecycle.

**Independent test:** start `m_CPM_NIH_Set_Pay_Calendar`, approve at both gates,
and assert it reaches `VALIDATED` with a complete ledger history.

**Acceptance scenarios**

1. **Given** an object in `DISCOVERED`, **When** its workflow starts, **Then**
   steps run in lifecycle order and each transition is recorded.
2. **Given** an object awaiting plan approval, **When** the orchestrator process
   restarts, **Then** the workflow resumes with no state lost.
3. **Given** an approval that arrives three days later, **When** it arrives,
   **Then** the workflow continues from that point.
4. **Given** a step that fails, **When** it is retried per policy and still
   fails, **Then** the object is marked blocked with the failure recorded, and no
   downstream step runs.

### User Story 2 — Verify every agent output before it is trusted (P1)

Every agent output passes a deterministic verifier before reaching the ledger.
Failures are retried with the verifier's findings; they are never recorded with
a caveat.

**Why this priority:** this is the mechanism that makes Article I real. Without
it the boundary between computed fact and model judgment collapses in practice.

**Independent test:** feed an analysis containing a fabricated port name and
assert it is rejected, retried, and never stored.

**Acceptance scenarios**

1. **Given** an analysis with an unresolvable citation, **When** verified,
   **Then** it is rejected and retried with the failing citation named.
2. **Given** a plan naming a nonexistent pattern, **When** verified, **Then** it
   is rejected.
3. **Given** a wave assignment violating the dependency graph, **When** verified,
   **Then** it is rejected naming the edge.
4. **Given** repeated verification failure up to the retry limit, **When**
   exhausted, **Then** the object is blocked for human attention rather than
   accepted.

### User Story 3 — Human approval as durable state (P1)

Approval requests are durable, survive restarts, wait indefinitely, and record
approver identity, timestamp and the exact artifact digest reviewed.

**Why this priority:** Article VIII. In a government migration the approval
record is the audit answer to who authorised a change to a payroll feed.

**Acceptance scenarios**

1. **Given** a pending request, **When** the system restarts, **Then** it is
   still pending and still addressed to the same approver role.
2. **Given** an approval, **When** recorded, **Then** the artifact digest is
   captured so a later edit is detectable.
3. **Given** an agent attempting to approve, **When** submitted, **Then** it is
   rejected — actor type agent can never approve.
4. **Given** a rejection with comments, **When** recorded, **Then** the object
   returns to the prior state with the comments attached.

### User Story 4 — Scope before converting (P1)

Before any object is analysed, the orchestrator runs the coverage report over the
input, records each object's construct tiers, and routes objects containing
unknown constructs to `OUT_OF_SCOPE` rather than attempting them.

**Why this priority:** Article XII requires scope to be knowable before
commitment. An orchestrator that begins analysing before coverage is established
spends model budget on objects it cannot finish, and discovers the gap late.

**Independent test:** submit an input containing a construct absent from the
registry; assert the coverage step routes the containing object to
`OUT_OF_SCOPE`, no agent step runs for it, and the rest of the input proceeds.

**Acceptance scenarios**

1. **Given** any input, **When** a run starts, **Then** coverage is computed
   first and every object's construct tiers are recorded before any analysis.
2. **Given** an object containing a T4 construct, **When** scoped, **Then** it
   is routed to `OUT_OF_SCOPE` and no agent step is invoked for it.
3. **Given** coverage is later extended, **When** the object is resubmitted,
   **Then** it re-enters at `SCOPED` with its earlier history retained.
4. **Given** an object containing a T3 construct, **When** scoped, **Then** it
   proceeds normally and is routed to `MANUAL_PORT` after plan approval.

### User Story 5 — Run a wave with bounded concurrency (P2)

A wave runs many objects concurrently, respecting dependency order between waves
and a concurrency limit for cost and rate-limit control.

**Acceptance scenarios**

1. **Given** a wave of 17 objects, **When** started, **Then** they run
   concurrently up to the configured limit.
2. **Given** a wave with unfinished predecessors, **When** started, **Then** it
   is refused naming the incomplete objects.
3. **Given** one object blocked mid-wave, **When** the wave continues, **Then**
   unaffected objects proceed and dependents of the blocked object do not.

### User Story 6 — Replay any object's history (P2)

An auditor asks how a decision was reached. The orchestrator replays the object's
execution deterministically, showing every input, every agent output, every
verification result and every approval.

**Why this priority:** this is why durable orchestration was chosen over a
developer-session agent runtime.

**Acceptance scenarios**

1. **Given** a completed object, **When** replayed, **Then** every step's inputs
   and outputs are reproduced in order.
2. **Given** a replay, **When** compared to the original, **Then** the
   deterministic steps produce identical results.
3. **Given** an agent step, **When** replayed, **Then** the recorded output is
   returned rather than the model being re-invoked.

### User Story 7 — Control cost and rate limits (P3)

The orchestrator caps model spend per object and per wave, and reports actual
against budget, so cost scales predictably with repository size.

**Acceptance scenarios**

1. **Given** a per-object budget, **When** exceeded, **Then** the object is
   paused for human decision rather than continuing.
2. **Given** a completed wave, **When** reported, **Then** actual cost per object
   and per step is available.

---

## Requirements

### Functional

- **FR-001** Each object MUST have one durable workflow execution carrying its
  full lifecycle, surviving process and host failure.
- **FR-001a** A run MUST compute coverage before any agent step, and MUST route
  objects containing T4 constructs to `OUT_OF_SCOPE` without invoking an agent
  *(Article XII)*.
- **FR-002** Human approvals MUST be durable signals that can wait indefinitely
  *(Article VIII)*.
- **FR-003** Every agent output MUST pass a deterministic verifier before any
  ledger write. Recording an unverified output is prohibited *(Article I)*.
- **FR-004** Verification failures MUST be retried with findings fed back, up to
  a configured limit, after which the object is blocked for human attention.
- **FR-005** Model calls, platform API calls and generator runs MUST be
  retryable activities with backoff; workflow logic MUST contain no
  non-determinism.
- **FR-006** All ledger writes MUST pass through the orchestrator; agents MUST
  NOT write directly *(003 FR-013)*.
- **FR-007** Wave execution MUST enforce dependency order between waves and a
  concurrency limit within one.
- **FR-008** An object's execution MUST be replayable, returning recorded agent
  outputs rather than re-invoking models.
- **FR-009** Agents MUST receive canonical model records, never raw exports
  *(Article I)*.
- **FR-010** The orchestrator MUST enforce per-object and per-wave cost budgets,
  pausing rather than exceeding them.
- **FR-011** A blocked object MUST NOT allow downstream steps or dependent
  objects to proceed.
- **FR-012** The orchestrator MUST record actor type on every transition, and
  MUST reject any approval whose actor type is agent.
- **FR-013** Reasoning loops within an agent step MUST be contained in a single
  activity, so self-correction does not pollute the audit history with dozens of
  records per object.

### Conformance requirements

- **CR-001** The orchestrator MUST handle an arbitrary object count across an
  arbitrary number of waves, including Wave 0, whose cross-cutting prerequisites
  are not per-object work and need a distinct workflow shape. *Evidence:* the
  reference corpus yields 119 objects across five waves.
- **CR-002** A cyclic dependency between workflows MUST be surfaced as requiring
  a human ordering decision, never broken automatically.
- **CR-003** Objects whose provenance is not production MUST be prevented from
  reaching `CUTOVER` until a production export replaces them *(Article IV)*.
- **CR-004** Coverage MUST be computed before any agent step, and an object
  containing a T4 construct MUST consume no agent budget *(Article XII)*.
- **CR-005** The orchestrator MUST scale to at least 10,000 objects without a
  change of design, with per-wave concurrency and budget enforced independently
  of total size.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Temporal cluster, workers and deployment | platform | yes | Platform engineering |
| Concurrency and budget ceilings appropriate to repository size | governance | no | Migration lead |
| Approver identity source and role mapping | integration | yes | Platform engineering |
| Model spend budget per object and per wave | governance | yes | Migration lead |
| Retry limits and escalation path per step | governance | no | Migration lead |

### Key entities

- **ObjectWorkflow** — one durable execution per object. Identity: the object's
  fully qualified path plus an attempt number.
- **WaveWorkflow** — parent execution coordinating a wave.
- **AgentStep** — one agent invocation: inputs, output, verification result,
  attempt number, cost.
- **VerificationResult** — pass/fail with findings, per rule.
- **ApprovalRequest** — durable pending human decision, with role, artifact
  digest and outcome.
- **CostRecord** — spend per step, object and wave.

---

## Success Criteria

Stated as invariants over an arbitrary input *(Article XI)*.

- **SC-001** An object's workflow survives an orchestrator restart at every
  lifecycle step, verified by a test that restarts at each.
- **SC-002** An approval pending for 72 hours is still actionable and resumes
  correctly.
- **SC-003** Zero ledger writes occur from unverified agent output; a query over
  all transitions returns zero without a verification result.
- **SC-004** Zero approvals with actor type agent.
- **SC-005** Replaying any completed object reproduces every deterministic step
  identically and re-invokes no model.
- **SC-006** A wave completes within its configured concurrency limit for any
  wave size, and a blocked object stops only itself and its dependents.
- **SC-008** No agent step is invoked for an object in `OUT_OF_SCOPE`; a query
  over all agent-step records returns zero exceptions.
- **SC-007** Cost per object and per step is reported for every completed wave,
  and no wave exceeds its budget without a recorded human decision.

---

## Edge Cases

- **Agent produces valid output that a human then rejects.** Object returns to
  the prior state with comments; the rejected artifact is retained, not deleted.
- **Corpus re-ingested mid-wave.** In-flight objects continue against the model
  digest they started with; the change is recorded and affected objects are
  flagged for re-analysis.
- **Two engineers start the same object concurrently.** One execution per object
  path; the second attaches to the running one rather than starting a duplicate.
- **Verification rule itself is wrong.** Rejects valid output repeatedly, so the
  object blocks. Retry-limit exhaustion must therefore surface the verifier's
  findings prominently, since the fix may be in the verifier.
- **Model unavailable for hours.** Activities retry with backoff; the workflow
  waits rather than failing the object.
- **Cost budget exhausted mid-object.** Pauses with state intact; resumable on a
  human decision.

## Assumptions

- Durable orchestration is worth its operational cost even at small object
  counts, because the binding requirement is auditability rather than
  throughput. Recorded in
  [ADR-0002](../../docs/adr/0002-durable-orchestration.md), which also records
  why the lighter developer-session runtime was rejected.

## Dependencies

- **Upstream** 001–007; `.specify/memory/constitution.md` for the verification
  rules
- **Downstream** none; this is the top of the stack.

---

## Review & Acceptance Checklist

- [x] No implementation detail beyond the engines decided in ADR-0002
- [x] Every requirement testable
- [x] User stories independently testable and prioritised
- [x] Success criteria measurable
- [x] Refusal conditions stated *(Article II)* — FR-003, FR-004, FR-011
- [x] Provenance requirements stated *(Article IV)* — FR-012, CF-003
- [x] Object identity fully qualified *(Article III)*
- [x] Corpus gaps enumerated *(Article VII)*
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] Coverage computed before any agent spend *(Article XII)* — FR-001a
- [x] Human-approval boundaries identified *(Article VIII)* — FR-002, FR-012
- [x] All `[NEEDS CLARIFICATION]` resolved
