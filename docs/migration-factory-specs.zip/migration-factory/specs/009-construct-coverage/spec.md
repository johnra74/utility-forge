# Feature Specification: Construct Coverage and Conformance

**Feature Branch** `009-construct-coverage`
**Created** 2026-09-10 · **Status** Draft
**Input** Declare what the converter can handle, report it for any input before
converting, and prove every claim against conformance corpora.

---

## Why this feature exists

The converter's scope is the PowerCenter metamodel, not any one estate
([ADR-0006](../../docs/adr/0006-general-converter-scope.md)). That only means
something if three things are true: every construct has a declared tier, the
tier is reportable for an arbitrary input without converting it, and no tier can
be claimed without evidence. This feature owns all three, plus the extensibility
contract that lets coverage grow without forking
([ADR-0007](../../docs/adr/0007-extensibility-and-backends.md)).

## User Scenarios & Testing

### User Story 1 — Report coverage for an unseen repository (P1)

A prospective customer supplies a repository export. Within minutes, and without
converting anything, an engineer produces a report: how much is convertible, what
preconditions are outstanding, what needs manual work, and which objects are
affected.

**Why this priority:** "can you convert my repository?" is the first question
asked and the last one a pilot engagement should be needed to answer. This is
the scoping deliverable.

**Independent test:** run coverage over a corpus containing a T4 construct and
assert the report names it, attributes it to specific objects, and reports the
convertible proportion — with no conversion attempted and no model calls made.

**Acceptance scenarios**

1. **Given** any repository export set, **When** coverage runs, **Then** every
   construct is counted and assigned a tier, and per-tier totals and proportions
   are reported.
2. **Given** a T2 construct, **When** coverage runs, **Then** its outstanding
   restrictions are listed with the objects they affect.
3. **Given** a T3 construct, **When** coverage runs, **Then** the objects
   needing manual work are named individually.
4. **Given** a T4 construct, **When** coverage runs, **Then** it is reported as
   unknown, the containing objects are named, and the process exits non-zero.
5. **Given** any input, **When** coverage runs, **Then** no conversion is
   attempted, no artifact is written, and no model call is made.

### User Story 2 — Refuse to claim more than is proved (P1)

An engineer promotes a construct to T1. The promotion fails unless a conformance
fixture exercises it and its counter-example test passes.

**Why this priority:** a tier is a promise. Silent partial support — converting
a construct's easy paths and ignoring the rest — is worse than refusing it,
because it converts the reader's trust along with the code.

**Independent test:** attempt to promote a construct to T1 with no fixture;
assert the registry check fails naming what is missing.

**Acceptance scenarios**

1. **Given** a registry entry at T1 with no conformance-corpus coverage,
   **When** the registry is validated, **Then** validation fails naming the
   construct.
2. **Given** a T1 entry whose pattern has no counter-example test, **When**
   validated, **Then** validation fails *(Article V)*.
3. **Given** a T1 or T2 entry referencing a pattern that does not load, **When**
   validated, **Then** validation fails.
4. **Given** a T2 entry with no stated restrictions, **When** validated,
   **Then** validation fails — T2 without restrictions is either T1 or a
   mistake.

### User Story 3 — Extend coverage without touching the core (P1)

An engineer adds support for a construct the converter has not seen, by adding a
pattern plugin, a fixture and a registry entry. No core file changes.

**Why this priority:** coverage is never complete. If extending it means editing
a dispatcher, every engagement forks the converter.

**Independent test:** add a plugin for a new construct in a temporary directory,
and assert it is discovered, dispatched, and reported at its declared tier
without modifying any file under `core/`.

**Acceptance scenarios**

1. **Given** a plugin bundling a catalog entry, a counter-example test and an
   emitter, **When** it is registered, **Then** the construct converts at its
   declared tier.
2. **Given** a plugin missing any of the three parts, **When** loading is
   attempted, **Then** it is rejected naming the missing part.
3. **Given** two plugins claiming the same construct, **When** loading,
   **Then** the conflict is reported and neither is silently preferred.
4. **Given** a registry entry whose plugin has been deleted, **When** the
   registry is validated, **Then** validation fails rather than the construct
   silently regressing to unknown at conversion time.

### User Story 4 — Verify support per repository version (P1)

An engineer confirms whether a construct is supported at the repository version
in front of them, rather than in general.

**Why this priority:** element and attribute availability differs across
PowerCenter releases. A construct verified at one version is a claim about that
version.

**Acceptance scenarios**

1. **Given** a registry entry, **When** inspected, **Then** it names the
   repository-version range it was verified against.
2. **Given** an input at a version outside every entry's verified range, **When**
   coverage runs, **Then** it refuses with a version message rather than
   reporting optimistic coverage.
3. **Given** an input at a supported version using a construct verified only at
   another, **When** coverage runs, **Then** that construct is reported T2 with
   a version restriction.

### User Story 5 — Maintain the conformance corpora (P2)

An engineer runs the whole conformance suite and sees, per corpus, which
constructs are exercised and which registry claims are unevidenced.

**Why this priority:** coverage claims decay. A construct can regress from T1 by
a change elsewhere, and only continuous evidence catches it.

**Acceptance scenarios**

1. **Given** the corpora, **When** the suite runs, **Then** a matrix of
   construct × corpus coverage is produced.
2. **Given** a T1 or T2 construct exercised by no corpus, **When** the suite
   runs, **Then** it is reported as an unevidenced claim and the suite fails.
3. **Given** a real corpus added under an ingestion agreement, **When** it is
   registered, **Then** it contributes construct coverage without contributing
   production data.

### User Story 6 — Add a customer repository as a regression corpus (P2)

After an engagement, the customer's repository structure is retained as a
regression corpus so later changes cannot break what once worked.

**Acceptance scenarios**

1. **Given** a completed engagement, **When** its repository is registered as a
   corpus, **Then** the conformance suite includes it and reports its construct
   coverage.
2. **Given** a registered real corpus, **When** the suite runs, **Then** it
   asserts structure and construct coverage only, never data values.

---

## Requirements

### Functional

- **FR-001** The system MUST hold a construct registry as versioned data, not
  code, recording per construct: coverage tier, restrictions, implementing
  pattern, verified repository-version range, and conformance-corpus coverage
  *(Article XII)*.
- **FR-002** The system MUST report coverage for an arbitrary input without
  converting it, without writing any artifact, and without any model call.
- **FR-003** The coverage report MUST give per-tier counts and proportions, list
  outstanding T2 restrictions with affected objects, and name T3 and T4 objects
  individually.
- **FR-004** The system MUST exit non-zero when the input contains a T4
  construct or an unverified repository version.
- **FR-005** The system MUST validate the registry and MUST fail when: a T1
  entry lacks conformance-corpus coverage; a T1 entry's pattern lacks a
  counter-example test; a T2 entry states no restrictions; or any entry
  references a pattern that does not load *(Article V, XII)*.
- **FR-006** A pattern plugin MUST bundle a catalog entry, a counter-example test
  and an emitter. A plugin missing any part MUST be rejected at load time,
  naming the missing part.
- **FR-007** Plugin discovery MUST require no changes to files under `core/`, and
  two plugins claiming one construct MUST be reported as a conflict rather than
  silently resolved.
- **FR-008** Registry entries MUST be repository-version-scoped, and a construct
  used at an unverified version MUST report T2 with a version restriction.
- **FR-009** The system MUST produce a construct × corpus coverage matrix and
  MUST fail when any T1 or T2 construct is exercised by no corpus.
- **FR-010** The system MUST support registering additional corpora, including
  real repositories, and MUST assert only structure and construct coverage
  against them, never data values.
- **FR-011** The system MUST be deterministic, offline, and free of model calls
  *(Article I)*.
- **FR-012** Tier changes MUST be reviewable as a diff of the registry data
  file, with the evidence required by FR-005 checked in CI.

### Conformance requirements

- **CR-001** Every construct in the PowerCenter metamodel MUST have a registry
  entry. A construct with no entry is T4 by definition, and encountering one MUST
  be a refusal rather than a silent skip.
- **CR-002** `synthetic-core` MUST exercise every T1 and T2 construct at least
  once.
- **CR-003** `synthetic-identity` MUST exercise shortcuts (local and global),
  folder-level reusable transformations and sessions, worklets nested at least
  three deep, multi-folder exports and multi-repository inputs. *Rationale:* no
  real corpus on hand exercises any of these, and they change what identity
  means *(Article III)*.
- **CR-004** `synthetic-adversarial` MUST exercise name collisions at every
  scope, empty-versus-absent attributes, cyclic dependencies, a router whose
  first group is unconditionally true, and unset variable ports.
- **CR-005** The registry MUST be reportable at any tier granularity — whole
  input, per folder, per mapping — since scoping conversations happen at all
  three.

### Gaps this feature must surface

| Gap | Type | Blocking? | Owner |
| --- | --- | --- | --- |
| Informatica documentation access for authoritative construct semantics | reference | yes | Migration engineering |
| Sample exports at repository versions outside the verified range | conformance | yes | Migration engineering |
| Ingestion agreement terms for adding a real customer corpus | governance | yes | Legal / migration lead |
| Whether unverified-version constructs are quoted as T2 or excluded | governance | no | Product lead |

### Key entities

- **ConstructEntry** — one construct's registry record: identifier, tier,
  restrictions, pattern id, verified version range, corpus coverage.
- **PatternPlugin** — catalog entry, counter-example test and emitter, bound to
  one or more constructs.
- **CoverageReport** — per input: tier counts and proportions, outstanding
  restrictions, named T3/T4 objects, version verdict.
- **ConformanceCorpus** — a registered corpus: name, origin (synthetic or real),
  construct coverage, assertion scope.
- **CoverageMatrix** — construct × corpus, with unevidenced claims flagged.

---

## Success Criteria

Stated as invariants *(Article XI)*.

- **SC-001** For any input, every construct encountered is assigned a tier; zero
  constructs are unclassified.
- **SC-002** Coverage reporting completes for any input without writing an
  artifact, without a model call, and without a network call — asserted by an
  import guard and a filesystem assertion.
- **SC-003** Registry validation fails on every one of the four FR-005 defect
  classes; asserted once per class.
- **SC-004** Every T1 and T2 construct is exercised by at least one corpus; the
  coverage matrix reports zero unevidenced claims.
- **SC-005** A plugin can be added, discovered, dispatched and reported with zero
  modifications to files under `core/`; asserted by a test that fails if any
  `core/` file changes.
- **SC-006** A plugin missing its catalog entry, counter-example test or emitter
  is rejected at load; asserted once per missing part.
- **SC-007** Every registry entry names a verified repository-version range;
  zero entries claim support in general.
- **SC-008** Coverage for the largest available corpus completes in under 30
  seconds.
- **SC-009** A tier regression — a T1 construct losing its fixture or its test —
  fails CI rather than surfacing at conversion time.

---

## Edge Cases

- **Construct present but never instantiated.** Reported at its tier with a
  zero count. Absence of use is not absence of support, and the report must not
  imply otherwise.
- **Construct in the registry whose plugin was deleted.** Registry validation
  fails. It must never degrade to T4 silently at conversion time.
- **Input mixing repository versions.** Coverage reported per version; the
  lowest verdict governs the input.
- **Vendor plugin claiming a construct the core also claims.** Conflict
  reported; neither is preferred. Precedence would make coverage
  configuration-dependent, which defeats the point of a declared surface.
- **T3 construct that a customer has already hand-ported.** Still T3 in the
  registry — the tier describes the converter, not the engagement. The ledger
  tracks that the port exists.
- **Registry claims T1 but the emitter refuses at conversion time.** A
  contradiction and a defect. CI must catch it by converting every
  `synthetic-core` fixture, not merely by loading plugins.

## Assumptions

- Construct semantics are establishable from Informatica's documentation plus
  fixture experiments. Where documentation is ambiguous, the construct stays T2
  with the ambiguity as a stated restriction, rather than being promoted on a
  guess.
- Coverage proportions computed on structure predict conversion effort well
  enough for scoping. They are not an effort estimate, and the report must not
  present them as one.

## Dependencies

- **Upstream** 001 (parsed model to count constructs against);
  `docs/construct-coverage.md` (the declared surface);
  `docs/pattern-catalog.md` (pattern entries and counter-examples)
- **Downstream** 003 gates `DISCOVERED` → `SCOPED` on tiers; 004 bands
  complexity using them; 005 plans manual ports for T3; 006 dispatches on
  patterns; 008 computes coverage before spending agent budget.

---

## Review & Acceptance Checklist

- [x] No implementation detail beyond the registry-as-data decision in ADR-0007
- [x] Every requirement testable and unambiguous
- [x] Every user story independently testable and prioritised
- [x] Success criteria measurable and technology-agnostic
- [x] Refusal conditions stated *(Article II)* — FR-004, FR-005, FR-006
- [x] Provenance requirements stated *(Article IV)* — FR-008 version scoping
- [x] Object identity fully qualified throughout *(Article III)*
- [x] Corpus gaps enumerated with owners *(Article VII)*
- [x] Human-approval boundaries identified *(Article VIII)* — tier promotion is
      a reviewed registry diff, not an automated act
- [x] No requirement or success criterion cites one estate's counts
      *(Article XI)*
- [x] This feature *is* the Article XII mechanism
- [x] All `[NEEDS CLARIFICATION]` resolved
